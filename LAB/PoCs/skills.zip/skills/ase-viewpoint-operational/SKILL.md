---
name: ase-viewpoint-operational
description: >
  Build, analyse and review the Operational view of an agentic system in
  SysML v2 following the Rozanski & Woods Operational viewpoint - installation
  and upgrade, functional and data migration, operational monitoring and
  control, alerting, configuration management, performance monitoring,
  support, backup and restore, and operation in third-party environments -
  made agentic: per-stage traces, token and latency telemetry, evaluation in
  production, prompt/model/index versions as configuration items, kill
  switches, operating modes (normal / degraded / maintenance / halted),
  runbooks and escalation. Use when asked how an agent will be run, monitored,
  rolled out, rolled back, supported or switched off in production, or to
  review an operations plan. Do not use for where components run and on what
  (use ase-viewpoint-deployment) or for failure analysis and fallback tactics
  as a quality (use ase-perspective-availability-resilience).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Operational viewpoint

Load `ase-arch-sysml-foundations` first. Control: `AseMethodology::OperationalViewpoint`
(no `AseCatalogue` entry yet - the R&W table below comes from the book and
site, not from a control). Read it with `ase_viewpoint("Operational")` and
`ase_obligations("Operational")`. Autonomy precedes this view in A4: its
escalation routes are an input here.

## Definition

> "Describes how the system will be operated, administered, and supported
> when it is running in its production environment" -
> `AseMethodology::OperationalViewpoint`, source
> viewpoints-and-perspectives.info/home/viewpoints.

R&W note it is usually the least rigorously defined view because detail
arrives late; for an agentic system that is backwards. The behaviour of an
LLM stage is known only by observing it in production, and it changes when
the provider, prompt or corpus changes underneath an unchanged design.
**Stakeholders**: system administrators, production engineers, developers,
testers, communicators, assessors (R&W); in ASE the `SiteReliabilityEngineer`
and `ComplianceOfficer` hold `OperationalVisibility`, the SRE and
`SoftwareEngineer` hold `FailureBehaviour`. **Applicability**: any system
deployed into a complex or critical operational environment - every agent
with a model provider, a tool or a user-facing answer qualifies.

**Concerns.** ASE frames two: `OperationalVisibility` (can an operator see
what the system did and why?) and `FailureBehaviour` (what breaks when a
participant fails, and how far does it spread?). R&W's list, with the agentic
reading:

| R&W concern | Agentic reading |
|---|---|
| Installation and upgrade | a release is a *configuration baseline*: code + model id + prompt set + index version + tool allow-list; backout = the previous baseline |
| Functional migration | moving users from the old workflow; shadow mode (agent runs, human answers) before cut-over |
| Data migration | re-embedding the corpus when the embedding model changes; memory stores across schema changes |
| Operational monitoring and control | per-stage traces; route and model switches; kill switch |
| Alerting | SLO burn on latency, token spend, fallback-route rate, online eval scores, PII leak |
| Configuration management | prompt, model, index, threshold, allow-list versions as configuration items; who may change which |
| Performance monitoring | latency and tokens per stage and per branch, measured against declared `latencyMs` / `costTokens` |
| Support | answer-flagging by users, triage tiers, escalation to a human owner |
| Backup and restore | prompt registry, eval sets, memory, audit traces; the index is rebuildable, its source is not |
| Operation in third-party environments | model and search APIs: SLAs, rate limits, deprecation notices, silent model updates |

**Models (R&W)**: installation, migration, configuration management,
administration (monitoring, control, alerting, procedures), support.

## R&W model elements -> SysML v2

| R&W element | SysML v2 | ASE convention |
|---|---|---|
| Installation / upgrade plan, backout | `action def ReleaseBaseline` with successions; backout as an `action` reachable from every step | the release gate is the first action |
| Migration plan | `action def` (parallel run / shadow / staged) + `requirement def` for the cut-over criterion | cut-over criterion is an eval threshold |
| Configuration item / group | `part def ConfigurationBaseline` with `String` version attributes | never on stage defs - no `@Extension` needed in the view |
| Telemetry record | `item def StageSpan` (traceId, stage, latency, tokens, model and prompt version, outcome) | one span per stage per request |
| Telemetry coverage | `allocation def TracedBy` + `allocate <stage> to ops.tracer` | a stage with no allocation is invisible |
| Operating modes | `state def ServiceMode` with signal `item def`s; `exhibit state` on the operations plane | degraded modes correspond to `hasFallback` stages |
| Control (kill switch, route switch) | `part def KillSwitch` + transitions to a `halted` state | every mode reachable and leavable |
| Alert rule | `requirement def <X>Alert` with numeric threshold attributes, satisfied by the monitor | no number, no alert |
| Operational procedure (runbook) | `action def Runbook<X>` whose `doc` names trigger, stages, owner | one per articulation point and per degraded mode |
| Support model / escalation | `action def` + `@Correspondence` to the Autonomy view | escalation target is a stakeholder role |
| Eval in production | `part def OnlineEvaluator` (sample rate, judge, metric) + alert requirement | the production face of the A2 eval questions |
| Backup and restore | `requirement def RestoreObjectives` (RPO, RTO) + `verification def` (restore drill) | per store: rebuildable or backed up |

## Activities -> SysML

1. **Identify the operational stakeholders and their questions.** Name the
   operator role from A1 (`part def X :> AseMethodology::SiteReliabilityEngineer`)
   and specialise the two framed concerns with spec-specific ones
   (`concern def WebPathVisibility :> AseMethodology::OperationalVisibility`).
   An RS spec rarely names the operator; the oracle expects you to ask.
2. **Design the telemetry.** One `item def StageSpan` carrying what a
   post-mortem needs: `traceId`, `stage`, `latencyMs`, `tokensIn`,
   `tokensOut`, `modelVersion`, `promptVersion`, `outcome`
   (`ok | fallback | timeout | error`). Add decision records for routing
   stages (verdict and reason) - a route nobody can explain fails
   `OperationalVisibility`. Allocate every stage to the tracer:

   ```
   allocation def TracedBy {
       end stage : RS04::Stage;
       end collector : TraceCollector;
   }
   allocation relevanceTraced : TracedBy allocate RS04::RS04Design::relevance to ops.tracer;
   ```
3. **Define the operating modes.** A `state def` with `normal`, one degraded
   state per fallback route, `maintenance`, and `halted` (kill switch). Every
   state has a way in and a way out; `halted` leaves only by an explicit
   release signal.

   ```
   state def ServiceMode {
       entry; then normal;
       state normal;
       state webDegraded;
       state maintenance;
       state halted;
       transition first normal accept WebSearchUnavailable then webDegraded;
       transition first webDegraded accept WebSearchRestored then normal;
       transition first normal accept KillSwitchEngaged then halted;
       transition first halted accept KillSwitchReleased then normal;
   }
   ```
4. **State the alert rules** as requirement defs with numeric thresholds and
   a window, each satisfied by the monitor. Derive them from the A2 scenarios
   and the budgets: `latency_budget` gives the p100 threshold, `cost_budget`
   the per-request token ceiling, the eval questions the online metrics.
5. **Model configuration management.** A `ConfigurationBaseline` part def
   listing every behaviour-changing item and its version; a decision naming
   who may change each (prompt changes by GEPA go through the release gate,
   never straight to production).
6. **Plan installation, upgrade and migration.** `action def ReleaseBaseline`:
   gate -> shadow -> canary -> promote, with `backout` reachable from every
   step. Data migration (re-embedding) builds a new index beside the old one
   and switches an alias; model upgrades are a new baseline, not an edit.
7. **Write the runbooks.** One `action def Runbook<X>` per degraded mode and
   per stage `articulation_points` names. The `doc` names the trigger (the
   alert), the owner role, the stages touched and the exit condition.
8. **Plan support and backup.** Support tiers and escalation as an
   `action def`; `@Correspondence` to the Autonomy view's escalation path.
   RPO / RTO per store as a requirement with a restore-drill verification.
9. **Walk the failure scenarios.** For each A2 availability scenario, check
   that its stimulus is an accepted signal, its environment is a mode, its
   response is a runbook and its measure is an alert threshold.

## The view

```
view def OperationalView {
    satisfy requirement vp : AseMethodology::OperationalViewpoint;
    filter @SysML::PartUsage or @SysML::StateUsage or @SysML::ActionUsage or @SysML::AllocationUsage;
}
view operational : OperationalView {
    expose RS04_Operational::ops::**;
    render asTreeDiagram;           // plane, modes, telemetry allocations
}
view runbooks : OperationalView {
    expose RS04_Operational::*;
    render asElementTable;          // runbook, trigger, owner, exit
}
```

Keep each `filter` on one line (the builtin gate is line-based). The filter
admits no flows between stages: the pipeline belongs to Functional; this view
shows what watches and controls it.

## Analysis the model supports

| Question | Engine |
|---|---|
| Is there any degraded path at all? | `fallback_coverage` (ABSENCE, warning, reads `hasFallback`) |
| Which stage failures need a runbook? | `articulation_points`, `minimum_cut`, `cascade_depth` (Availability) |
| Every stage traced; modes live (no trap or unreachable state); degraded modes backed by `hasFallback` stages; kill switch; numeric alert thresholds; runbook per articulation point | `run_skill_script("ase-viewpoint-operational", "ops_coverage.py", stdin=<design + operational view>)` |
| Alert thresholds consistent with budgets | `latency_budget`, `cost_budget` numbers vs alert attributes - by comparison, review |
| Does the degraded mode actually work? | none - `verification def` (outage drill), run in the eval harness |
| Online quality in production | none in the model - `OnlineEvaluator` output against the alert requirement |

`fallback_coverage` is closed-world and shallow: it passes when *any* stage
declares `hasFallback = true`. It does not know which failure the fallback
covers, nor whether the fallback is operable. `ops_coverage.py` adds the
correspondence (fallback stage <-> degraded mode <-> runbook); the drill
verification adds the evidence. `verification_coverage` fires regardless
(projection limit - see foundations `reasoning.md`); record it as an
accepted `@Finding`.

Projection limits that shape this view: `state def`, `allocation`,
`verification def` and AD-kit metadata are **not projected**, and
`cli explain` reads `design.sysml` only - so nothing in `ad/operational.sysml`
moves the sweep. Modes, telemetry allocations and runbooks are checked
text-level by `ops_coverage.py` alone. And `checks.EXTERNAL_KINDS` is only
`WebSearchFallback`: the hosted model API, tracing SaaS and any MCP/HTTP tool
are third-party environments `data_exposure` cannot see. List each in the
third-party section with the data it receives, and record it as a decision.

## Reasoning over the model

- *What does the operator see when stage X fails?* X's span has
  `outcome = error`; the mode transition it triggers; the runbook naming X.
  A stage with none of the three is an unobservable failure.
- *What if the web search API is gone for a day?* Remove `web` from the
  pattern in a scratch variant and re-run `explain`: `latency_budget` should
  improve, `fallback_coverage` still pass (relevance keeps its route), and
  no requirement lose its `satisfy`. If one does, the degraded mode breaks a
  requirement and the stakeholder must accept it in a decision.
- *Which alert catches a silent model update?* Only the online evaluator and
  the per-stage token/latency drift alert; a design with neither cannot
  detect it. State this as a risk if absent.
- **Closed world.** "Every stage traced" means every stage *declared* in the
  pattern has a `TracedBy` allocation - a tool called inside a stage is not a
  stage and is not covered. Say which stages the verdict rests on.
- **Correspondences** (`@Correspondence`): Operational -> Functional
  (`TracedBy` for every stage usage), Operational -> Availability
  (`webDegraded` realised by a `hasFallback` stage), Operational -> Autonomy
  (escalation target equals the approval owner), Operational -> Deployment
  (the tracer and kill switch run somewhere), Operational -> Development
  (the baseline's versions are the codeline's released artefacts).

## Pitfalls -> detection in the model

| Pitfall | Detection |
|---|---|
| Lack of engagement with operational staff | no stakeholder specialising `SiteReliabilityEngineer`; runbook `doc` with no owner role |
| Lack of backout planning | `ReleaseBaseline` has no `backout` action, or backout reachable from only the last step |
| Lack of migration planning / insufficient window | no migration `action def`; re-index with no parallel index or duration |
| Missing management tools | no kill switch, no route switch (`ops_coverage.py`) |
| Production environment constraints ignored | third-party rate limits absent from the alert rules |
| Lack of integration into the production environment | spans not allocated (`ops_coverage.py` telemetry) |
| Inadequate backup models | no `RestoreObjectives`; prompt registry or eval set not listed |
| Unsuitable alerting | alert requirement with no number or window (`ops_coverage.py`); alert on every request |
| (agentic) configuration drift | prompt or model version not in `ConfigurationBaseline`; `modelId` "latest" |
| (agentic) unobservable routing | a `hasFallback` stage with no decision record in its span |
| (agentic) eval only offline | no `OnlineEvaluator`; quality known only at release |
| (agentic) fallback nobody can see | `hasFallback` stage but no degraded mode (`ops_coverage.py`) |
| (agentic) kill switch trap | `halted` with no release transition, or reachable only from `normal` |

## Checklist

Operator role named and consulted; every stage traced with model and prompt
version; operating modes defined, each reachable and leavable; every fallback
stage has a degraded mode and a runbook; every articulation point has a
runbook; kill switch present and tested; alert thresholds numeric, windowed
and traced to a budget or scenario; configuration baseline lists model,
prompt set, index and allow-list versions; release path has gate, shadow or
canary, and backout; re-index and model-upgrade migrations planned; RPO/RTO
per store with a restore drill; third-party SLAs, limits and deprecation
channels recorded; support tiers and escalation mapped to Autonomy.

## Output contract

`ad/operational.sysml` containing: operator stakeholder and specialised
concerns; `StageSpan` and `TracedBy` allocations for every stage; the
`ServiceMode` state def exhibited on the operations plane; alert requirement
defs with `satisfy`; `ConfigurationBaseline`; `ReleaseBaseline` and runbook
action defs; `RestoreObjectives` with a verification; `@Finding` for
`fallback_coverage` and the Availability checks; `@Correspondence`
statements; `@ArchitectureDecision` for mode design and backout strategy.

Validate (from `AI Skills/skills`):

```
python description-to-sysmlv2/scripts/check_model.py < ad/operational.sysml
python ase-arch-sysml-foundations/scripts/check_ad.py < ad/operational.sysml
cat design.sysml ad/operational.sysml | python ase-viewpoint-operational/scripts/ops_coverage.py
python -m sysmlagents.cli explain <RS-xx>
```

First line of the file: `// ad-check: fragment viewpoints=Operational perspectives=`.
Report every surviving `ops_coverage` warning with its disposition. Worked
example (RS-04, CorrectiveRag with web fallback): `references/example.sysml`.
