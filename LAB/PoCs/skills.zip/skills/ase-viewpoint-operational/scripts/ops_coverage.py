#!/usr/bin/env python3
"""Tier-3 analysis: operational coverage of an agentic design (R&W Operational).

Reads SysML v2 text on stdin: the design (stage defs and the pattern part def
with parts and flows) followed by the Operational view. Reports what an
operator could not see or control, as text-level heuristics:

    telemetry     every stage usage is allocated to a tracer
                  (an allocation typed by, or targeting, *Trace*/*Telemetry*/*Span*)
    modes         a state def with a degraded and a maintenance state; every
                  state reachable, every state leavable (no trap state)
    kill switch   a halted/killed/stopped state or a *KillSwitch* part
    fallback      degraded states <-> stages with hasFallback = true, both ways
                  (the correspondence fallback_coverage cannot see)
    alerts        requirement defs named *Alert*/*Slo* carry a numeric threshold
    runbooks      every articulation point of the pattern (forward flows, back
                  edges removed as sysmlagents.analysis does) is
                  named in some `action def Runbook*` (doc text counts)

Closed-world: only declared stages, flows, states and allocations are seen.
Every result is a prompt for judgement, not a verdict. Exit 0 unless the input
contains no pattern (a part def with parts and flows), then 1.
"""

import re
import sys


def strip(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"//[^\n]*", " ", text)


def blocks(text, header_re):
    for m in re.finditer(header_re, text):
        i = text.find("{", m.start())
        if i < 0 or ";" in text[m.end():i]:
            continue
        depth, j = 0, i
        while j < len(text):
            depth += {"{": 1, "}": -1}.get(text[j], 0)
            if depth == 0:
                break
            j += 1
        yield m.group(1), text[i + 1:j]


def resolve(defs, parents, name, attr, seen=None):
    seen = seen or set()
    if name in seen or name not in defs:
        return None
    seen.add(name)
    m = re.search(r"attribute\s+(?:redefines\s+)?" + attr + r"\b[^=;]*=\s*([\w.]+)", defs[name])
    if m:
        return m.group(1)
    p = parents.get(name)
    return resolve(defs, parents, p, attr, seen) if p else None


def back_edges(nodes, edges):
    """DFS colouring in declaration order - mirrors sysmlagents.analysis."""
    succ = {n: [b for a, b in edges if a == n and b in nodes] for n in nodes}
    colour, back = {n: 0 for n in nodes}, set()

    def visit(n):
        colour[n] = 1
        for m in succ[n]:
            if colour[m] == 1:
                back.add((n, m))
            elif colour[m] == 0:
                visit(m)
        colour[n] = 2

    for n in nodes:
        if colour[n] == 0:
            visit(n)
    return back


def articulation(stages, flows):
    ids = set(stages)
    back = back_edges(list(stages), flows)
    fwd = [(a, b) for a, b in flows if a in ids and b in ids and (a, b) not in back]
    targets = {b for _, b in fwd}
    entries = [s for s in ids if s not in targets and any(a == s for a, _ in fwd)]

    def reach(removed):
        adj = {}
        for a, b in fwd:
            if a not in removed and b not in removed:
                adj.setdefault(a, []).append(b)
        seen = {e for e in entries if e not in removed}
        stack = list(seen)
        while stack:
            for t in adj.get(stack.pop(), []):
                if t not in seen:
                    seen.add(t)
                    stack.append(t)
        return seen

    base = reach(set())
    out = []
    for s in sorted(ids):
        lost = (base - {s}) - reach({s})
        if lost:
            out.append((s, sorted(lost)))
    return out


def main():
    raw = sys.stdin.read()
    text = strip(raw)
    defs, parents = {}, {}
    for m in re.finditer(r"\bpart\s+def\s+(\w+)(\s*:>\s*(?:\w+::)*(\w+))?", text):
        if m.group(3):
            parents[m.group(1)] = m.group(3)
    defs = {k: v for k, v in blocks(text, r"\bpart\s+def\s+(\w+)")}

    patterns = {}
    for name, body in defs.items():
        parts = dict(re.findall(r"\bpart\s+(\w+)\s*:\s*(?:\w+::)*(\w+)\s*;", body))
        flows = re.findall(r"\bflow\s+(\w+)(?:\.\w+)?\s+to\s+(\w+)", body)
        if len(parts) >= 2 and flows:
            patterns[name] = (parts, flows)
    if not patterns:
        print("FAIL - no pattern found (a part def with parts and flows); include design.sysml in the input")
        return 1

    # -- allocations to a tracer ------------------------------------------
    traced = set()
    for m in re.finditer(r"(?:\ballocation\s+\w+\s*:\s*(?:\w+::)*(\w+)\s+)?\ballocate\s+([\w:.]+)\s+to\s+([\w:.]+)\s*;", text):
        typ, src, dst = m.group(1) or "", m.group(2), m.group(3)
        if re.search(r"trac|telemetr|span", typ + " " + dst, re.I):
            traced.add(re.split(r"::|\.", src)[-1])

    # -- operating modes ----------------------------------------------------
    modes = {}
    for name, body in blocks(text, r"\bstate\s+def\s+(\w+)"):
        states = re.findall(r"\bstate\s+(\w+)\s*[;{]", body)
        trans = re.findall(r"\btransition\s+(?:\w+\s+)?first\s+(\w+)\s+(?:accept\s+[\w:]+\s+)?then\s+(\w+)", body)
        start = re.search(r"\bentry\s*;\s*then\s+(\w+)", body)
        modes[name] = (states, trans, start.group(1) if start else (states[0] if states else None))

    runbooks = {n: b for n, b in blocks(raw, r"\baction\s+def\s+(Runbook\w*)")}
    alerts = {n: b for n, b in blocks(text, r"\brequirement\s+def\s+(\w*(?:Alert|Slo)\w*)")}
    kill = re.search(r"\bstate\s+(halted|killed|stopped|off)\b|\bKillSwitch\b", text, re.I)

    warnings, info = [], []

    all_states = [s for st, _, _ in modes.values() for s in st]
    degraded = [s for s in all_states if re.search(r"degrad|fallback|reduced", s, re.I)]
    if not modes:
        warnings.append("modes: no state def - operating modes (normal / degraded / maintenance / halted) undeclared")
    else:
        if not degraded:
            warnings.append("modes: no degraded state - partial operation is not an operator-visible mode")
        if not any(re.search(r"maint", s, re.I) for s in all_states):
            info.append("modes: no maintenance state - re-index and upgrades run in normal mode")
        for name, (states, trans, start) in modes.items():
            outs = {a for a, _ in trans}
            ins = {b for _, b in trans} | ({start} if start else set())
            for s in states:
                if s not in outs:
                    warnings.append(f"modes: {name}.{s} has no outgoing transition - a trap state")
                if s not in ins:
                    warnings.append(f"modes: {name}.{s} is unreachable - no transition enters it")
    if not kill:
        warnings.append("control: no kill switch (halted state or KillSwitch part)")

    for name, body in alerts.items():
        if not re.search(r"attribute\s+\w+\s*:\s*\w+\s*=\s*\d", body):
            warnings.append(f"alerts: {name} has no numeric threshold - unsuitable alerting")
    if not alerts:
        warnings.append("alerts: no requirement def named *Alert / *Slo")

    for pname, (parts, flows) in sorted(patterns.items()):
        fb = [u for u, t in parts.items() if resolve(defs, parents, t, "hasFallback") == "true"]
        llm = [u for u, t in parts.items() if (resolve(defs, parents, t, "llmCalls") or "0") not in ("0",)]
        untraced = sorted(set(parts) - traced)
        aps = articulation(list(parts), flows)
        print(f"== {pname}: {len(parts)} stages, {len(fb)} with fallback, {len(llm)} model-calling")
        if untraced:
            warnings.append(f"telemetry: {pname} stages not allocated to a tracer: {', '.join(untraced)}")
        if fb and modes and not degraded:
            warnings.append(f"fallback: {pname} declares fallback stages ({', '.join(fb)}) but no degraded mode shows them to the operator")
        if degraded and not fb:
            warnings.append(f"fallback: degraded mode(s) {', '.join(degraded)} but no stage of {pname} has hasFallback = true (fallback_coverage will fire)")
        if not fb and not modes:
            warnings.append(f"fallback: {pname} has no fallback stage and no modes - any failure is an outage")
        rb_text = " ".join(runbooks.values())
        for s, lost in aps:
            if not re.search(r"\b" + s + r"\b", rb_text):
                warnings.append(f"runbooks: articulation point {pname}.{s} (strands {', '.join(lost)}) is named in no Runbook action def")
        info.append(f"{pname}: articulation points {', '.join(s for s, _ in aps) or 'none'}; runbooks {len(runbooks)}")

    head = "OK with warnings" if warnings else "OK"
    print(f"{head} - {len(warnings)} warning(s), {len(modes)} mode machine(s), {len(alerts)} alert rule(s), {len(runbooks)} runbook(s)")
    for tag, items in (("warning", warnings), ("info", info)):
        for i in items:
            print(f"  - {tag}: {i}")
    print("note: text-level, closed-world heuristics over declared stages, flows, states and allocations")
    return 0


if __name__ == "__main__":
    sys.exit(main())
