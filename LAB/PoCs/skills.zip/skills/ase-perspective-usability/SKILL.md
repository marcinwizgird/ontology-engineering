---
name: ase-perspective-usability
description: >
  Apply the Rozanski & Woods Usability perspective to an agentic system's
  SysML v2 architecture - a review-only perspective in ASE - by stating
  measurable usability requirements for conversational UX (follow-up
  resolution, perceived latency and streaming, abstention messaging,
  visible citations and explanations, waiting on long tasks), verifying them
  against evaluation with real users, and recording which architecture
  proxies an agent can still reason over. Use for UX, conversational design,
  "feels slow", abstention or refusal wording, citation display, user
  testing or usability review questions about an ASE design. Do not use for
  disability access and WCAG (use ase-perspective-accessibility) or for
  measured end-to-end latency budgets (use
  ase-perspective-performance-scalability).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Usability perspective

Load `ase-arch-sysml-foundations` first. Control (read-only, read with
`ase_perspective("Usability")`): `AseMethodology::UsabilityPerspective`. No
`AseCatalogue` entry exists yet.

## Definition

> "The ease with which people who interact with the system can work
> effectively" - `AseMethodology::UsabilityPerspective`, source
> viewpoints-and-perspectives.info/home/perspectives.

## No computable check - and why

The control carries `@Perspective { checks = ""; }` and `@ReviewOnly`:

> "Not derivable from an architecture model at all. For agentic systems it
> is measured by evaluation against real users, which is the
> measurable-not-provable half of the property taxonomy. Kept in the
> catalogue so its absence is a stated position rather than an oversight."

So: no ASE check will pass or fail usability, and `check_coverage` is
satisfied by the reason, not by coverage. Never report "usability: no
findings" as a result. What this skill produces instead is (a) usability
requirements with **measurable** targets, (b) `verification def`s that run
against **evaluation with users**, and (c) architecture **proxies** that
bound usability without proving it.

**Applicability.** R&W: significant human interaction or public exposure.
Every conversational agent qualifies; so does any agent whose operators
must read its traces.

**Concerns.** The control frames `OperationalVisibility`. R&W's list,
paraphrased: interface usability, business process flow, information
quality, fit with working practice and skills, perceived usability, ease of
changing the interface. Agentic concerns: conversational continuity,
perceived latency, abstention and refusal messaging, explanation and
citations, waiting on turnaround tasks, trust calibration (the user neither
over- nor under-trusts the answer), and recovery from a wrong answer.

**Stakeholders.** End users by type (RS-08: new hires chat, line managers
only receive plans - R&W's "single user type" pitfall), operators who read
traces, the product owner, and an HCI specialist R&W say to engage.

## Activities -> SysML

R&W: UI design, participatory design, interface evaluation, prototyping.

### 1. Name the user types and what they are trying to do

One `part def <User> :> AseMethodology::EndUser` per type with context in
`doc` (experience, device, task). Concerns in the users' words; specialise
a methodology concern when one fits (`PerceivedResponsiveness :>
LatencyBudget`), otherwise frame it from the requirement that answers it:

```
requirement def AbstentionGivesNextStep {
    doc /* Out-of-corpus: say so in one sentence and name who to ask. */
    frame concern next : KnowWhatToDoNext;
    attribute usersWhoKnewNextStep : Real = 0.9;
}
```

### 2. Turn each agentic UX quality into a measurable requirement

| Quality | Measurable target | Measured by |
|---|---|---|
| Conversational continuity | follow-up resolution accuracy (RS-08: >= 0.8) | replay of recorded conversations |
| Perceived latency | time to first visible token (p95) and to full reply | client instrumentation under load |
| Waiting on turnaround work | progress within 1 s; status cadence | instrumentation; test observation |
| Abstention messaging | share of users who knew the next step | moderated test with out-of-scope tasks |
| Explanation / citations | citations opened without help; citation recall | test observation; eval metric |
| Task effectiveness | task success rate over scripted tasks | moderated test, >= 8 participants |
| Trust calibration | users detect a seeded wrong answer | test with a planted error |
| Recovery | turns to correct a misunderstood question | replay / test |

Every target a number and a unit, or it cannot be verified. Name the
requirement after its concern where natural (`LatencyBudgetPerceived`) so
`evidence_generable` reaches it; otherwise use `frame`.

### 3. Verify against evaluation, not against the model

```
verification def ModeratedUsabilityTest {
    subject design : RS08::RS08Design;
    objective {
        verify requirement OnboardingTaskSuccess;
        verify requirement AbstentionGivesNextStep;
    }
    doc /* 8 new hires, 5 tasks incl. two out-of-corpus questions; think-aloud. */
}
```

Combine: offline replay (cheap, every iteration), instrumentation (every
load test), moderated tests (per release), and production signals (thumbs,
rephrase rate, abandonment) in the Operational view. Carry results back as
`@Finding` with the number and the dataset.

### 4. Prototype early, with the real model

Usability of an agent depends on what the model actually says. A wireframe
with lorem ipsum tests nothing; prototype on the walking skeleton with the
real synthesiser and real corpus, and test abstention wording before GEPA
optimises it away. When GEPA runs, add usability metrics to the
non-regression set, not only to the objective.

## What the model can still carry

| Support | SysML | What it enables |
|---|---|---|
| Measurable targets | requirement defs with attributes | a verdict per release from evaluation |
| Verification | `verification def` per requirement | `evidence_chain.py` coverage (Regulation skill) |
| Scenarios | `@QualityScenario` with a numeric measure | A2 utility tree, test script |
| Extension attributes | `userVisible : Boolean`, `streams : Boolean`, `workloadClass` on stage defs (`@Extension`) | would make "the stage producing user-visible text streams" and per-class budgets computable |
| Proxies | existing checks, see below | bounds, not proof |

`workloadClass` is the recorded `ResponseTimeClassGap`; RS-08 makes it real.

## Applying the perspective to each view

| View | What the perspective adds |
|---|---|
| Context | user types as stakeholders; the presenting surface (chat widget, email, API) as an external |
| Functional | abstention and refusal paths as stages with user-facing output contracts; rewriter for follow-ups |
| Information / Knowledge | answer item carries citations with human-readable titles; memory scope decides what users need to repeat |
| Concurrency | streaming; turnaround work in the background with progress events |
| Autonomy | what the user must confirm; how an agent asks for clarification instead of guessing |
| Operational | feedback capture, rephrase and abandonment metrics, conversation review |

## Analysis and proxies

| Question | Engine |
|---|---|
| Is the design usable? | none - review; evaluation with users |
| Can the reply arrive in the perceived budget? | `latency_budget` / `critical_path` as proxy (total, not perceived) |
| Is there an abstention path at all? | review of flows; a refusal output in the answer contract |
| Can every answer show a citation? | `citation_carriers`, `provenance_paths` (Groundedness) as proxy |
| Does a loop make the user wait unboundedly? | `bounded_cycles` (Drift) as proxy |

A proxy that passes proves only that the architecture does not *prevent*
the quality. A proxy that fails is a usability finding.

## Reasoning over the model

- **Walk the scenario over the flows.** Each step of a usability scenario
  should cross a declared flow; a step with no flow (e.g. "user sees
  progress") is a missing event path.
- **Correspondence.** Every requirement with a user-facing target has a
  verification that involves users or recorded user data:
  `@Correspondence { kind = "refines"; rule = "user-facing requirement verified by replay or moderated test"; }`.
- **What-if.** Moving a stage to the turnaround class changes what the user
  waits for; re-run the latency proxy per class.
- **Closed world.** Nothing here sees wording, layout or tone; say so.

## Tactics -> SysML change -> expected effect

| Tactic | Agentic form | SysML change | What should move |
|---|---|---|---|
| Separate UI from processing (R&W) | answer item is structured (text, citations, status); surface renders it | `item def Answer` with fields; surface as external | UI changes need no pipeline change |
| Asynchronous processing | stream tokens; background plan with progress | `workloadClass`, progress item | first-token time |
| Clarify rather than guess | ask a question when the query is ambiguous | clarification branch stage | fewer recovery turns |
| Honest abstention | abstain with next step | refusal output contract | next-step comprehension |
| Show sources | human-readable, openable citations | citation item carries title and link | citations opened |
| Remember context | memory stage, summarised history | memory stage in chat path | follow-up resolution |

## Pitfalls -> detection

| Pitfall (R&W, paraphrased; agentic) | Detection |
|---|---|
| Single user type assumed | one EndUser specialisation for a spec naming several |
| Over-complex interface / technology-driven design | no user task in any requirement doc |
| Ignoring other perspectives' effect | security or regulation gate adds steps with no usability requirement |
| Interface not separated from processing | answer item is free text only |
| Targets without numbers | requirement defs with no attribute |
| (agentic) "feels instant" read as total latency | only `latency_budget`; no first-token requirement |
| (agentic) abstention untested | no out-of-scope task in any verification def |
| (agentic) optimiser erodes UX | GEPA objective with no usability metric in non-regression |

## Checklist

User types named; usability concerns stated in user terms; each agentic UX
quality has a numeric target; each target verified by replay,
instrumentation or a moderated test; abstention and citation display
tested; proxies run and reported as proxies; `@ReviewOnly` reason quoted in
the AD; decision records the position.

## Output contract

In `ad/perspectives.sysml`: `satisfy AseMethodology::UsabilityPerspective
by <Design>;`; user types and concerns; measurable requirement defs, each
satisfied; verification defs against evaluation; `@QualityScenario`s; one
`@Finding` recording the review-only position and one per proxy result;
`@ArchitectureDecision` for each UX-driven change.

Validate: gate; `check_ad.py` with `// ad-check: perspectives=Usability`;
`ase-perspective-regulation/scripts/evidence_chain.py` for requirement ->
verification coverage. Worked RS-08 example: `references/example.sysml`.
