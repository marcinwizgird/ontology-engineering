---
name: ase-viewpoint-concurrency
description: >
  Build, analyse and review the Concurrency view of an agentic system in
  SysML v2 following the Rozanski & Woods Concurrency viewpoint - concurrency
  units (processes, task pools, rate limiters), the mapping of functional
  elements to them, inter-process communication, state models with
  termination, contention, deadlock, starvation and race conditions - with
  the agentic units first: fan-out width, loop iterations (maxIterations),
  parallel tool calls, async turnaround tasks. Use when asked what runs in
  parallel, how loops terminate, whether fan-out times iterations fits the
  budget, how a rate limit serialises work, or to review a concurrency
  model. Do not use for where units run (use ase-viewpoint-deployment) or for
  what a participant may do without approval (use ase-viewpoint-autonomy).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Concurrency viewpoint

Load `ase-arch-sysml-foundations` first. Control:
`AseMethodology::ConcurrencyViewpoint` - read with `ase_viewpoint("Concurrency")`
and `ase_obligations("Concurrency")`. (`ase_obligations` currently returns the
Functional required-attribute list for every viewpoint; for this view the
list is exactly right, because fan-out and `maxIterations` are the inputs.)

## Definition

> "Describes the concurrency structure of the system and maps functional
> elements to concurrency units" - `AseMethodology::ConcurrencyViewpoint`,
> source viewpoints-and-perspectives.info/home/viewpoints.

The methodology adds: for agentic systems the concurrency units are fan-out
width and loop iteration, and their product is the budget surprise.

**Stakeholders**: developers and testers first, communicators, and the SRE who
runs it (`SoftwareEngineer`, `SiteReliabilityEngineer`). **Applicability**
(R&W): systems with several concurrent threads of execution. Every agentic
system with a parallel retrieval, a multi-query fan-out, a tool-calling loop
or a critic loop qualifies; a single retrieve-then-generate chain
(NaiveRag) does not - record that as a decision and skip the view.

**Concerns**: ASE frames `ConcurrencyAndFanOut` (what runs in parallel, and
what does that multiply?) and `Termination` (does every loop stop, and does
it make progress?). R&W's concerns, to walk as a checklist: task structure;
mapping of elements to tasks; inter-process communication; state management;
synchronisation and integrity; supporting scalability; startup and shutdown;
task failure; reentrancy.

**Models**: the system-level concurrency model (processes, process groups,
threads, IPC) and the state model (states, transitions, events, actions).
The methodology's model string: "parallel branches, fan-out, cycles and their
bounds".

## R&W model elements -> SysML v2

| R&W element | SysML v2 | ASE convention |
|---|---|---|
| Process / process group | `part def U :> ConcurrencyUnit` with `kind`, `maxConcurrency`, `ipc` | a run's event loop, a worker pool, a queue consumer, a rate limiter |
| Thread | not modelled one by one; `maxConcurrency` on the unit, `fanOut` on the stage | one async task per fanned-out branch |
| Mapping element -> unit | `allocation def ElementToTask` + `allocation t : ElementToTask allocate <Design>::<stage> to runtime.<unit>;` | exactly one per stage |
| Parallel branches | two flows from one stage (design) + `fork` / `join` in an `action def` (view) | the analysis takes the maximum latency |
| Fan-out | `fanOut` on the stage def (design) | multiplies downstream cost, not latency |
| Loop | a back edge in the flows + `maxIterations` on the design part def | loop stages run `maxIterations` times |
| IPC mechanism | `ipc` attribute on the unit; `interface def` when the protocol matters | graph state, queue, HTTP, MCP |
| State model | `state def` with `entry`, `state`, `transition ... accept ... if ... then` | one per loop and per long-running task |
| Synchronisation | `join` node; guard on a transition; a single-writer unit | who writes shared agent state |
| Contention | a unit with `maxConcurrency` below demand; `calc def` over it | shared model API, news API, vector store |

Keep units, allocations, actions and states in `ad/concurrency.sysml`; the
design keeps only `fanOut`, `maxIterations` and flows, which the analysis reads.

## Activities -> SysML

1. **Model the process structure.** Name the units the runtime actually has.
   For a LangGraph or DSPy program: one coordinator loop per request (single
   writer of the graph state), a task pool for parallel branches, a limiter
   per rate-limited dependency, a background queue for turnaround work.

   ```
   part def ConcurrencyUnit {
       attribute kind : String;           // process | task-pool | limiter | external
       attribute maxConcurrency : Integer;
       attribute ipc : String;
   }
   part def ResearchPool :> ConcurrencyUnit {
       attribute redefines kind = "task-pool";
       attribute redefines maxConcurrency = 18;
   }
   ```
   Put every attribute on the base, redefine in the subtypes - `check_ad.py`
   treats any `part def X :> Y` with new attributes as a stage needing `@Extension`.
2. **Map elements to units.** One `ElementToTask` allocation per design
   usage. Check with the Deployment skill's script (below). An unmapped stage
   is concurrency nobody designed.
3. **Define IPC.** Per unit boundary: in-process call, shared graph state,
   queue, HTTP to a model API, MCP to a tool. Name the single writer of each
   shared state. Parallel tool calls inside one LLM turn are IPC too: the
   model emits N calls, the runtime runs them concurrently and joins -
   model it as a fanned-out tool stage, not as one call.
4. **Model the coordination.** For each parallel region write an `action def`
   with `fork` and `join`. State what the join waits for and what it does when
   a branch never returns (timeout -> partial result). A join with no timeout
   on an external branch is a deadlock waiting for an outage.

   ```
   fork researchFork;
   join researchJoin;
   first researchFork then researchNews;
   first researchNews then researchJoin;
   ```
5. **Model state and termination.** Every cycle gets a `state def` whose
   transitions carry the bound *and* the progress guard, and whose terminal
   states include a non-success exit:

   ```
   transition sendBack first reviewing accept v : CriticVerdict
       if v.deficits < lastDeficits and iteration < maxIterations then planning;
   ```
   (Shown wrapped; in the file keep each transition and each `filter` on one
   line - the gate is line-based and a continuation line fails it.)
   `maxIterations` on the design counts *executions*: "send back at most
   twice" is 3. Write the progress condition as a `constraint def` required
   by a `requirement def` and `satisfy` it by the loop's judging stage.
6. **Analyse contention.** For each limiter or shared endpoint, compare demand
   (fan-out x calls per branch x iterations per window) to capacity with a
   `calc def`. Rate limits turn parallel branches into waves.
7. **Walk failure, startup and shutdown.** What happens to in-flight branches
   when the run is cancelled, a branch raises, or the model API returns 429?
   One line each in the unit's `doc`; an unhandled case is a finding.
8. **Record decisions** on fan-out width, bound, pool size, and the tradeoff
   they make between recall, latency and cost (`@TradeoffPoint`).

## The view

```
view def ConcurrencyView {
    satisfy requirement vp : AseMethodology::ConcurrencyViewpoint;
    filter @SysML::PartUsage or @SysML::AllocationUsage or @SysML::ActionUsage or @SysML::StateUsage;
}
view processStructure : ConcurrencyView {
    expose RS09_Concurrency::runtime::**;
    render asInterconnectionDiagram;
}
view mapping : ConcurrencyView {
    expose RS09_Concurrency::*;
    render asElementTable;        // element -> unit -> ipc -> bound
}
```
Model kinds: units + allocations (system-level concurrency model), `action
def` with fork/join (coordination), `state def` (state model). Nodes, regions
and authority do not belong here.

## Analysis the concurrency model supports

| Question | Engine |
|---|---|
| Does every cycle carry a bound? | `bounded_cycles` (STRUCTURE, error) - back edges vs `maxIterations` |
| Is a stage multiplied by both fan-out and a loop? | `fanout_compounding` (warning) - a stage on a cycle whose direct upstream has `fanOut > 1` |
| Does every bounded loop make progress? | `progress_conditions` - **fires on every cycle, always** (see below) |
| Worst-case latency with parallelism | `latency_budget`, `critical_path` - assumptions below |
| Worst-case cost with fan-out and loops | `cost_budget`, `llm_call_count`, `cost_sensitivity` (+1 iteration) |
| Does a rate limit serialise the fan-out? | `calc def RateLimitedLatency` (view file); none in ASE |
| Cost when post-join stages run once | `calc def JoinAwareCost` (view file) |
| Every stage mapped to exactly one unit | `run_skill_script("ase-viewpoint-deployment", "allocation_coverage.py", stdin=design + concurrency)` with `// allocation-check: hosting=ElementToTask model= nodes=ConcurrencyUnit` |
| Deadlock, starvation, races | none - review over the state and action models |

**Assumptions of the ASE analysis** (state them in every finding): parallel
branches cost their sum and take their maximum; fanned-out work is concurrent,
so fan-out multiplies cost but not latency (unbounded pool, no rate limit);
a stage on a cycle runs `maxIterations` times; back edges are removed before
the critical path. **No join**: fan-out propagates to *every* downstream
stage, including those after the join - in RS-09 the synthesiser and critic
are counted six times (411,000 tokens reported vs 141,000 join-aware, on the
example's illustrative stub estimates). Report
both numbers; the ASE figure is a conservative upper bound.

**Why `progress_conditions` always fires.** It yields every back edge
unconditionally: no SysML construct is projected into the graph that could
declare a progress condition (`state def` and `constraint def` are not
projected). A bound stops an infinite loop; it does not stop livelock (the
critic returns the same deficits three times). Record it as
`@Finding { disposition = "accept"; }` citing the projection limit and
point to the `state def` guard and the progress `requirement def` that carry
the condition.

## Reasoning over the concurrency model

- *What multiplies what?* For each stage: fan-out product of its ancestors x
  (`maxIterations` if on a cycle). A stage whose multiplier exceeds 10 is the
  first place to look for cost.
- *What if the bound grows by one?* The `cost_sensitivity` what-if; for
  latency, rerun `explain` on a scratch copy with `maxIterations + 1`.
- *What serialises?* Any unit with `maxConcurrency` below the fan-out it
  receives; the effective latency is waves x per-call latency.
- *Can it deadlock?* Build the wait-for relation from the action model: a
  join waiting on a branch that waits (through a shared limiter or a nested
  agent) on the joiner. Mutual delegation between agents is the agentic form.
- Closed world: the analysis sees only declared flows. Parallel tool calls
  hidden inside one stage, retries inside a client library, and streaming
  are invisible unless modelled - say which were not.
- Correspondences (`@Correspondence`): every design usage has one
  `ElementToTask` (Functional); every non-success terminal state is an
  escalation state (Autonomy); every limiter corresponds to a rate limit on a
  Deployment node; every unit has a telemetry signal (Operational).

## Pitfalls -> detection in the model

| Pitfall | Detection |
|---|---|
| Modelling the wrong concurrency | units named after code modules, not runtime units; no limiter where the Deployment view shows a rate limit |
| Modelling the concurrency wrongly | fork/join action disagrees with the design flows; parallel branches drawn as a chain |
| Excessive complexity | more units than distinct runtime mechanisms; threads modelled one by one |
| Resource contention | demand > `maxConcurrency` or rate limit (`RateLimitedLatency`) |
| Deadlock | a join with no timeout on an external branch; cyclic wait-for in the action model |
| Race conditions | two units writing one state; no single writer named in `ipc` |
| (agentic) unbounded loop | `bounded_cycles` |
| (agentic) livelock | loop state def without a progress guard; `progress_conditions` accepted with no guard to point to |
| (agentic) loop x fan-out | `fanout_compounding` |
| (agentic) off-by-one bound | "returns at most N" encoded as `maxIterations = N` |
| (agentic) hidden parallel tool calls | a tool-calling stage with `fanOut = 1` whose prompt allows several calls per turn |
| (agentic) turnaround work in the interactive path | a minutes-long stage on the critical path of an interactive budget; needs `workloadClass` (`ResponseTimeClassGap`) |
| (agentic) starvation | interactive and batch work sharing one limiter with no priority |

## Checklist

Every concurrency unit named with its kind, capacity and IPC; every stage
mapped to exactly one unit; every parallel region has a fork, a join and a
timeout; every cycle has a bound, a progress guard and a non-success exit;
shared state has one writer; every rate-limited dependency has a limiter and
a demand calc; startup, shutdown, cancellation and branch failure stated;
reentrancy of shared clients stated; analysis assumptions listed; the join
overcount reported; decisions record fan-out, bound and pool size.

## Output contract

`ad/concurrency.sysml` containing: `ConcurrencyUnit` hierarchy and a runtime
part; `ElementToTask` allocations; one `action def` per parallel region; one
`state def` per loop; progress `constraint def` + `requirement def` with
`satisfy`; rate-limit and join-aware `calc def`s; `@Assumption` list;
`@Finding` per check with disposition; `@Correspondence`; decisions.
Updates to `design.sysml`: `fanOut` on each fanning stage, `maxIterations` on
each design with a cycle.

Validate (from `AI Skills/skills`):

```
python description-to-sysmlv2/scripts/check_model.py < ad/concurrency.sysml
python ase-arch-sysml-foundations/scripts/check_ad.py < ad/concurrency.sysml   # fragment directive
cat design.sysml ad/concurrency.sysml | python ase-viewpoint-deployment/scripts/allocation_coverage.py
python -m sysmlagents.cli explain RS-09      # from ASE Agentic System
```
Worked example: `references/example.sysml` (RS-09, fan-out 6 x 3 sources,
critic loop of 3 passes, news limiter).
