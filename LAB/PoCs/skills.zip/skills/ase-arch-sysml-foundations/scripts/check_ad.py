#!/usr/bin/env python3
"""Tier-3 checker: completeness of an ASE architecture description (AD).

Reads the AD's SysML v2 files concatenated on stdin (design + views +
perspectives + decisions) and reports what the AD fails to carry. It is a
text-level checker over the constructs the ASE series prescribes; it does not
parse SysML and does not replace the structural gate (check_model.py in
description-to-sysmlv2), which must run first.

Scope directive, optional, anywhere in the input:

    // ad-check: viewpoints=Context,Functional perspectives=Security,Cost

Scoped viewpoints/perspectives that are missing are errors; without a
directive every catalogue entry is expected and missing ones are warnings.
Add the word `fragment` to the directive when checking one view or
perspective file on its own: AD-wide checks (stakeholders, scenarios,
decision presence, attributes declared in design.sysml) are then relaxed.

Checks
    stakeholders   some stakeholder is declared
    concerns       every design concern names a stakeholder and is framed
                   or specialises a methodology concern
    viewpoints     a view def satisfies each expected viewpoint, and a view
                   usage of it exposes something
    perspectives   each expected perspective is allocated (satisfy ... by)
                   or explicitly set aside in an @ArchitectureDecision
    attributes     an applied perspective's required attributes are declared
    extensions     every non-vocabulary stage attribute sits in a def that
                   carries @Extension with a reason
    decisions      every @ArchitectureDecision has its mandatory fields
    scenarios      every @QualityScenario has all six parts and a
                   response measure containing a number
    findings       accepted / waived findings name the decision behind them

Exit 0 when there are no errors (warnings allowed), 1 otherwise.
"""

import re
import sys

VIEWPOINTS = ["Context", "Functional", "Information", "Concurrency",
              "Development", "Deployment", "Operational",
              "Knowledge", "Autonomy"]

PERSPECTIVES = ["Security", "PerformanceAndScalability",
                "AvailabilityAndResilience", "Evolution", "Regulation",
                "DevelopmentResource", "Location", "Usability",
                "Accessibility", "Internationalization",
                "Cost", "Groundedness", "Drift"]

# attributes a perspective needs in order to compute rather than degrade
# to review - mirrors the checks in sysmlagents.checks
REQUIRED = {
    "PerformanceAndScalability": ["latencyMs", "llmCalls", "fanOut", "maxIterations"],
    "Cost": ["costTokens", "llmCalls", "maxIterations"],
    "Security": ["trustLevel", "dataClass"],
    "AvailabilityAndResilience": ["hasFallback"],
    "Groundedness": ["preservesProvenance"],
    "Drift": ["maxIterations"],
    "Location": ["region"],
}

VOCABULARY = {"llmCalls", "latencyMs", "costTokens", "fanOut",
              "preservesProvenance", "hasFallback", "trustLevel", "dataClass"}

SCENARIO_PARTS = ["source", "stimulus", "artifact", "environment",
                  "response", "responseMeasure"]
DECISION_FIELDS = ["id", "status", "owner", "rationale", "alternatives", "affects"]

ALIASES = {"Internationalisation": "Internationalization",
           "Performance": "PerformanceAndScalability",
           "Availability": "AvailabilityAndResilience"}


def strip(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"//[^\n]*", " ", text)


def blocks(text, header_re):
    """Yield (name, body) for each brace block whose header matches."""
    for m in re.finditer(header_re, text):
        i = text.find("{", m.end() - 1)
        if i < 0 or text[m.end():i].count(";"):
            continue
        depth, j = 0, i
        while j < len(text):
            if text[j] == "{":
                depth += 1
            elif text[j] == "}":
                depth -= 1
                if depth == 0:
                    break
            j += 1
        yield m.group(1), text[i + 1:j]


def metadata(text, name):
    """Yield dicts of the string fields of each @<name> { ... } usage."""
    for m in re.finditer(r"@(?:\w+::)*" + name + r"\s*\{(.*?)\}", text, re.S):
        yield dict(re.findall(r"(\w+)\s*=\s*\"(.*?)\"\s*;", m.group(1), re.S))


def scope(raw):
    m = re.search(r"//\s*ad-check:([^\n]*)", raw)
    if not m:
        return None, None
    vps = re.search(r"viewpoints=([\w,]*)", m.group(1))
    pps = re.search(r"perspectives=([\w,]*)", m.group(1))
    norm = lambda s: [ALIASES.get(x, x) for x in s.split(",") if x]
    return (norm(vps.group(1)) if vps else [],
            norm(pps.group(1)) if pps else [])


def main():
    raw = sys.stdin.read()
    text = strip(raw)
    errors, warnings, info = [], [], []
    vp_scope, pp_scope = scope(raw)
    strict_vp, strict_pp = vp_scope is not None, pp_scope is not None
    fragment = bool(re.search(r"//\s*ad-check:[^\n]*\bfragment\b", raw))
    vp_expected = vp_scope if strict_vp else VIEWPOINTS
    pp_expected = pp_scope if strict_pp else PERSPECTIVES

    # -- stakeholders ------------------------------------------------------
    if not fragment and not re.search(r"\bstakeholder\s+\w+\s*:", text) and \
            not re.search(r"part\s+def\s+\w+\s*:>\s*(?:\w+::)*\w*(Stakeholder|Engineer|Owner|Officer|Architect|User|Lead)\b", text):
        errors.append("stakeholders: none declared - A1 needs named stakeholders holding concerns")

    # -- concerns ----------------------------------------------------------
    framed = set(re.findall(r"\bframe\s+(?:concern\s+\w+\s*:\s*)?(?:\w+::)*(\w+)", text))
    for name, body in blocks(text, r"\bconcern\s+def\s+(\w+)[^;{]*"):
        header = re.search(r"concern\s+def\s+" + name + r"([^;{]*)", text).group(1)
        if "stakeholder" not in body:
            warnings.append(f"concern {name}: names no stakeholder")
        if ":>" not in header and name not in framed:
            warnings.append(f"concern {name}: neither specialises a methodology "
                            "concern nor is framed - nothing addresses it")

    # -- viewpoints --------------------------------------------------------
    satisfied = {}
    for vdef, body in blocks(text, r"\bview\s+def\s+(\w+)[^;{]*"):
        for vp in re.findall(r"satisfy\s+(?:requirement\s+)?\w+\s*:\s*(?:\w+::)*(\w+)Viewpoint", body):
            satisfied.setdefault(vp, []).append(vdef)
    usages = {}
    for uname, body in blocks(text, r"\bview\s+(\w+)\s*:\s*(?:\w+::)*\w+[^;{]*"):
        vtype = re.search(r"\bview\s+" + uname + r"\s*:\s*(?:\w+::)*(\w+)", text).group(1)
        usages.setdefault(vtype, []).append((uname, "expose" in body))
    for vp in vp_expected:
        if vp not in satisfied:
            (errors if strict_vp else warnings).append(
                f"viewpoint {vp}: no view def satisfies {vp}Viewpoint")
            continue
        for vdef in satisfied[vp]:
            if vdef not in usages:
                errors.append(f"view def {vdef}: no view usage - the view is defined but never produced")
            for uname, exposes in usages.get(vdef, []):
                if not exposes:
                    errors.append(f"view {uname}: exposes nothing - it is empty whatever its filter says")

    # -- decisions ---------------------------------------------------------
    decisions = list(metadata(text, "ArchitectureDecision"))
    set_aside = " ".join((d.get("affects", "") + " " + d.get("decision", "")) for d in decisions)
    for d in decisions:
        missing = [f for f in DECISION_FIELDS if not d.get(f, "").strip()]
        if missing:
            warnings.append(f"decision {d.get('id', '?')}: missing {', '.join(missing)}")
    if not decisions and not fragment:
        warnings.append("decisions: no @ArchitectureDecision - every choice needs a record")

    # -- perspectives ------------------------------------------------------
    allocated = set(re.findall(r"satisfy\s+(?:requirement\s+)?(?:\w+::)*(\w+)Perspective\s+by", text))
    declared_attrs = set(re.findall(r"\battribute\s+(?:redefines\s+)?(\w+)", text))
    for pp in pp_expected:
        if pp in allocated:
            need = [a for a in REQUIRED.get(pp, []) if a not in declared_attrs]
            if need:
                (info if fragment else warnings).append(f"perspective {pp}: applied but cannot compute - "
                                f"missing attribute(s) {', '.join(need)}")
        elif pp + "Perspective" in set_aside or pp in set_aside:
            info.append(f"perspective {pp}: set aside by decision")
        else:
            (errors if strict_pp else warnings).append(
                f"perspective {pp}: neither allocated (satisfy ... by) nor set aside by a decision")

    # -- extensions --------------------------------------------------------
    for name, body in blocks(raw, r"\bpart\s+def\s+(\w+)\s*:>[^;{]*"):
        own = re.findall(r"\battribute\s+(\w+)\s*:", strip(body))
        extra = [a for a in own if a not in VOCABULARY and a != "maxIterations"]
        if not extra:
            continue
        ext = list(metadata(body, "Extension"))
        if not ext or not any(e.get("reason", "").strip() for e in ext):
            warnings.append(f"stage {name}: non-vocabulary attribute(s) {', '.join(extra)} "
                            "without @Extension and a reason")

    for e in metadata(text, "Extension"):
        if not e.get("reason", "").strip():
            errors.append("an @Extension has no reason - indistinguishable from a misreading")

    # -- scenarios ---------------------------------------------------------
    scenarios = list(metadata(text, "QualityScenario"))
    for s in scenarios:
        sid = s.get("id", "?")
        missing = [p for p in SCENARIO_PARTS if not s.get(p, "").strip()]
        if missing:
            warnings.append(f"scenario {sid}: missing {', '.join(missing)}")
        # a percentile label (p95) says where to measure, not what - it is
        # not a number the response can be tested against
        elif not re.search(r"\d", re.sub(r"\bp\d{2,3}\b", " ", s["responseMeasure"])):
            warnings.append(f"scenario {sid}: response measure has no number - not testable")
    if not scenarios and not fragment:
        warnings.append("scenarios: no @QualityScenario - A2 output missing")

    # -- findings ----------------------------------------------------------
    for f in metadata(text, "Finding"):
        if f.get("disposition") in ("accept", "waive") and not f.get("decision", "").strip():
            warnings.append(f"finding {f.get('check', '?')}: {f['disposition']}ed without a decision id")

    # -- report ------------------------------------------------------------
    vp_have = sorted(set(satisfied) & set(VIEWPOINTS))
    summary = (f"viewpoints {len(vp_have)}/{len(vp_expected)} "
               f"perspectives allocated {len(allocated & set(pp_expected))}/{len(pp_expected)} "
               f"decisions {len(decisions)} scenarios {len(scenarios)}")
    head = "FAIL" if errors else ("OK with warnings" if warnings else "OK")
    print(f"{head} - {summary}")
    for tag, items in (("error", errors), ("warning", warnings), ("info", info)):
        for i in items:
            print(f"  - {tag}: {i}")
    print("note: text-level completeness check; run check_model.py first for well-formedness")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
