# SysML v2 idioms for architecture description

Exact syntax for every construct the ASE viewpoint and perspective skills
use. Basic constructs (part, port, item, flow, action, state, constraint,
requirement, verification) are in `description-to-sysmlv2/references/constructs.md`;
this file adds the architecture-specific ones. Copy the shape; do not
improvise keywords.

Legend: **[gate]** = the builtin gate and `model_reader` both handle it;
**[view]** = gate-valid, ignored by `model_reader` - keep it out of
`design.sysml`.

## 1. Stakeholders and concerns [view]

```
part def HrOperationsLead :> AseMethodology::ProductOwner {
    doc /* Owns RS-01; accepts the architecture in A6. */
}

concern def PolicyCitations :> AseMethodology::AnswerGroundedness {
    doc /* Every answer names the policy document and section. (RS-01 FR-2) */
    stakeholder owner : HrOperationsLead;
    stakeholder user : AseMethodology::EndUser;
}
```

Specialise a methodology concern whenever one fits - that is what lets
`concern_coverage` and `ase_concern` see the new concern as framed.

## 2. Viewpoint, view definition, view [view]

```
view def FunctionalView {
    satisfy requirement vp : AseMethodology::FunctionalViewpoint;
    filter @SysML::PartUsage or @SysML::FlowUsage or @SysML::PortUsage;
}

view functional : FunctionalView {
    expose RS01::RS01Design::**;     // ** = recursively
    render asInterconnectionDiagram;
}
```

Standard renderings (`Views` library): `asTreeDiagram`,
`asInterconnectionDiagram`, `asElementTable`, `asTextualNotation`. A custom
rendering: `rendering def asSequenceDiagram;`.

Filters take metaclass tests (`@SysML::ActionUsage`) and metadata tests
(`@AseAdKit::Tactic`), combined with `and` / `or` / `not`.

## 3. Use cases and actors (Context, Functional scenarios) [view]

```
use case def AskPolicyQuestion {
    subject assistant : RS01::RS01Design;
    actor employee : Employee;
    actor corpus : PolicyStore;
    objective {
        doc /* Employee gets a cited answer, or an explicit abstention. */
    }
    include use case retrieve : RetrievePolicy;
}
```

## 4. Allocation (Deployment, Concurrency, Development) [view]

```
allocation def StageToNode {
    end stage : RS01::Stage;
    end node : ComputeNode;
}

allocation synthOnApi : StageToNode
    allocate RS01::RS01Design::synth to deployment::modelApi;
```

Short form inside a part: `allocate synth to modelApi;`.

## 5. Individuals and snapshots (Deployment instances, Operational states) [view]

```
individual part def ProdEuWest :> ComputeNode;
individual part prodEuWest : ProdEuWest {
    snapshot part atPeak {
        attribute concurrentUsers : Integer = 50;
    }
}
```

## 6. Variation - architectural options (A5) [view]

```
variation part def RetrievalOption :> RS01::Stage {
    variant part denseOnly : RS01::DenseRetriever;
    variant part hybrid : HybridRetrieval;
}
```

Use for design-space exploration only; the accepted design in
`design.sysml` is always a plain, variant-free part def (the reader cannot
resolve variants).

## 7. Calculations and constraints (analysis) [gate]

```
calc def WorstCaseCost {
    in perStage : Integer[*];
    in iterations : Integer;
    return : Integer = sum(perStage) * iterations;
}

constraint def WithinBudget {
    in actual : Integer;
    in budget : Integer;
    actual <= budget
}

requirement def CostBudget {
    attribute budgetTokens : Integer = 5000;
    attribute worstCaseTokens : Integer;
    require constraint : WithinBudget {
        in actual = worstCaseTokens;
        in budget = budgetTokens;
    }
}
```

In ASE, `worstCaseTokens` is filled by the delegate (`sysmlagents.analysis`),
not by evaluating `calc def` - the calc states the formula so a reviewer can
check the delegate against it.

## 8. Analysis case (what is computed) [view]

```
analysis def PeakLoadAnalysis {
    subject design : RS01::RS01Design;
    in attribute concurrentUsers : Integer = 50;
    objective {
        doc /* Does worst-case latency hold at 50 concurrent users, assuming
             the model API rate limit of 500 RPM? */
    }
    return attribute p95LatencyMs : Integer;
}
```

Every `analysis def` names its delegate in `doc` or in an `@Finding` that
carries its result.

## 9. Trade study (option selection) [view]

```
import TradeStudies::*;

// shape follows the OMG SysML v2 TradeStudyExample
analysis retrievalTrade : TradeStudy {
    subject : RetrievalOption = (naive, hybrid);
    objective : MaximizeObjective;
    calc :>> evaluationFunction {
        in part option :>> alternative : RetrievalOption;
        return :>> result : Real;     // weighted utility, computed by delegate
    }
    return part :>> selectedAlternative : RetrievalOption;
}
```

If the pilot `TradeStudies` library is unavailable to the gate, fall back to
a plain `analysis def` with one `in` per alternative and an
`@ArchitectureDecision` recording the choice.

## 10. Verification [view]

```
verification def LatencyUnderPeak {
    subject design : RS01::RS01Design;
    objective {
        verify requirement RS01::LatencyBudget;
    }
    doc /* Method: load test at 50 concurrent users, 30 min, p100 latency. */
}
```

## 11. Metadata usage [gate]

```
part def WebSearchFallback :> Stage {
    @AseAdKit::Tactic {
        name = "Degrade gracefully";
        source = "R&W ch27";
        perspective = "AvailabilityAndResiliencePerspective";
    }
    attribute redefines hasFallback = true;
}
```

Extension attributes:

```
part def DenseRetriever :> Stage {
    @AseProfile::Extension {
        reason = "Location perspective needs residency to compute; vocabulary lacks it.";
        extends = "Stage vocabulary (RagPatterns::Stage)";
    }
    attribute region : String = "eu-west";
}
```

## 12. States (lifecycle, operating modes, escalation) [view]

```
state def OperatingMode {
    entry; then normal;
    state normal;
    state degraded;
    state maintenance;
    transition first normal accept ModelApiDown then degraded;
    transition first degraded accept ModelApiUp then normal;
}
```

## 13. The unallocated marker [gate]

```
// UNALLOCATED GroundedAnswer - the hypothetical document has no source
```

Exact form: `// UNALLOCATED <RequirementName>` then a reason.
`requirement_traceability` reads it; any other wording is invisible.

## Traps specific to architecture models

- The builtin gate is line-based: a `doc /* ... */` that spans lines must
  open on its own line inside the body, never after `{` on the same line as
  `require constraint {`.
- Keep a `filter` expression on one line; the builtin gate rejects a
  continuation line starting with `or`.
- Every `requirement def` in a file needs a `satisfy` or a
  `// UNALLOCATED <Name> - reason` marker, including interface contracts and
  requirements added by a view.
- `expose` names *usages or packages*; exposing a `def` exposes the
  definition, not its instances in the design.
- A view with no `expose` is empty whatever its `filter` says.
- `satisfy requirement vp : V;` belongs in the `view def`, not in the `view`.
- Keep ISQ quantities (`import ISQ::*; attribute t : DurationValue = 3 [SI::s];`)
  out of `design.sysml`: the checks read plain `Integer` `latencyMs` /
  `costTokens`. Use ISQ in view files if a stakeholder needs units shown.
