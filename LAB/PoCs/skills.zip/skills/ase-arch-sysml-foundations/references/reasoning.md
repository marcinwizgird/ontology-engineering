# Reasoning over an ASE architecture model

What the projected graph can conclude, what it cannot, and which tool to ask.

## 1. The projection

`sysmlagents.kg` / `lpg.project_lpg` turn the methodology and a design into a
labelled property graph. The node kinds actually projected today:

| Node | From | Key properties |
|---|---|---|
| `Stakeholder` | `part def S :> Stakeholder` | name |
| `Concern` | `concern def` | name, doc |
| `Viewpoint` | `viewpoint def` | name, origin, models, definition |
| `Perspective` | `requirement def` with `@Perspective` | name, origin, checks |
| `Check` | each id in `@Perspective.checks` | name |
| `Requirement` | `requirement def` in the design | name |
| `StageDef` | `part def X :> Stage` | every declared / redefined attribute |
| `Pattern` | the design `part def` (the one with parts and flows) | name, maxIterations, provenance |
| `Stage` | `part u : X` inside a pattern | type, pattern, resolved attributes |

Edges: `HOLDS` (stakeholder -> concern), `FRAMES` (viewpoint/perspective ->
concern), `DECLARES` (perspective -> check), `CONTAINS` (pattern -> stage),
`FLOWS_TO` (stage -> stage, `back_edge` flagged), `SATISFIES`, `UNALLOCATED`.

**Not projected** (so nothing can reason over them yet): views, `expose`,
`use case`, `state def`, `allocation`, `verification def`, `@ArchitectureDecision`
and the other AD-kit metadata, and any "Gate". Consequences you must state
when reporting:

- `verification_coverage` fires on every design - no `Verification` node is
  ever built, even when the model contains a `verification def`.
- `envelope_gate` fires on every design - no `Gate` node is ever built.
- `progress_conditions` fires on every cycle - there is no construct to
  declare a progress condition.

- **Only one external kind.** `checks.EXTERNAL_KINDS = {"WebSearchFallback"}`,
  and a stage's `type` is the def its usage names *directly* - not what that
  def specialises. Model providers, MCP / email / HTTP tools and even
  subtypes of `WebSearchFallback` are invisible to `data_exposure`,
  `sandbox_consistency`, `tool_authorisation` and `high_risk_classification`.
  A clean result on those checks says nothing about such boundaries; record
  each such crossing as a decision.
- **No declassification.** Reachability is transitive: a restricted stage
  upstream of an anonymiser still "reaches" the external sink through it,
  so `data_exposure` fires even when the design is correct. Accept it with a
  decision naming the anonymiser; a `declassifies` attribute is a roadmap item.
- **`provenance_paths` cannot see two cases**: a provenance-breaking stage
  that is itself the output, and any pattern whose output sits on a cycle
  (SelfRag, AgenticRag have no stage without an outgoing flow). Use
  `ase-perspective-groundedness`'s `provenance_trace.py` for those.
- **Checks narrower than their question**: `unsourced_stages` tests only "no
  inbound flow"; `citation_carriers` matches item *names*; `dangling_exits`
  flags only fully isolated stages; `bounded_cycles` tests that
  `maxIterations` exists, not its value; `cost_sensitivity` varies iterations,
  never fan-out.
- **Cost has no join.** Fan-out multiplies the cost of *every* downstream
  stage, including those after the fan-in, so a synthesiser after a
  4-way fan-out is counted four times. Report cost verdicts on fanned-out
  designs as conservative upper bounds.
- **Check ids use short perspective names** in the registry
  (`PerformancePerspective`, `AvailabilityPerspective`) where the methodology
  says `PerformanceAndScalabilityPerspective`,
  `AvailabilityAndResiliencePerspective`. In `@Finding.perspective` use the
  methodology name.
- **CORPUS checks need a corpus.** `cli explain` runs one design, so
  `duplicate_capability` is silent there by construction; run them over
  `kg.project_corpus([...])` + `registry.run` as `selftest.py` does.
- **`cli explain` reads `design.sysml` only.** Item defs that `citation_carriers`
  needs (names containing chunk / citation) must be there, not in a view file.

Record these as `@Finding { disposition = "accept"; ... }` citing the
projection limit, and use `check_ad.py` (text-level) for AD-kit elements.

## 2. Check catalogue by perspective

Kind decides what a result means.

| Perspective | Check | Kind | Severity | Reads |
|---|---|---|---|---|
| Performance & Scalability | `latency_budget` | QUANTITY | error | `latencyMs`, flows, `maxIterations`, `LatencyBudget.budgetMs` |
| | `critical_path` | QUANTITY | info | `latencyMs`, flows |
| | `fanout_compounding` | STRUCTURE | warning | `fanOut`, back edges |
| Cost (ext) | `cost_budget` | QUANTITY | error | `costTokens`, `fanOut`, `maxIterations`, `CostBudget.budgetTokens` |
| | `llm_call_count` | QUANTITY | warning | `llmCalls` |
| | `cost_sensitivity` | QUANTITY | info | +1 iteration what-if |
| Security | `trust_escalation` | REACHABILITY | error | `trustLevel`, flows |
| | `data_exposure` | REACHABILITY | error | `dataClass` in {restricted, pii, regulated, secret}, external stage types |
| | `sandbox_consistency` | CLASSIFICATION | error | `trustLevel == 0` on an external stage |
| | `tool_authorisation` | REACHABILITY | warning | `trustLevel` of callers of external stages |
| | `trust_declared` | ABSENCE | warning | `trustLevel` present |
| Availability & Resilience | `articulation_points` | STRUCTURE | warning | flows |
| | `minimum_cut` | STRUCTURE | warning | flows |
| | `cascade_depth` | REACHABILITY | info | forward flows |
| | `fallback_coverage` | ABSENCE | warning | `hasFallback` |
| Groundedness (ext) | `provenance_paths` | REACHABILITY | error | `preservesProvenance` |
| | `unsourced_stages` | STRUCTURE | warning | `llmCalls`, inbound flows |
| | `citation_carriers` | ABSENCE | warning | an `item def` named *chunk* / *citation* |
| Drift (ext) | `bounded_cycles` | STRUCTURE | error | back edges, `maxIterations` |
| | `progress_conditions` | ABSENCE | warning | (always fires - see 1) |
| | `envelope_gate` | ABSENCE | warning | (always fires - see 1) |
| Evolution | `orphan_stages`, `dangling_exits` | STRUCTURE | error / warning | flows |
| | `vocabulary_conformance` | CLASSIFICATION | warning | attributes outside the agreed eight |
| | `duplicate_capability`, `variation_rules` | CORPUS | info | stage defs across designs |
| Regulation | `requirement_traceability` | ABSENCE | error | `satisfy`, `// UNALLOCATED X` |
| | `concern_coverage` | ABSENCE | error | `FRAMES` |
| | `check_coverage` | ABSENCE | warning | `DECLARES` or `@ReviewOnly` |
| | `verification_coverage` | ABSENCE | warning | (always fires - see 1) |
| | `orphan_stakeholder`, `evidence_generable` | ABSENCE | info | `HOLDS`, requirement/concern names |
| | `high_risk_classification` | CLASSIFICATION | info | loop + external + ungrounded |
| Development Resource | `build_surface` | CORPUS | info | distinct stage defs |
| Location, Usability, Accessibility, Internationalisation | none | - | - | `@ReviewOnly` with reason |

The agreed stage vocabulary is exactly: `llmCalls`, `latencyMs`,
`costTokens`, `fanOut`, `preservesProvenance`, `hasFallback`, `trustLevel`,
`dataClass`. Any other attribute on a stage def trips
`vocabulary_conformance` - which is correct for an `@Extension` attribute:
the warning is how the extension stays visible. Accept it with a decision
that names the roadmap item.

## 3. Open world vs closed world

| Kind | Reading | What a clean result means |
|---|---|---|
| QUANTITY | arithmetic over declared estimates | "within budget *if* the estimates hold" |
| REACHABILITY | traversal over declared flows | "no declared path" - an undeclared flow is invisible |
| ABSENCE | closed-world | "the model does not declare it" - never "it does not exist" |
| STRUCTURE | graph shape | exact for the declared graph |
| CLASSIFICATION | definitional | exact for declared attributes |
| CORPUS | across designs | depends on which designs are loaded |

Rule: every clean verdict you report names the attributes and flows it rests
on. "No data exposure" on a design with no `dataClass` declared is not a
finding; it is a missing input - report it as a gap (`ase_gap`).

## 4. Tools and when to use them

| Need | Tool |
|---|---|
| Start an activity: aims, inputs, controls, outputs, agent | `ase_step("A4")` |
| What governs this step (must obey) | `ase_controls("A5")` |
| Viewpoint definition, concerns, models, pitfalls | `ase_viewpoint("Functional")` |
| Perspective quality, tactics, pitfalls, checks | `ase_perspective("Performance")` |
| Who holds a concern and what frames it | `ase_concern("LatencyBudget")` |
| What a conforming view must carry | `ase_obligations("Functional")` |
| Attributes a design fails to declare | `ase_gap("designs/RS-01/design.sysml")` |
| Cite a methodology claim | `ase_provenance("PerformanceOnFunctional")` |
| Run analysis + all checks on a design | `python -m sysmlagents.cli explain RS-01` |
| Compare patterns / options numerically | `compare(analyse())`, `conformance(analyse())` |

There is deliberately no Cypher tool: the typed tools are the query surface.

## 5. Reasoning patterns every view can use

1. **Obligation -> gap.** `ase_obligations(vp)` lists what the view must
   carry; `ase_gap(design)` lists what the design lacks. The difference is the
   elicitation list for A1/A8, not something to invent.
2. **Concern -> evidence chain.** stakeholder HOLDS concern, FRAMED by
   viewpoint/perspective, perspective DECLARES check, check covers requirement,
   requirement SATISFIED by element. A break anywhere is a Regulation finding.
3. **What-if.** Copy the design into a scratch variant, change one parameter
   (an iteration bound, a fan-out, a stage), re-run `explain`. A verdict that
   flips on one plausible change is a sensitivity point - record it.
4. **Cross-view correspondence.** Every functional stage should be deployed
   somewhere (Deployment), own or consume declared items (Information), sit
   in a concurrency unit (Concurrency), and have an authority level (Autonomy).
   Express each as `@Correspondence` with a rule; check the rule by listing
   stages absent from the other view.
