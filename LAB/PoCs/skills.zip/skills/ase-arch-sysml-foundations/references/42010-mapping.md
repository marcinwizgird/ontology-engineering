# ISO/IEC/IEEE 42010 - Rozanski & Woods - SysML v2 - ASE

One row per concept. The SysML v2 column is what you write; the ASE column is
where the concept already lives (read-only) or where a design puts it.

| 42010 term | R&W term | SysML v2 construct | ASE location / rule |
|---|---|---|---|
| System of interest | system | `part def <System>` | the design part def in `design.sysml` (e.g. `RS01Design`) |
| Environment | context, external entities | `part def` outside the system, connected by `port` / `interface`; `actor` in a `use case def` | Context view |
| Stakeholder | stakeholder | `part def S :> Stakeholder`; `stakeholder s : S;` inside a concern | `AseMethodology` stakeholders; design adds specific roles in `ad/00-stakeholders.sysml` |
| Concern | concern | `concern def C { stakeholder s : S; }` | `AseMethodology` / `AseCatalogue`; a design adds spec-specific concerns, each specialising (`:>`) a methodology concern where one fits |
| Architecture viewpoint | viewpoint | `viewpoint def V { frame C; }` | `AseMethodology` - **control, never edited** |
| Model kind | model (e.g. functional structure model) | `view def` with `filter` naming the element kinds; `rendering def` | the viewpoint skill names the model kinds and their filters |
| Architecture view | view | `view v : VDef { expose ...; render ...; }` | `ad/<viewpoint>.sysml` |
| Architecture model | model | the exposed elements (`part def`, `action def`, `state def`, ...) | `design.sysml` + view packages |
| Perspective (R&W, not in 42010) | perspective | `requirement def P` framing concerns, with `@Perspective` / `@PerspectiveSpec` metadata | `AseMethodology` - control; the design allocates with `satisfy P by <design>` |
| Correspondence | cross-view consistency | `@Correspondence` metadata; `allocation`; `satisfy` | `ad/*.sysml`, checked by the owning viewpoint skill |
| Correspondence rule | consistency rule | `constraint def` or a check in `sysmlagents.checks` | named in `@Correspondence.rule` |
| Architecture decision | architectural decision | `@ArchitectureDecision` on the element decided | `ad/decisions.sysml` |
| Rationale | rationale | `ArchitectureDecision.rationale`, `doc` | - |
| Architecture description | AD | the `designs/<RS-xx>/` folder | produced by A4, refined by A5/A7 |
| Scenario (SEI; R&W ch10) | architectural scenario | `@QualityScenario` / `@FunctionalScenario` on a `use case def` or `requirement def` | `ad/00-stakeholders.sysml` (A2) |
| Tactic (SEI; R&W perspective) | tactic | `@Tactic` on the element realising it | per perspective skill |
| Quality requirement | quality property requirement | `requirement def` with `attribute` target and `require constraint` | `design.sysml` (budgets) |
| Verification | assessment / testing | `verification def` with `objective { verify R; }` | `verification_coverage` check reads this |
| Analysis | model analysis | `analysis def` / `calc def`; computation delegated | `sysmlagents.analysis` |
| Trade-off | option exploration | `analysis` typed by `TradeStudies::TradeStudy`, or `variation` / `variant` | `ase-arch-evaluation` |

## Two ASE departures, stated

1. **Perspectives as requirements.** 42010 has no perspective. ASE models one
   as a `requirement def` that frames concerns, because a perspective is a
   quality property asserted across views - which is what a requirement is.
   `viewpoint def` is itself a kind of requirement def in SysML v2, so
   `frame` inside a requirement def is a small step, not a new idea.
2. **`frame <ConcernDef>;`** The methodology frames concern *definitions*
   (`frame FunctionalCapabilities;`). Strict SysML v2 frames a concern
   *usage* (`frame concern fc : FunctionalCapabilities;`). The ASE gate and
   projection accept the short form; when a design adds concerns of its own,
   prefer the strict form - it validates in both the builtin gate and the
   pilot implementation.

## Where each viewpoint's elements live

| Viewpoint | Primary SysML constructs | ASE attributes read by checks |
|---|---|---|
| Context | `part def` (system, externals), `port def`, `interface def`, `use case def` + `actor`, `item def` | `EXTERNAL_KINDS` stage types |
| Functional | `part def` stages, `port def`, `flow`, `interface def`, `action def` | `llmCalls`, `latencyMs`, `costTokens`, `fanOut`, `maxIterations` |
| Information | `item def`, attribute `dataClass`, `state def` (lifecycle), `flow` of items | `dataClass`, `preservesProvenance`, item names with chunk/citation |
| Knowledge (ext) | `item def` sources, retrieval stages, memory `part def` with retention | `preservesProvenance` |
| Concurrency | `fanOut`, `maxIterations`, `state def`, `action def` with `fork`/`join` | `fanOut`, `maxIterations`, back edges |
| Autonomy (ext) | authority attributes, approval gates as `part def`, `state def` for escalation | `trustLevel` (proxy), `Gate` nodes |
| Deployment | `part def` nodes, `allocation def` / `allocate`, `individual` | `region` (extension, for Location) |
| Operational | `part def` telemetry / runbook elements, `state def` operating modes, `action def` procedures | `hasFallback` |
| Development | `package` structure, `import`, generated vs hand-written markers | stage def count (`build_surface`) |
