---
name: ase-arch-sysml-foundations
description: >
  Shared conventions for writing an architecture description (AD) in SysML v2
  the Rozanski & Woods way inside ASE - the ISO 42010 to SysML v2 mapping, the
  file layout of an AD, the view / viewpoint / expose / render idiom, the
  decision, scenario and risk metadata kit, and how to model, analyse and
  reason over an AD. Load before any ase-viewpoint-* or ase-perspective-*
  skill, or when asked how SysML v2 represents stakeholders, concerns,
  viewpoints, views, perspectives or architecture decisions. Do not use for
  turning plain prose into a SysML model with no architecture framing - that
  is description-to-sysmlv2.
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# SysML v2 foundations for an ASE architecture description

The ASE series applies Rozanski & Woods (R&W), *Software Systems Architecture*
2nd ed., to agentic systems, and states every artefact in SysML v2. This skill
holds what every viewpoint and perspective skill assumes. Read it once per
task; the viewpoint and perspective skills do not repeat it.

## The three jobs SysML does here

| Job | Question | SysML v2 means | ASE engine |
|---|---|---|---|
| **Model** | What is the architecture? | `part def`, `port def`, `item def`, `flow`, `action def`, `state def`, `allocation`, `view def` | the gate `check_model.py` |
| **Analyse** | Does it meet its numbers? | `attribute` estimates, `calc def`, `constraint def`, `requirement def` + `require constraint`, `analysis def`, `verification def` | `sysmlagents.analysis` (the delegate for analysis cases) |
| **Reason** | What follows from it? | the model projected to a graph: reachability, absence, classification | `sysmlagents.checks` (36 checks), the `ase` MCP tools |

A view that only *draws* is documentation. Each viewpoint skill says which of
its models can also be analysed and which questions its graph can answer; a
view that supports neither must say so.

## Non-negotiables (from ASE ROADMAP 2.3)

1. **Controls are read-only.** `methodology/*.sysml` (process, viewpoints,
   perspectives, profile) and `models/rag-patterns.sysml` govern the work. Read
   them through `ase_viewpoint`, `ase_perspective`, `ase_controls`,
   `ase_step`; never edit them. A passing design with a dirty `models/` or
   `methodology/` diff is a failing design.
2. **Gaps are extensions on the design, with a reason.** If a viewpoint or
   perspective needs an attribute the vocabulary lacks (e.g. `region` for
   Location, `workloadClass` for response-time classes, `authorityLevel` for
   Autonomy), declare it on the *design's* stage def with
   `@Extension { reason = "..."; extends = "..."; }` and list it as a roadmap
   item to promote.
3. **Every decision has a record** - `@ArchitectureDecision` from the AD kit,
   with owner, date, rationale, alternatives, and the requirement or concern
   it affects.
4. **Quote, do not paraphrase, definitions.** Cite with `ase_provenance`.

## Layout of an architecture description

```
designs/<RS-xx>/
  design.sysml            the analysable design: the subset model_reader reads
                          (part def, :>, attribute redefines, part usage, flow,
                          requirement def, satisfy). Ports, port defs,
                          `perform`, `interface ... connect` and `doc` may also
                          live here - verified to leave analysis and sweep
                          unchanged. Views, use cases, states, allocations,
                          variants go in ad/.
  ad/
    00-stakeholders.sysml stakeholders, concerns, scenarios (A1, A2)
    context.sysml         one file per view, each importing the design
    functional.sysml
    information.sysml
    knowledge.sysml
    concurrency.sysml
    autonomy.sysml
    deployment.sysml
    operational.sysml
    development.sysml
    perspectives.sysml    perspective applications: satisfy, analysis cases, findings
    decisions.sysml       decision records, risks, tradeoffs
    ad-kit.sysml          copied from references/ad-kit.sysml
```

Why split: `model_reader` is a subset extractor. Keeping views out of
`design.sysml` keeps the analysable model inside that subset, and lets a view
add constructs (use cases, states, allocations) the reader would ignore
silently. A view file opens with `package RS01_Functional { import RS01::*; ... }`.

For a small design a single file is acceptable; keep the design package first
and every view in its own nested package.

## The core idiom

Viewpoints are controls - they already exist in `AseMethodology`. A design
never redefines a viewpoint; it declares a view that *satisfies* it:

```
package RS01_Functional {
    import RS01::*;
    import AseMethodology::*;

    view def FunctionalView {
        satisfy requirement vp : FunctionalViewpoint;
        filter @SysML::PartUsage or @SysML::FlowUsage;   // what may appear
    }

    view functional : FunctionalView {
        expose RS01Design::**;                           // what does appear
        render asInterconnectionDiagram;
    }
}
```

- `viewpoint def` = the 42010 viewpoint (framed concerns, stakeholders)
- `view def` = the model kinds a conforming view uses (`filter` = allowed kinds)
- `view` = the concrete view (`expose` = which elements, `render` = how drawn)
- `satisfy requirement vp : <Viewpoint>` inside the `view def` is what makes
  the view accountable to the viewpoint's concerns

Perspectives are `requirement def`s in `AseMethodology`, unallocated by
design. A design applies one by allocating it:

```
satisfy AseMethodology::PerformanceAndScalabilityPerspective by RS01Design;
```

An unallocated perspective in a *design* is a coverage gap. Record a
perspective you deliberately do not apply as a decision, not as silence.

See `references/42010-mapping.md` for the full term mapping and
`references/sysml-idioms.md` for exact syntax of every construct the series uses.

## The AD kit

`references/ad-kit.sysml` defines metadata the methodology profile does not
yet carry - copy it into `ad/ad-kit.sysml` (it is a skill asset, not a
control):

| Metadata | Use | Source |
|---|---|---|
| `@QualityScenario` | six-part scenario: source, stimulus, artifact, environment, response, responseMeasure | SEI QAW / Bass et al. |
| `@ArchitectureDecision` | decision record: status, owner, date, rationale, alternatives, affects | ISO 42010 decision, ADR |
| `@Risk`, `@NonRisk` | ATAM risk / non-risk bound to a decision | SEI ATAM |
| `@SensitivityPoint`, `@TradeoffPoint` | a parameter one / several qualities depend on | SEI ATAM |
| `@Finding` | a check result carried into the AD, with check id and severity | ASE checks |
| `@Correspondence` | a 42010 correspondence between elements of two views | ISO 42010 |
| `@Tactic` | which R&W / SEI tactic a design element realises | R&W perspectives, SEI tactics |

## Analysis: how numbers enter

SysML v2 `analysis def` states *what* is computed; ASE delegates *how* to
`sysmlagents.analysis`. Write both halves:

```
analysis def WorstCaseLatency {
    subject design : RS01Design;
    objective { doc /* worst-case end-to-end latency, critical path, ms */ }
    return latencyMs : Integer;     // computed by sysmlagents.analysis
}
```

Then run the delegate (`python -m sysmlagents.cli explain RS-01` or
`analyse()` / `explain()` in Python) and carry the result back as a
`@Finding` with the number. Never write a computed number into the model by
hand without the run that produced it.

Stage parameters (`latencyMs`, `costTokens`, `llmCalls`, `fanOut`) are
**declared estimates**. Every analysis verdict is conditional on them; say
so, and prefer measured values when the eval has produced them.

## Reasoning: what the graph can and cannot conclude

The model is projected to a labelled property graph (`lpg.project_lpg`,
FalkorDB or in-memory). Checks fall into six kinds, and the kind decides what
a result means - see `references/reasoning.md`:

- STRUCTURE, QUANTITY, REACHABILITY, ABSENCE, CLASSIFICATION, CORPUS
- **ABSENCE is closed-world.** "No path found" means "no path *declared*". A
  clean absence check on an incomplete model proves nothing - state which
  attributes and flows the conclusion rests on.
- A check that never fires on anything may be disconnected; `models/tripwire.sysml`
  exists so every check fires somewhere.

## Validate before reporting

1. Structural gate for every `.sysml` file:
   `run_skill_script("description-to-sysmlv2", "check_model.py", stdin=<model>)`
2. AD completeness across the files you produced (stakeholders, concern
   framing, viewpoint coverage, perspective allocation, required attributes,
   decisions, scenarios):
   `run_skill_script("ase-arch-sysml-foundations", "check_ad.py", stdin=<all AD files concatenated>)`
   The first line may scope the check:
   `// ad-check: viewpoints=Context,Functional perspectives=PerformanceAndScalability`
   Add `fragment` to the directive to check one view or perspective file on
   its own (AD-wide checks are relaxed); always finish with a run over the
   whole AD without it.
3. Required-attribute gaps against the live methodology: `ase_gap(<design path>)`.
4. The perspective sweep: `python -m sysmlagents.cli explain <RS-xx>`.

Report a model as done only after 1 and 2 are clean. Report every surviving
warning with the reason it is accepted.

## Series map

| Skill | Use for |
|---|---|
| `ase-arch-definition-process` | walking A1-A8, choosing which viewpoint/perspective skill to load |
| `ase-arch-scenarios` | A2 - quality attribute scenarios, utility tree |
| `ase-arch-evaluation` | A5/A6 - options, trade studies, ATAM-style evaluation, decisions |
| `ase-viewpoint-<name>` | one per viewpoint: context, functional, information, concurrency, development, deployment, operational, knowledge, autonomy |
| `ase-perspective-<name>` | one per perspective: security, performance-scalability, availability-resilience, evolution, regulation, development-resource, location, usability, accessibility, internationalisation, cost, groundedness, drift |
