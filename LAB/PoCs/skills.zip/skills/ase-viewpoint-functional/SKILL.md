---
name: ase-viewpoint-functional
description: >
  Build, analyse and review the Functional view of an agentic system in SysML
  v2 following the Rozanski & Woods Functional viewpoint - functional elements
  (agents, stages, tools), responsibilities, interfaces with contracts,
  connectors, requirement traceability, scenario walkthroughs, interaction and
  flexibility analysis, and the R&W structural heuristics (God elements, too
  many dependencies, level of detail). Use when asked for the functional
  structure, component model, agent/stage decomposition, interfaces between
  agents and tools, or to review one. Do not use for where components run
  (ase-viewpoint-deployment) or for threads, parallelism and loops
  (ase-viewpoint-concurrency).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Functional viewpoint

Load `ase-arch-sysml-foundations` first. Control: `AseMethodology::FunctionalViewpoint`
and `AseCatalogue::FunctionalViewpoint` (full ch17 table) - read with
`ase_viewpoint("Functional")` and `ase_obligations("Functional")`.

## Definition

> "Describes the system's runtime functional elements and their
> responsibilities, interfaces, and primary interactions" - R&W 2nd ed., ch17.

The cornerstone of most ADs, usually read first - and too often the only view
produced. It drives Information, Concurrency, Development and Deployment.
**Stakeholders**: all. **Applicability**: all systems.

**Concerns**: `FunctionalCapabilities` (what it must do - and must not),
`ExternalInterfaces` (data, event and control flows in both directions, each
with syntax *and* semantics), `InternalStructure` (elements, their mapping to
requirements, their interactions), `FunctionalDesignPhilosophy` (coherence,
cohesion, consistency, coupling, extensibility, flexibility, generality,
interdependency, separation of concerns, simplicity).

**Model**: one - the functional structure model.

## R&W model elements -> SysML v2

| R&W element | SysML v2 | ASE convention |
|---|---|---|
| Functional element | `part def X :> Stage` + `part x : X` in the design part def | a stage, agent, tool or orchestrator; its `doc` states the responsibilities |
| Responsibility: information managed | `ref item` / `attribute` on the element; `item def` in Information view | - |
| Responsibility: services offered | `port` with `in`/`out item`; `perform action` | - |
| Responsibility: activities initiated | `perform action` + outgoing `flow` | - |
| Interface (operations + semantics) | `port def` (syntax) + `requirement def` with `assume constraint` (pre) / `require constraint` (post) (semantics - Design by Contract) | contract requirement named `<Port>Contract` |
| Connector | `flow a to b` (always, for analysis) + `interface def`/`interface ... connect` when the mechanism matters (sync/async, protocol, resilience) | a rich connector (queue, event bus) becomes a stage in its own right |
| External entity | `part def` from the Context view, reached via a port | external stage types are what Security reachability treats as sinks |
| Functional capability traceability | `satisfy FR by element` | `requirement_traceability` reads it |

`design.sysml` must keep `flow a to b` between part usages - that is what the
analysis reads. Ports, `perform` and `interface ... connect` may sit alongside
(verified not to change the analysis). The view file adds the view, the
contracts and the scenarios.

## Activities -> SysML

Activities 1-4 **construct** the model; 5-8 **validate and tune** it.

1. **Identify the elements.** Derive system-level responsibilities from the
   FRs; assign elements; assess against the design-philosophy criteria;
   iterate. With a chosen pattern (A3), identification *is* instantiating the
   pattern and assigning responsibilities to its stages. Refinement moves and
   their SysML: *generalisation* -> a shared `part def` specialised by `:>`;
   *decomposition* -> the element becomes a part def with its own parts and
   flows (a nested pattern); *amalgamation* -> merge stage defs (records a
   decision; usually a performance tactic); *replication* -> the same def used
   twice (e.g. an input guard at each external interface).
2. **Assign responsibilities.** In each element's `doc`: information it
   manages, services it offers, activities it initiates. Three short lines.
3. **Design interfaces.** For each port: the items in and out, and a contract:

   ```
   port def RetrievalPort {
       in item query : SearchQuery;
       out item chunks : Chunk[0..*];
   }
   requirement def RetrievalPortContract {
       subject p : RetrievalPort;
       assume constraint {
           doc /* query.text is non-empty */
       }
       require constraint {
           doc /* every chunk carries a non-empty sourceId; at most topK
                chunks, ordered by score */
       }
   }
   satisfy RetrievalPortContract by RS01::RS01Design::dense;
   ```
   The owning element satisfies its contract - otherwise the contract is an
   unallocated requirement and the gate says so.
   For an LLM element the contract is the only place its semantics are
   written down - output schema, refusal behaviour, citation obligation. An
   interface without a contract is pitfall 1.
4. **Design connectors.** Decide per interaction: synchronous or
   asynchronous, latency tolerance, resilience. Tool calls from an agent are
   connectors to external entities; record the mechanism (function call,
   MCP, HTTP) in the `interface def`.
5. **Check functional traceability.** Every FR has `satisfy FR by <element>`
   or `// UNALLOCATED FR - reason`. Run the sweep: `requirement_traceability`.
6. **Walk through scenarios.** For each A2 functional scenario, write the
   interaction as an `action def` with successions over the elements'
   performed actions, and check every step crosses a declared flow:

   ```
   action def AskPolicyQuestionWalk {
       action retrieve;     // dense.retrieve
       action synthesise;   // synth.synthesise
       first retrieve then synthesise;
   }
   ```
   A step with no matching `flow` is a missing connector; an FR no scenario
   touches is untested functionality.
7. **Analyse interactions.** Count interactions per scenario and per element;
   minimise without breaking coherence. Run `functional_metrics.py`.
8. **Analyse for flexibility.** Pose "what if" change scenarios (swap the
   model provider, add a retrieval source, add a language) and count the
   elements each touches. Interaction analysis (7) and flexibility (8) pull
   in opposite directions - record the resolution as a decision.

## The view

```
view def FunctionalView {
    satisfy requirement vp : AseMethodology::FunctionalViewpoint;
    filter @SysML::PartUsage or @SysML::PortUsage or @SysML::FlowUsage or @SysML::InterfaceUsage;
}
view functional : FunctionalView {
    expose RS01::RS01Design::**;
    render asInterconnectionDiagram;
}
view functionalTable : FunctionalView {
    expose RS01::RS01Design::*;
    render asElementTable;       // element, responsibilities, interfaces
}
```

The filter is the guard against the **overloaded view**: no allocation,
no nodes, no threads may appear. If you need them, they belong to another view.
Different audiences get different renderings of the same exposed model
(pitfall 6) - never a different model.

## Analysis the functional model supports

| Question | Engine |
|---|---|
| FR coverage | `requirement_traceability` (sweep) |
| Reachability / dead elements | `orphan_stages`, `dangling_exits` |
| Structure heuristics: level of detail, God element, central element, too many deps, undefined elements, infrastructure, bare connectors | `run_skill_script("ase-viewpoint-functional", "functional_metrics.py", stdin=<design>)` |
| Single points of failure the structure creates | `articulation_points`, `minimum_cut` (Availability) |
| Latency / cost the structure implies | `latency_budget`, `cost_budget` - the Functional view *feeds* the performance model (`PerformanceOnFunctional.requiredAttributes`) |
| Duplicate capability across designs | `duplicate_capability`, `variation_rules` |

## Reasoning over the functional model

- *Which element realises FR-x?* follow `SATISFIES` edges.
- *What breaks if element X is removed?* reachability from entry to exit
  without X (`articulation_points` generalised).
- *Which elements can reach an external entity?* - the Security question;
  depends on declared flows only (closed-world).
- *Which change scenario touches most elements?* - flexibility; answer by
  listing elements whose defs reference the changed item/port.
- Cross-view correspondences to state (`@Correspondence`): every functional
  element is allocated in Deployment; every item on a port is defined in
  Information; every element with a cycle is covered in Concurrency; every
  element that acts externally has an authority level in Autonomy.

## Pitfalls -> detection

| Pitfall | Detection |
|---|---|
| Poorly defined interfaces | port with no `<Port>Contract`; flow between portless parts (`functional_metrics` info) |
| Poorly understood responsibilities | element def without `doc`; FR without `satisfy` |
| Infrastructure modelled as functional elements | names like `*Server`, `*Broker`, `*Database` (`functional_metrics`); vector DB *engine* belongs to Deployment, the *retriever* is functional |
| Overloaded view | view filter admits allocations, nodes, states |
| Diagrams without element definitions | undefined elements (`functional_metrics`) |
| Reconciling multiple stakeholders | one rendering for all audiences |
| Wrong level of detail | > 10 top-level elements (warning), > 20 (error); internals of an LLM prompt in the view |
| God elements | > 50% of functional responsibilities in < 25% of elements; one element in > 75% of interactions |
| Too many dependencies | an element using > 50% of its peers |
| (agentic) orchestrator as God element | an orchestrator agent that owns routing, memory, tool choice and synthesis |
| (agentic) tools without contracts | tool ports with no stated side effects or idempotency |

## Checklist

Fewer than 15-20 top-level elements; every element named with responsibilities
and interfaces; all interactions through interfaces linked by connectors;
appropriate cohesion; appropriate coupling; important scenarios identified
and walked; functional coverage checked against FRs; design principles
defined and followed; ability to cope with likely change considered;
presentation fits every stakeholder group.

## Output contract

`ad/functional.sysml` containing: the `FunctionalView` def and view usages;
a contract requirement per port; a walkthrough `action def` per A2
functional scenario; `@Correspondence` statements to the other views;
decisions for amalgamation / decomposition / 7-vs-8 tradeoffs. Updates to
`design.sysml`: element `doc`s, ports, `satisfy` for every FR.

Validate: gate; `functional_metrics.py`; `check_ad.py` with
`// ad-check: fragment viewpoints=Functional perspectives=`; the sweep.
Report every surviving heuristic warning with the judgement you made on it.
Worked example: `references/example.sysml`.
