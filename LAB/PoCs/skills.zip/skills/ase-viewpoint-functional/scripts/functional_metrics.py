#!/usr/bin/env python3
"""Tier-3 analysis: R&W functional-structure heuristics over a SysML v2 design.

Reads a design (SysML v2 text) on stdin. For every part def that composes
parts and flows - a functional structure - it reports the numeric heuristics
Rozanski & Woods give for the Functional viewpoint (ch17), so they are
computed rather than eyeballed:

    element count        8-10 top-level target, 15-20 ceiling       (wrong level of detail)
    God element          >50% of responsibilities in <25% of elements
    central element      takes part in more than 75% of interactions
    too many deps        an element uses more than 50% of its peers
    undefined elements   element definitions with no doc             (diagram without definitions)
    infrastructure       element names from the solution, not the problem domain
    connectors           flows between parts that declare no ports

Responsibilities are counted as `satisfy <Req> by <part>` allocations of
functional requirements (quality budgets such as *Budget, *Loop, Grounded*
are excluded - ASE parks them on one carrier by convention) plus `perform`
statements in the element's definition; say so when reporting. The
coupling heuristics apply from 6 elements up; below that R&W's percentages
are noise.
Text-level and heuristic: every result is a prompt for judgement, not a
verdict. Exit 0 always unless the input has no functional structure.
"""

import re
import sys

QUALITY = re.compile(r"(Budget|Bound|Loop|Perspective|Latency|Cost|Grounded\w*)$")
INFRA = re.compile(r"(Server|Broker|Database|Cluster|Container|Kubernetes|"
                   r"LoadBalancer|Vm|Host|Middleware|Bus|AppServer)$")


def strip(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"//[^\n]*", " ", text)


def blocks(text, header_re):
    for m in re.finditer(header_re, text):
        i = text.find("{", m.start())
        if i < 0 or ";" in text[m.end():i]:
            continue
        depth, j = 0, i
        while j < len(text):
            depth += {"{": 1, "}": -1}.get(text[j], 0)
            if depth == 0:
                break
            j += 1
        yield m.group(1), text[i + 1:j]


def main():
    raw = sys.stdin.read()
    text = strip(raw)
    defs_raw = dict(blocks(raw, r"\bpart\s+def\s+(\w+)"))
    defs = {k: strip(v) for k, v in defs_raw.items()}
    has_doc = {k for k, v in defs_raw.items() if re.search(r"\bdoc\s*/\*", v)}
    has_port = {k for k, v in defs.items() if re.search(r"\bport\s+\w+\s*:", v)}
    performs = {k: len(re.findall(r"\bperform\b", v)) for k, v in defs.items()}

    found = False
    for name, body in defs.items():
        parts = dict(re.findall(r"\bpart\s+(\w+)\s*:\s*(?:\w+::)*(\w+)", body))
        flows = re.findall(r"\bflow\s+(\w+)(?:\.\w+)?\s+to\s+(\w+)", body)
        if len(parts) < 2 or not flows:
            continue
        found = True
        n = len(parts)
        print(f"== {name}: {n} elements, {len(flows)} interactions")
        notes = []

        if n > 20:
            notes.append(f"error: {n} top-level elements exceeds the 15-20 ceiling - model a system of systems")
        elif n > 10:
            notes.append(f"warning: {n} top-level elements is above the 8-10 target")

        resp = {p: performs.get(t, 0) for p, t in parts.items()}
        # quality budgets are parked on one carrier by ASE convention and are
        # not functional responsibilities - count functional ones only
        for req, p in re.findall(r"\bsatisfy\s+(?:\w+::)*(\w+)\s+by\s+(\w+)", body):
            if p in resp and not QUALITY.search(req):
                resp[p] += 1
        total = sum(resp.values())
        if total >= n / 2 and n >= 4:
            top = sorted(resp.values(), reverse=True)[:max(1, n // 4)]
            if sum(top) > total / 2 and len(top) < n / 4 + 1:
                who = sorted(resp, key=resp.get, reverse=True)[:len(top)]
                notes.append(f"warning: God element - {', '.join(who)} hold {sum(top)}/{total} "
                             f"responsibilities (>50% in <25% of elements)")

        touch = {p: 0 for p in parts}
        succ = {p: set() for p in parts}
        for a, b in flows:
            for x in (a, b):
                if x in touch:
                    touch[x] += 1
            if a in succ and b in parts:
                succ[a].add(b)
        for p, c in touch.items():
            if n >= 6 and c > 0.75 * len(flows):
                notes.append(f"warning: {p} takes part in {c}/{len(flows)} interactions - central element / bottleneck")
            if n >= 6 and len(succ[p]) > (n - 1) / 2:
                notes.append(f"warning: {p} depends on {len(succ[p])}/{n - 1} peers (>50%) - too many dependencies")

        for p, t in sorted(parts.items()):
            if t in defs_raw and t not in has_doc:
                notes.append(f"info: {p} : {t} has no doc - responsibilities undefined")
            if INFRA.search(t):
                notes.append(f"warning: {p} : {t} looks like infrastructure - Deployment view?")
        portless = sorted({x for a, b in flows for x in (a, b)
                           if parts.get(x) and parts[x] not in has_port})
        if portless:
            notes.append(f"info: connectors are bare flows for {', '.join(portless)} - "
                         f"no port/interface declares syntax or semantics")

        degrees = ", ".join(f"{p}:{touch[p]}" for p in parts)
        print(f"   interactions per element: {degrees}")
        print(f"   responsibilities per element: " +
              ", ".join(f"{p}:{resp[p]}" for p in parts))
        for x in notes or ["ok: no heuristic tripped"]:
            print(f"   - {x}")

    if not found:
        print("no functional structure found (no part def with >= 2 parts and a flow)")
        return 1
    print("note: R&W heuristics, text-level; results prompt judgement, they are not verdicts")
    return 0


if __name__ == "__main__":
    sys.exit(main())
