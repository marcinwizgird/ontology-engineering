---
name: ase-viewpoint-autonomy
description: >
  Build, analyse and review the Autonomy view of an agentic system in SysML
  v2 - the ASE extension viewpoint for what each participant (agent, stage,
  tool) may do on its own authority, what needs approval, which approval
  gates (human-in-the-loop, policy, release) guard which actions, where an
  escalation goes, and which actions are reversible. Adds an authorityLevel
  extension attribute, approval gate part defs, escalation state defs and
  authority requirements, and reads the trust checks against them. Use when
  asked what the agent may do without asking, where HITL approval sits,
  whether a tool call can publish, send, pay or delete, how escalation works,
  or whether untrusted content can steer an action. Do not use for trust
  levels and data classes on their own (use ase-perspective-security) or for
  loop bounds and parallelism (use ase-viewpoint-concurrency).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Autonomy viewpoint

Load `ase-arch-sysml-foundations` first. Control:
`AseMethodology::AutonomyViewpoint` - read with `ase_viewpoint("Autonomy")`
and `ase_obligations("Autonomy")`. (`ase_obligations` returns the generic
Functional attribute list; the attribute this view needs, `authorityLevel`,
does not exist in the vocabulary yet - activity 2.)

## Definition

Autonomy is an ASE extension, not an R&W viewpoint, so there is no R&W
definition to quote. The methodology's own statement:

> "Describes what each participant may do on its own authority, what
> requires approval, and where an escalation goes." - `AseMethodology::AutonomyViewpoint`
> (doc), `@Viewpoint { origin = "extension" }`.

Its `@Extension` reason: R&W have no viewpoint asking what a component may
act on without asking; for agentic systems this is the primary governance
question, and it is structural rather than cross-cutting - so a viewpoint,
not a perspective. Model string: "authority levels, approval gates,
escalation paths".

**Stakeholders**: `ComplianceOfficer` and `ProductOwner` (who hold the
concern), the `SecurityArchitect`, the human approvers (end users, analysts,
operators) and the SRE who receives escalations. **Applicability**: every
system with a participant that acts beyond returning text - tool calls with
side effects, writes, messages, payments, code execution - or that loops or
self-improves. A read-only Q&A system still gets a one-table view stating
that every participant is at authority 0 or 1; the statement is the evidence.

**Concerns**: `AutonomyAndAuthority` (what may this act on without asking,
and who approves the rest?). Related, framed elsewhere: `PrivilegeBoundaries`
(Security), `BehaviouralDrift` (Drift), `OperationalVisibility` (escalation
receivers). Sub-concerns to walk: authority per participant; reversibility of
each action; approval gates and their timeout behaviour; escalation routes;
delegation between agents (authority must not grow through delegation);
authority under optimisation (who approves a changed prompt).

**Models**: authority model (level + grant per participant), gate model
(approval gates and what they guard), escalation model (state defs).

## Model elements -> SysML v2

| Element | SysML v2 | ASE convention |
|---|---|---|
| Participant | part usage in the design | agents, stages, tools - from the Functional view |
| Authority level | `attribute authorityLevel : Integer` on the design's stage def, `@Extension` | scale below; the number, for computing |
| Authority grant | `metadata AuthorityGrant about <Design>::<usage> { mayDo; mustNot; reversible; approval; escalatesTo; }` | the meaning, in the view file |
| Trust (proxy) | `trustLevel` (vocabulary) | how far a participant's *input* is believed; not what it may do |
| Approval gate | `part def G :> ApprovalGate` with `gateKind`, `approver`, `guards`, `onTimeout` | human / policy / budget / release |
| Gate on the path | a design stage that realises the gate (e.g. an anonymiser), with `@Correspondence` | the checks only see gates that are stages |
| Escalation path | `state def` with `accept <Signal>` transitions to flagged / awaiting states | each terminal state names a receiver |
| Authority rule | `requirement def` + `satisfy ... by` | "no stage may publish" is a requirement, satisfied by the design |

Authority scale (declare it once in the design's `@Extension` reason):

| Level | Meaning | Examples | Approval |
|---|---|---|---|
| 0 contained | output only to the next stage | planner, synthesiser, critic, reranker | none |
| 1 read | queries sources; the query itself leaves when the source is external | retriever, web search, news API | a policy gate if the query can carry internal data |
| 2 reversible act | writes that can be undone without third-party effect | draft to a workspace, cache, own ticket queue | none, or post-hoc review |
| 3 irreversible or third-party act | publish, send, pay, delete, contact a person, execute code outside a sandbox | email tool, payment API, publish | a gate on **every** path to it |

## Activities -> SysML

1. **List participants and their actions.** From the Functional view: every
   tool each agent can call, every write, every outbound message. An action
   the prompt allows but the model does not list is the first finding.
2. **Assign authority on the design.** Add the extension once, on a shared
   stage def, and redefine per stage:

   ```
   part def AuthorisedStage :> Stage {
       @AseProfile::Extension {
           reason = "Autonomy viewpoint: what a stage may do unapproved; vocabulary has trustLevel only. Scale 0 contained, 1 read, 2 reversible, 3 irreversible.";
           extends = "Stage vocabulary (RagPatterns::Stage)";
       }
       attribute authorityLevel : Integer = 0;
   }
   part def Synthesizer :> AuthorisedStage {
       attribute redefines authorityLevel = 2;   // writes the draft
   }
   ```
   Verified: adding it leaves latency, cost and every check but
   `vocabulary_conformance` unchanged; that warning is how the extension stays
   visible - accept it with a decision naming the roadmap item.
3. **Write the grants.** One `metadata AuthorityGrant about ...` per
   participant above level 0: what it may do, what it must not, whether its
   act is reversible, which gate approves, where it escalates.
4. **Place the gates.** For every level-3 action, and every level-1 read that
   can carry internal data outward, name the gate. A human gate adds human
   turnaround to the path - if it sits on the critical path the interactive
   budget no longer applies (`ResponseTimeClassGap`); prefer gates at the
   boundary (the human publishes) over gates inside the loop.
5. **Model escalation.** A `state def` whose non-success exits (source down,
   loop exhausted, policy reject, low confidence) all end in a state with a
   named receiver. `onTimeout` on each human gate: hold, reject, or proceed
   flagged - never proceed silently.
6. **State the authority rules as requirements** ("no stage may publish", "no
   contact outside the three sources") and satisfy them by the design or the
   stage that enforces them.
7. **Run the sweep and read trust against authority** (below); record each
   finding with a disposition.
8. **Gate the self-improvement.** If prompts or weights change after release
   (GEPA, fine-tuning), a release gate with a human approver is part of this
   view; `envelope_gate` asks for it and cannot see it.

## The view

```
view def AutonomyView {
    satisfy requirement vp : AseMethodology::AutonomyViewpoint;
    filter @SysML::PartUsage or @SysML::StateUsage or @AuthorityGrant;
}
view authority : AutonomyView {
    expose RS09::RS09Design::*;
    render asElementTable;       // participant, level, may, must not, gate
}
view governance : AutonomyView {
    expose RS09_Autonomy::*;
    render asTreeDiagram;        // gates and escalation paths
}
```
Keep every `filter` on one line in the file - the builtin gate is line-based.

## Analysis the autonomy model supports

| Question | Engine |
|---|---|
| Can a low-trust stage reach a higher-trust one? | `trust_escalation` (REACHABILITY, error) - `trustLevel`, flows |
| Is every external capability invoked only from the highest trust present? | `tool_authorisation` (warning) |
| Is a trust-0 stage external? | `sandbox_consistency` (error) |
| Does every stage declare trust? | `trust_declared` (ABSENCE, warning) |
| Can restricted data reach an external sink? | `data_exposure` (error) - transitive, **no declassification** |
| Is the design high-risk by definition? | `high_risk_classification` (info) - two of loop, external effect, ungrounded |
| Is there a gate over optimised candidates? | `envelope_gate` - **fires on every design** (no `Gate` node is projected) |
| Does untrusted input reach a level-3 action without a gate? | none in ASE - by hand: drop gate stages from the flow graph; any path from a stage with lower `trustLevel` to an `authorityLevel = 3` stage is a finding |
| Does delegation raise authority? | none - review: a caller at level n invoking a callee above n |

Limits you must state with every clean result: `checks.EXTERNAL_KINDS` is
`{"WebSearchFallback"}` and a stage's type is the def its usage names
*directly*. An email tool, an MCP server, a payment API, a hosted model, or
a subtype of `WebSearchFallback` is **invisible** to `data_exposure`,
`sandbox_consistency`, `tool_authorisation` and `high_risk_classification`.
Type a web-reaching usage directly as `WebSearchFallback`; record every
other boundary crossing as a decision. `data_exposure` is transitive: an
anonymiser or gate stage does not declassify, so a correct design can still
fire it - accept with a decision naming the gate.

## Reasoning over the autonomy model

- **Trust is not authority.** `trustLevel` says how far a participant's input
  is believed; `authorityLevel` says what it may do. A `trust_escalation`
  finding (untrusted content reaches a trusted stage) is what retrieval-
  augmented agents do by design; its severity depends on the authority of
  what it reaches. Tainted content reaching only level 0-2 stages can mislead
  a draft a human reviews; reaching a level-3 stage without a gate is the
  prompt-injection path that matters.
- **The dangerous triple.** A participant that reads untrusted content, has
  access to internal data, and can send something out (a web query counts)
  is an exfiltration channel. Look for it on every cycle: in RS-09 web
  content can steer the next pass's web queries.
- **What-ifs.** Raise one stage to level 3 (give the synthesiser a publish
  tool) and ask which gates now sit on every path to it; add an agent that
  delegates and ask whether its callee's level exceeds its own.
- Closed world: a tool the prompt can call but the model does not declare is
  invisible; a gate not realised by a stage on the path is invisible to
  reachability; `Gate` nodes are never projected.
- Correspondences (`@Correspondence`): every participant with authority >= 1
  appears in the Functional view with its tool ports; every policy gate is
  realised by a stage on every path to what it guards; every escalation
  state has a receiver in the Operational view; every loop exit in the
  Concurrency view's state def maps to an escalation state here.

## Pitfalls -> detection in the model

| Pitfall | Detection |
|---|---|
| Authority implied by the prompt, not the architecture | a tool in the runtime with no participant and no grant |
| Trust used as authority | `authorityLevel` absent; decisions argue from `trustLevel` alone |
| Irreversible action without a gate | an `authorityLevel = 3` stage reachable from an entry with no gate stage on the path |
| Gate that cannot fail | `onTimeout = "proceed"`; a human gate with no reject transition |
| Escalation to nobody | a terminal state of the escalation `state def` with no receiver |
| Human gate inside the interactive path | gate stage on the critical path of a seconds-scale budget |
| Delegation escalation | an agent at level n calling a sub-agent or tool above n |
| External effect invisible to the checks | a web/email/MCP/payment usage not typed `WebSearchFallback`; `tool_authorisation` clean for the wrong reason |
| Anonymiser treated as declassifier | `data_exposure` "fixed" by removing `dataClass` rather than accepting with a decision |
| Ungated self-improvement | GEPA or fine-tuning in scope, no release gate, `envelope_gate` accepted without one |
| Silent autonomy | a read-only system with no autonomy view at all - the absence is not evidence |

## Checklist

Every participant has a level and, above 0, a grant; every level-3 action
has a gate on every path; every gate has an approver and a timeout
behaviour; every non-success exit escalates to a named receiver; authority
rules are requirements with `satisfy`; delegation cannot raise authority;
trust findings dispositioned against authority; external crossings the
checks cannot see recorded as decisions; self-improvement gated; the
`authorityLevel` extension carries its reason and roadmap item.

## Output contract

`ad/autonomy.sysml` containing: `AuthorityGrant` metadata def and one grant
per participant above level 0; `ApprovalGate` hierarchy and a governance
part; escalation `state def`s; authority `requirement def`s with `satisfy`;
`@Finding` per trust / classification check with disposition; `@Risk` for
residual injection paths; `@Correspondence`; decisions. Updates to
`design.sysml`: `authorityLevel` via `@Extension` on the stage defs,
`trustLevel` on every stage, gate stages (anonymiser, policy check) on the
paths they guard.

Validate (from `AI Skills/skills`):

```
python description-to-sysmlv2/scripts/check_model.py < ad/autonomy.sysml
python ase-arch-sysml-foundations/scripts/check_ad.py < ad/autonomy.sysml    # fragment directive
python -m sysmlagents.cli explain RS-09      # from ASE Agentic System
```
Worked example: `references/example.sysml` (RS-09: nothing above level 2,
the analyst publishes, web queries behind a policy gate, GEPA behind a
release gate).
