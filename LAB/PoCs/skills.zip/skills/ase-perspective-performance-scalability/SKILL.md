---
name: ase-perspective-performance-scalability
description: >
  Apply the Rozanski & Woods Performance and Scalability perspective to an
  agentic system's SysML v2 architecture - capture load-qualified performance
  requirements, build the performance model from the functional and deployment
  views, compute worst-case latency, throughput bounds and peak-load
  behaviour, apply performance tactics, and record findings and decisions.
  Use for response time, latency budgets, throughput, rate limits, peak load,
  scalability, capacity or "will it be fast enough" questions about an ASE
  design. Do not use for token or money cost per interaction (use
  ase-perspective-cost) or for failure handling (use
  ase-perspective-availability-resilience).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Performance and Scalability perspective

Load `ase-arch-sysml-foundations` first. Methodology entries (controls, read
with `ase_perspective("Performance")`):
`AseCatalogue::PerformanceAndScalabilityPerspective` (full ch26 table),
`AseCatalogue::PerformanceOnFunctional` (required attributes),
`AseCatalogue::ResponseTimeClassGap` (known vocabulary gap).

## Definition

> "The ability of the system to predictably execute within its mandated
> performance role and to handle increased processing volumes in the future
> if required" - R&W 2nd ed., ch26 summary table.

`AseMethodology::PerformanceAndScalabilityPerspective` carries the website's
wording ("...within its mandated performance *profile* and to handle
increased processing volumes"); the book table says *role* and adds "if
required". Both are sourced - cite whichever element you reference, and do
not silently merge them.

Two properties: **performance** now, **scalability** under growth.

**Applicability.** Systems with complex, unclear or ambitious performance
requirements; architectures containing elements of unknown performance;
systems likely to grow significantly. All three hold for agentic systems by
construction - a language model *is* an element whose performance is
unknown. Treat this perspective as always applicable.

**Concerns** (catalogue concern defs): `ResponseTime` (responsiveness vs
turnaround), `Throughput`, `Scalability` (long-term and transient bursts),
`Predictability`, `HardwareResourceRequirements` (for agents: model serving
capacity, rate limits, context window), `PeakLoadBehaviour` (the "knee").
Stakeholders: end users, SRE, finance owner.

## Activities -> SysML

R&W's loop: capture requirements -> create performance model -> (analyse
model || practical testing) -> assess against requirements -> rework ->
back to the model.

### 1. Capture the performance requirements

A response-time target means nothing without a load. Every performance
requirement states: the interaction (start and end), the percentile, the
load it holds under, and the workload class.

```
requirement def LatencyBudget {
    doc /* From RS-01 QR-1: "An answer appears within 3 seconds."
         Stakeholder answer (A1): worst case, not p50. */
    attribute budgetMs : Integer = 3000;          // read by latency_budget
    attribute percentile : Integer = 100;         // worst case
    attribute atConcurrentUsers : Integer = 50;   // "50 concurrent users Monday"
    attribute workloadClass : String = "interactive";
}

requirement def ThroughputTarget {
    doc /* Peak: 50 concurrent users; assumed think time 30 s. */
    attribute peakRequestsPerMinute : Integer = 100;
}
```

Business-phrased targets ("20,000 transactions a day") are real needs;
translate them into mix, daily distribution and peak concentration and keep
the original sentence in `doc`. Throughput is counted in user-recognisable
transactions (questions answered), never in technical units (tokens, DB
inserts). Missing load, percentile or scalability horizon -> ask in A1; if
unanswered, `@Assumption`.

### 2. Create the performance model

R&W derive the performance model from the **Deployment** view simplified to
processes, nodes, links and data stores, annotated with per-element
processing times at a stated concurrency, link latencies, concurrency
ceilings and contention multipliers, plus an explicit **assumption list**.

In ASE the functional design already *is* most of that model. Obligations
(`PerformanceOnFunctional.requiredAttributes`): every stage declares
`latencyMs`, `costTokens`, `llmCalls`, `fanOut`; every pattern with a cycle
declares `maxIterations`. Add what the deployment view contributes:

```
part def ModelApi {                           // in ad/deployment.sysml
    attribute rateLimitRpm : Integer = 500;   // concurrency ceiling
    attribute rateLimitTpm : Integer = 200000;
    attribute p50LatencyMs : Integer = 900;
}
```

Remote hops: the `flow` statement carries no latency. Fold a remote call's
network cost into the called stage's `latencyMs` and record it as an
assumption; if a hop is architecturally significant (cross-region, external
API), model it as its own stage so the critical path shows it.

Workload class: the vocabulary has one `latencyMs` and cannot tell an
interactive reply from a turnaround task (`ResponseTimeClassGap`). If the
design has both, add `workloadClass` on the design's stage defs with
`@Extension` citing that gap - never change the vocabulary.

### 3. Analyse the model

| Question | Engine | How |
|---|---|---|
| Worst-case end-to-end latency vs budget | `latency_budget` | critical path through the DAG, loop stages x `maxIterations` |
| What dominates the path | `critical_path` | largest stage share |
| Fan-out inside a loop | `fanout_compounding` | stage multiplied by both |
| Does the verdict survive one more iteration | `cost_sensitivity` pattern: re-run with `maxIterations + 1` | what-if |
| Throughput ceiling | manual `calc def` (below) | least scalable element on the path bounds capacity |
| Knee / peak behaviour | `analysis def` + load test | saturation of the ceiling element |

The ASE analysis assumes: parallel branches take the maximum latency; fan-out
multiplies cost, not latency (concurrent); a stage on a cycle runs
`maxIterations` times; estimates are worst case. Say so in every finding.

Throughput bound - the least scalable element sets capacity:

```
calc def ThroughputCeiling {
    in rateLimitRpm : Integer;        // ModelApi ceiling
    in llmCallsPerRequest : Integer;  // from the analysis: llm_calls x iterations
    return : Integer = rateLimitRpm / llmCallsPerRequest;
}
```

Compare the ceiling to `ThroughputTarget.peakRequestsPerMinute`. R&W add a
~20% allowance for hidden inefficiency to path estimates as a starting
point; if you apply it, state it as an assumption.

Run: `python -m sysmlagents.cli explain <RS-xx>`; carry each verdict into
`ad/perspectives.sysml` as `@Finding` with the number.

### 4. Practical testing

Testing effort is inversely proportional to confidence. For LLM stages
confidence is low by default: measure `latencyMs` per stage under realistic
prompt length and concurrency (micro-benchmark), and the end-to-end path
under the A2 peak scenario (benchmark). Replace declared estimates with
measured values and keep the old estimate in `doc`. Express each test as a
`verification def` verifying the requirement it exercises.

### 5. Assess against the requirements

Walk every performance requirement and state: met / not met / met only under
assumption X. Maintain `@Risk` entries for open performance risks, closing
them with evidence.

### 6. Rework

Apply tactics (below). Rework typically touches Functional and Deployment,
often Concurrency and Information. Re-run the analysis after each change;
record the before/after numbers in the decision.

## Applying the perspective to each view

| View | What the perspective adds or checks in SysML |
|---|---|
| Context | slow or rate-limited external systems as externals with `latencyMs`; performance requirements recorded here first |
| Functional | required attributes on every stage; compromises such as merging two LLM stages to cut a round trip, recorded as decisions |
| Information / Knowledge | index size, corpus growth rate, cache items; data to replicate or pre-compute |
| Concurrency | `fanOut`, `maxIterations`, parallel branches; contention on the model API |
| Development | performance guidelines (prompt length limits, streaming, no sync I/O on the path) |
| Deployment | model serving placement, rate limits, regions - the calibration source |
| Operational | latency and token telemetry per stage, alerting on the knee |

## Tactics -> SysML change -> expected effect

| Tactic (R&W ch26) | Agentic form | SysML change | Check that should move |
|---|---|---|---|
| Optimise repeated processing | shorten the prompt of the most-called stage | lower `latencyMs`/`costTokens` of the top stage by total cost | `critical_path`, `latency_budget` |
| Reduce contention via replication | multiple model deployments / keys | `ModelApi[n]` in deployment; higher ceiling | throughput calc |
| Prioritise processing | interactive queue before batch | `workloadClass` extension, two requirement defs | per-class budgets |
| Consolidate related workload | one LLM call doing classify + rewrite | merge two stages into one stage def | `llm_call_count`, `critical_path` |
| Distribute processing over time | nightly re-index, precomputed summaries | move stage out of the interactive pattern into a batch pattern | `latency_budget` |
| Minimise use of shared resources | avoid shared vector store locks, per-tenant indices | deployment allocation | throughput calc |
| Reuse resources and results | semantic / response cache | cache stage with `hasFallback = true`, low `latencyMs`; decision on staleness | `latency_budget` (hit path) |
| Partition and parallelise | parallel retrievers, parallel tool calls | parallel branches instead of a chain | `critical_path` |
| Scale up / out | bigger model tier / more replicas | deployment attributes | throughput calc |
| Degrade gracefully | timeout -> cheaper model or cached answer | fallback stage, `hasFallback = true` | `fallback_coverage` |
| Asynchronous processing | streaming tokens; background research tasks | `workloadClass = "turnaround"`; perceived-latency requirement | per-class budgets |
| Relax transactional consistency | eventually consistent index | Information view decision | - |
| Make design compromises | smaller/faster model; fewer loop iterations | lower `maxIterations`, swap stage def | all quantity checks; record quality cost |

Every tactic applied gets `@Tactic` on the changed element and an
`@ArchitectureDecision` with the before and after numbers.

## Pitfalls -> how to detect them in the model

| Pitfall | Detection |
|---|---|
| Imprecise goals | requirement def lacks `budgetMs`, `percentile` or load attribute; `check_ad.py` / `ase_gap` |
| Unrealistic models | stage estimates never replaced by measurement; `doc` says "estimate" on every stage after eval exists |
| Simple measures for complex cases | budget verified single-user only; no `atConcurrentUsers` |
| Inappropriate partitioning | one stage on every path (`articulation_points`) with high `latencyMs` - the God-element bottleneck |
| Invalid environment assumptions | rate limits / model latency asserted with no source; no `@Assumption` |
| Too much indirection | chains of zero-work routing stages on the critical path |
| Concurrency contention | shared `ModelApi` ceiling below peak demand (throughput calc) |
| Database contention | vector store shared by ingest and query without allocation decision |
| Transaction overhead | many small LLM calls where one would do (`llm_call_count` high, each small) |
| Careless resource allocation | context window filled per iteration without bound |
| Network vs in-process | remote hops not in any `latencyMs`; no assumption recorded |
| (agentic) loop x fan-out | `fanout_compounding` |
| (agentic) fragile verdict | passes now, fails at `maxIterations + 1` |

## Checklist

Requirements: targets agreed with stakeholders; both response time and
throughput covered; user-observed vs total (async) work distinguished;
targets sanity-checked; expectations set; every target stated against a
load.
Architecture: main performance risks identified; enough analysis and testing
for the confidence needed; workload known and classes prioritised; scaling
limit known; assumptions listed and validated where needed; consistency
relaxation considered; reviewed against every pitfall above.

## Output contract

In `ad/perspectives.sysml`:

1. `satisfy AseMethodology::PerformanceAndScalabilityPerspective by <Design>;`
2. load-qualified requirement defs (in `design.sysml` if the checks read them)
3. the throughput `calc def` and any `analysis def` with their results as `@Finding`
4. one `@Finding` per check result with disposition
5. `@Tactic` + `@ArchitectureDecision` for every change, with before/after numbers
6. `@Assumption` list (the performance model's assumptions)
7. `verification def` per performance requirement

Validate: gate on every file; `check_ad.py` with
`// ad-check: perspectives=PerformanceAndScalability`; `ase_gap`; the sweep.
A worked RS-01 example is in `references/example.sysml`.
