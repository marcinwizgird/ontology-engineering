---
name: ase-perspective-cost
description: >
  Apply the ASE Cost perspective (an extension to Rozanski & Woods) to an
  agentic system's SysML v2 architecture - state a worst-case token budget per
  interaction, compute how stage costs compound under fan-out and loop
  iteration, count model calls, test whether the verdict survives one more
  iteration, explore cheaper options, and record findings and decisions. Use
  for token cost, cost per question, LLM spend, model-call count, "why is
  this so expensive", cost budgets, model routing or caching for cost, and
  fan-out x iteration blow-ups in an ASE design. Do not use for response time
  or throughput (use ase-perspective-performance-scalability) or for the
  team, time and build budget (use ase-perspective-development-resource).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Cost perspective

Load `ase-arch-sysml-foundations` first. Methodology entry (control, read
with `ase_perspective("Cost")` and cite with `ase_provenance("CostPerspective")`):
`AseMethodology::CostPerspective`, `origin = "extension"`,
`checks = "cost_budget,llm_call_count,cost_sensitivity"`.

## Definition

> "The ability of the system to execute within a mandated cost envelope per
> interaction, and to keep that envelope under composition." -
> `AseMethodology::CostPerspective` doc, ase-methodology.sysml.

It is an ASE extension, not an R&W perspective. The recorded reason
(`@Extension`, quoted): *"R&W fold cost into Development Resource and
Performance. For agentic systems token cost is first-class and behaves
differently from both: it is per-interaction, it compounds multiplicatively,
and it is invisible to inspection. Eight reasonable stages composed to
68,600 tokens against a 5,000 budget in our own reference model."*

**Applicability.** Any design with at least one model-calling stage
(`llmCalls > 0`). Mandatory when the design has a cycle, a stage with
`fanOut > 1`, or both - that is where cost stops being additive.

**Concerns.** `CostPerInteraction` ("What does one interaction cost, worst
case?") is the framed concern. Related: `ConcurrencyAndFanOut` (the
multiplier), `DeploymentTopology` (which model serves which stage, at what
price), catalogue `Scalability` (cost per unit as volume grows).
**Stakeholders:** `FinanceOwner`, `ProductOwner` (hold the concern);
`SoftwareEngineer` (owns the estimates); `SiteReliabilityEngineer` (sees the
bill).

## Activities -> SysML

The loop mirrors Performance: capture the budget -> build the cost model ->
analyse -> measure -> assess -> rework.

### 1. Capture the cost requirement

The checks read one requirement by name: `CostBudget.budgetTokens`. A budget
under any other name is invisible to `cost_budget` and `cost_sensitivity`,
which then stay silent - a clean result on a design with no `CostBudget` is a
missing input, not a pass.

```
requirement def CostBudget {
    doc /* From RS-06 QR-2: "Cost under 10,000 tokens per question."
         A1 answer: worst case; hosted and on-prem tokens count alike. */
    attribute budgetTokens : Integer = 10000;     // read by cost_budget
}
```

Ask in A1: per interaction or per session; worst case or mean; tokens or
money; which models count. Record the original sentence in `doc`; if
unanswered, `@Assumption`.

### 2. Build the cost model

Obligations: every stage declares `costTokens` and `llmCalls`; any stage that
multiplies work declares `fanOut`; any pattern with a cycle declares
`maxIterations` (`check_ad.py` REQUIRED for Cost). The delegate computes

```
cost = SUM over stages  costTokens x fanIn x iterations
llm  = SUM over stages  llmCalls   x fanIn x iterations
```

where `fanIn` is the product of `fanOut` upstream on the heaviest path and
`iterations` is `maxIterations` for a stage on a cycle, 1 otherwise. State the
formula as a `calc def` so a reviewer can check the delegate against it (see
`references/example.sysml`).

Money needs what the vocabulary lacks - input/output token split and price
per model tier. Add them on the design's stage def with `@Extension` (never
on `RagPatterns::Stage`); `vocabulary_conformance` will warn, which is how the
extension stays visible. Accept that warning with a decision naming the
roadmap item.

### 3. Analyse

Verified against the reference model
(`python -c "from sysmlagents import analyse, compare; print(compare(analyse()))"`
from `ASE Agentic System`, budget 5,000 tokens):

| Pattern | stages | llm | latency ms | cost tokens | cost_budget |
|---|---|---|---|---|---|
| NaiveRag | 2 | 1 | 1,520 | 2,200 | pass |
| RerankHybridRag | 5 | 1 | 1,715 | 2,200 | pass |
| HydeRag | 3 | 2 | 2,420 | 3,300 | pass |
| CorrectiveRag | 4 | 2 | 3,020 | 3,000 | pass |
| SelfRag | 3 | 6 | 6,660 | 9,300 | fail |
| AgenticRag | 8 | 46 | 16,575 | 68,600 | fail |

AgenticRag's 68,600 is compounding, not size: synth 2,200 x fan-in 4 x 5
passes = 44,000; grounded 900 x 4 x 5 = 18,000; expander 1,200 x 5 = 6,000;
orchestrator 600. The model's own `satisfy CostBudget` claims on SelfRag and
AgenticRag disagree with the analysis ("model claims otherwise") - read
`conformance(analyse())` too.

| Question | Engine | Reads |
|---|---|---|
| Worst case vs budget | `cost_budget` (error) | `costTokens`, `fanOut`, `maxIterations`, `CostBudget.budgetTokens` |
| Model calls per interaction | `llm_call_count` (warning, fixed threshold > 10) | `llmCalls` x fan-in x iterations |
| Does the verdict survive +1 iteration | `cost_sensitivity` (info) | re-analysis at `maxIterations + 1`; only with a `CostBudget`; iterations only, never fan-out |
| Per-stage derivation and share | `python -m sysmlagents.cli explain <RS-xx>` ("cost derivation"), `scripts/cost_grid.py` | same |
| Design-space table for A5 | `scripts/cost_grid.py <Pattern>` | grid over `maxIterations` x `fanOut` |
| Money per month | `calc def MonthlySpendCents` + `@Extension` prices | extension attributes - review, no check |

`cost_grid.py` reads the model on stdin, mirrors the delegate's assumptions,
and exits 1 when a pattern is over budget. On AgenticRag it shows the only
single-pass, fan-out-1 cell under 5,000 tokens is 4,900.

Assumptions to state in every finding: estimates are declared, not measured;
each loop pass costs the same (real loops grow context each pass, so real
cost is super-linear); exclusive branches are summed as if both ran (the
reader cannot tell a choice from a fork - CorrectiveRag counts `web` and
`synth` paths together), so cost is pessimistic there and optimistic
wherever a tool secretly calls a model.

### 4. Measure

Evaluation produces `tokens_p100` per question (and per stage from traces).
Express it as a `verification def` verifying `CostBudget`; replace declared
`costTokens` with measured values and keep the estimate in `doc`.

### 5. Assess and 6. rework

Walk each option: pass / fail / pass only under assumption X. Rework is an A5
exploration, never silent tuning - RS-06 fails if `fanOut` or `maxIterations`
is quietly lowered and presented as satisfying the spec. Present options with
computed numbers, get the stakeholder's choice, record it (A8 if a
requirement is relaxed or deferred).

## Applying the perspective to each view

| View | What the perspective adds or checks in SysML |
|---|---|
| Context | the model providers as externals; the budget and its unit recorded at the boundary |
| Functional | `costTokens` / `llmCalls` on every stage; merges of adjacent LLM stages recorded as decisions |
| Information / Knowledge | chunk count and size into the synthesiser (top-k drives input tokens); cache items |
| Concurrency | `fanOut` and `maxIterations` - the two multipliers; `fanout_compounding` flags a stage hit by both |
| Autonomy | an agent that may spawn sub-agents or retry without bound is an unmodelled multiplier - bound it |
| Deployment | model tier per stage (`@Extension modelTier`), price per tier, on-prem vs hosted |
| Operational | per-stage token telemetry, spend alerts, the hard `spent_tokens` cut-off in generated code |
| Development | prompt templates versioned with their measured token size |

## Tactics -> SysML change -> expected effect

| Tactic | Agentic form | SysML change | Check that should move |
|---|---|---|---|
| Fewer iterations | lower the retry bound; exit early on a passing judge | lower `maxIterations` | `cost_budget`, `llm_call_count`, `cost_sensitivity` |
| Less fan-out | fewer sub-queries or parallel agents | lower `fanOut` on the expander | `cost_budget`, `fanout_compounding` |
| Smaller model per stage | cheap model for judge, router, reformulator | lower `costTokens` on that stage def; `modelTier` extension | `cost_budget` |
| Routing | classifier sends easy questions to a one-pass path | new router stage + two branches; note the sum-of-branches over-count, record expected mix as `@Assumption` | `cost_budget` (pessimistic), review |
| Prompt compression | fewer / shorter chunks, summarised history | lower `costTokens` on the synthesiser; Knowledge-view top-k decision | `cost_budget` |
| Caching | provider prefix cache; semantic response cache | cache stage with low `costTokens` + `hasFallback`; cached share as `@Assumption` | `cost_budget` on the hit path |
| Consolidate calls | one call to classify and rewrite | merge two stage defs | `llm_call_count` |
| Remove the loop | defer self-check (RS-06 option C) | delete the back edge; record the deferred requirement | all three; groundedness tradeoff |
| Hard stop | token ceiling enforced at runtime | Operational view; generated `spent_tokens` guard | none - runtime guard, verify in eval |

Each applied tactic: `@Tactic` on the changed element, `@ArchitectureDecision`
with before/after numbers from the delegate.

## Pitfalls -> how to detect them in the model

| Pitfall | Detection |
|---|---|
| No budget, or budget under another name | no `requirement def CostBudget` with `budgetTokens`; `cost_budget` silent - report as a gap |
| Average-case budget | `doc` of `CostBudget` says "average" or "typical"; no `percentile` |
| Stage without estimates | `costTokens` absent on a stage with `llmCalls > 0` - defaults to 0; `ase_gap` |
| Loop with no bound | `bounded_cycles` error; cost of the loop computed at one pass |
| Multiplier hidden in a tool | a tool or agent stage that calls a model but declares `llmCalls = 0` - review every external stage |
| Satisfy claim contradicts analysis | `conformance(analyse())` shows "CLAIMED BUT FAILS" for `CostBudget` |
| Fragile verdict | `cost_sensitivity` fires, or `cost_grid.py` prints SENSITIVE |
| Constant-per-pass assumption | loop stage whose context grows per pass, no `@Assumption` on growth |
| Tokens treated as money | one budget across models of different price; no `modelTier` extension |
| Silent tuning | `fanOut` / `maxIterations` changed with no decision and no option table |
| Estimates never replaced | eval has run, stage `doc` still says "estimate" |

## Checklist

Budget named `CostBudget`, per interaction, worst case, unit and models
agreed; every model-calling stage has `costTokens` and `llmCalls`; every
multiplier declared; delegate run and numbers carried as `@Finding`;
`cost_sensitivity` result recorded; per-stage shares known (which stage to
attack first); design-space options computed, not estimated; money view
present if the budget owner thinks in currency; measured tokens planned as a
`verification def`; each tactic's quality cost (usually groundedness or
recall) recorded as a `@TradeoffPoint`.

## Output contract

In `ad/perspectives.sysml` (and `design.sysml` for what the checks read):

1. `satisfy AseMethodology::CostPerspective by <Design>;`
2. `requirement def CostBudget { attribute budgetTokens ... }` in `design.sysml`
3. the cost `calc def`, the design-space `analysis def`, results as `@Finding`
4. one `@Finding` per `cost_budget`, `llm_call_count`, `cost_sensitivity` result, with disposition and decision
5. `@Extension` on any stage def carrying price or token-split attributes
6. `@Tactic` + `@ArchitectureDecision` per change, before/after numbers; `@TradeoffPoint` for the quality given up
7. `verification def` against measured `tokens_p100`

Validate (from `AI Skills/skills`):

```
python description-to-sysmlv2/scripts/check_model.py < <file>
python ase-arch-sysml-foundations/scripts/check_ad.py < <file>   # // ad-check: perspectives=Cost
python ase-perspective-cost/scripts/cost_grid.py [Pattern] < <design.sysml>
```

then `ase_gap(<design>)` and `python -m sysmlagents.cli explain <RS-xx>`.
Worked RS-06 example (infeasible match, option table, recorded choice):
`references/example.sysml`.
