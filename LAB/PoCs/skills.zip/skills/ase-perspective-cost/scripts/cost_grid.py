#!/usr/bin/env python3
"""Token-cost breakdown and design-space grid for an ASE pattern or design.

Reads a SysML v2 model (the ASE stage subset) on stdin. For each pattern -
or the ones named in argv - prints the per-stage cost derivation
(costTokens x upstream fan-in x iterations, ranked by share) and a grid of
worst-case cost / model calls / latency over maxIterations and fan-out, marked
against CostBudget.budgetTokens (or --budget=N). Flags a verdict that flips
with one more iteration, which is what cost_sensitivity reports.

    python cost_grid.py [Pattern ...] [--budget=N] < design.sysml

Same assumptions as sysmlagents.analysis: a stage on a cycle runs
maxIterations times; fan-out multiplies downstream cost, not latency;
parallel and exclusive branches are both counted. Stdlib only.
Exit 1 when a pattern is over budget, 0 otherwise.
"""

import re


VOCAB = ("llmCalls", "latencyMs", "costTokens", "fanOut",
         "preservesProvenance", "hasFallback", "trustLevel", "dataClass")
ATTR = re.compile(r"^attribute\s+(?:(?:redefines|:>>)\s+)?(\w+)\s*(?::\s*[\w:]+)?\s*(?:=\s*(.+))?$")
PART_USE = re.compile(r"^part\s+(\w+)\s*:\s*(?:\w+::)*(\w+)")
FLOW = re.compile(r"^flow\s+(\w+)\s+to\s+(\w+)$")
PART_DEF = re.compile(r"^part\s+def\s+(\w+)(?:\s*(?::>|specializes)\s*(?:\w+::)*(\w+))?$")
ITEM_DEF = re.compile(r"^item\s+def\s+(\w+)")
REQ_DEF = re.compile(r"^requirement\s+def\s+(\w+)$")


def _val(raw):
    if raw is None:
        return None
    raw = raw.strip().rstrip(";").strip()
    if raw in ("true", "false"):
        return raw == "true"
    try:
        return int(raw)
    except ValueError:
        return raw.strip('"')


def _blocks(text):
    root = {"head": "<root>", "stmts": [], "kids": []}
    stack, buf = [root], []
    for ch in text:
        if ch == "{":
            kid = {"head": " ".join("".join(buf).split()), "stmts": [], "kids": []}
            stack[-1]["kids"].append(kid)
            stack.append(kid)
            buf = []
        elif ch == "}":
            tail = " ".join("".join(buf).split())
            if tail:
                stack[-1]["stmts"].append(tail)
            buf = []
            if len(stack) > 1:
                stack.pop()
        elif ch == ";":
            s = " ".join("".join(buf).split())
            if s:
                stack[-1]["stmts"].append(s)
            buf = []
        else:
            buf.append(ch)
    return root["kids"]


def read(text):
    """-> dict(defs={name:(parent, attrs)}, patterns={name:{attrs,usages,flows}},
    items={name:[attr names]}, reqs={name:attrs})"""
    text = re.sub(r"doc\s*/\*.*?\*/", " ", text, flags=re.S)
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    text = re.sub(r"//[^\n]*", " ", text)
    m = {"defs": {}, "patterns": {}, "items": {}, "reqs": {}}

    def attrs(b):
        out = {}
        for s in b["stmts"]:
            a = ATTR.match(s)
            if a:
                out[a.group(1)] = _val(a.group(2))
        return out

    def walk(bs):
        for b in bs:
            h = b["head"]
            if h.startswith("package "):
                for st in b["stmts"]:                  # bodiless `part def X :> Y;`
                    pd = PART_DEF.match(st)
                    if pd:
                        m["defs"].setdefault(pd.group(1), (pd.group(2), {}))
                walk(b["kids"])
                continue
            pd = PART_DEF.match(h)
            if pd:
                us = [PART_USE.match(s) for s in b["stmts"]]
                fl = [FLOW.match(s) for s in b["stmts"]]
                if any(us) or any(fl):
                    m["patterns"][pd.group(1)] = {
                        "attrs": attrs(b),
                        "usages": {u.group(1): u.group(2) for u in us if u},
                        "flows": [(f.group(1), f.group(2)) for f in fl if f]}
                else:
                    m["defs"][pd.group(1)] = (pd.group(2), attrs(b))
                continue
            it = ITEM_DEF.match(h)
            if it:
                m["items"][it.group(1)] = list(attrs(b))
                continue
            rq = REQ_DEF.match(h)
            if rq:
                m["reqs"][rq.group(1)] = attrs(b)
    walk(_blocks(text))
    return m


def resolved(m, name):
    chain, seen, cur = [], set(), name
    while cur and cur in m["defs"] and cur not in seen:
        seen.add(cur)
        chain.append(m["defs"][cur][1])
        cur = m["defs"][cur][0]
    out = {}
    for a in reversed(chain):
        out.update({k: v for k, v in a.items() if v is not None})
    return out


def back_edges(nodes, edges):
    succ = {n: [] for n in nodes}
    for a, b in edges:
        succ[a].append(b)
    colour, back = {n: 0 for n in nodes}, set()

    def visit(n):
        colour[n] = 1
        for x in succ[n]:
            if colour[x] == 1:
                back.add((n, x))
            elif colour[x] == 0:
                visit(x)
        colour[n] = 2
    for n in nodes:
        if colour[n] == 0:
            visit(n)
    return back


def _reach(succ, start):
    seen, stack = set(), [start]
    while stack:
        n = stack.pop()
        if n not in seen:
            seen.add(n)
            stack.extend(succ.get(n, []))
    return seen


def cycle_members(nodes, edges, back):
    succ = {n: [] for n in nodes}
    for a, b in edges:
        succ[a].append(b)
    mem = set()
    for tail, head in back:
        seen = _reach(succ, head)
        if tail in seen:
            mem |= {n for n in seen if tail in _reach(succ, n)}
        mem |= {head, tail}
    return mem


def analyse(m, pname, override=None):
    """Worst-case numbers, same assumptions as sysmlagents.analysis.
    override: {"maxIterations": n, "fanOut": {usage: n}, "defs": {def: {attr: v}}}"""
    ov = override or {}
    p = m["patterns"][pname]
    nodes = list(p["usages"])
    edges = [(a, b) for a, b in p["flows"] if a in p["usages"] and b in p["usages"]]
    at = {}
    for n in nodes:
        d = p["usages"][n]
        at[n] = dict(resolved(m, d))
        at[n].update(ov.get("defs", {}).get(d, {}))
        if n in ov.get("fanOut", {}):
            at[n]["fanOut"] = ov["fanOut"][n]
    mi = int(ov.get("maxIterations", p["attrs"].get("maxIterations", 1)) or 1)
    back = back_edges(nodes, edges)
    dag = [e for e in edges if e not in back]
    oncyc = cycle_members(nodes, edges, back)
    it = {n: (mi if n in oncyc else 1) for n in nodes}
    indeg = {n: 0 for n in nodes}
    succ = {n: [] for n in nodes}
    preds = {n: [] for n in nodes}
    for a, b in dag:
        succ[a].append(b)
        indeg[b] += 1
        preds[b].append(a)
    order, q = [], [n for n in nodes if indeg[n] == 0]
    while q:
        n = q.pop(0)
        order.append(n)
        for x in succ[n]:
            indeg[x] -= 1
            if indeg[x] == 0:
                q.append(x)
    fan = {}
    for n in order:
        fan[n] = max((fan.get(x, 1) * int(at[x].get("fanOut", 1) or 1) for x in preds[n]),
                     default=1)
    for n in nodes:
        fan.setdefault(n, 1)
    best = {n: 0 for n in nodes}
    for n in order:
        own = int(at[n].get("latencyMs", 0) or 0) * it[n]
        best[n] = (max(best[x] for x in preds[n]) if preds[n] else 0) + own
    rows = []
    for n in nodes:
        c = int(at[n].get("costTokens", 0) or 0)
        l = int(at[n].get("llmCalls", 0) or 0)
        rows.append((n, p["usages"][n], c, fan[n], it[n], c * fan[n] * it[n], l * fan[n] * it[n]))
    return {"rows": rows, "cost": sum(r[5] for r in rows), "llm": sum(r[6] for r in rows),
            "latency": max(best.values()) if best else 0, "maxIterations": mi,
            "back": sorted(back), "on_cycle": oncyc, "attrs": at, "edges": edges,
            "dag": dag, "declared_bound": "maxIterations" in p["attrs"]}


def main(argv):
    import sys
    m = read(sys.stdin.read())
    if not m["patterns"]:
        print("no pattern found (a part def with part usages or flows)")
        return 1
    budget = int(m["reqs"].get("CostBudget", {}).get("budgetTokens", 0) or 0)
    want = [a for a in argv if not a.startswith("--")]
    for a in argv:
        if a.startswith("--budget="):
            budget = int(a.split("=", 1)[1])
    names = want or list(m["patterns"])
    bad = [n for n in names if n not in m["patterns"]]
    if bad:
        print(f"unknown pattern(s): {', '.join(bad)}; have {', '.join(m['patterns'])}")
        return 1
    print(f"budget: {budget:,} tokens" if budget else
          "budget: none (no CostBudget.budgetTokens) - cost_budget would stay silent")
    fails = 0
    for name in names:
        a = analyse(m, name)
        print(f"\n== {name}  maxIterations={a['maxIterations']}"
              f"{'' if a['declared_bound'] else ' (undeclared, 1 assumed)'}"
              f"  cycles={['%s->%s' % e for e in a['back']] or 'none'}")
        print(f"   {'stage':<14}{'def':<24}{'tok':>6}{'fanIn':>6}{'iter':>5}{'cost':>8}{'llm':>5}{'share':>7}")
        for n, d, c, f, i, tot, llm in sorted(a["rows"], key=lambda r: -r[5]):
            share = f"{tot / a['cost']:.0%}" if a["cost"] else "-"
            print(f"   {n:<14}{d:<24}{c:>6}{f:>6}{i:>5}{tot:>8}{llm:>5}{share:>7}")
        verdict = ("" if not budget else
                   ("  PASS" if a["cost"] <= budget else "  FAIL"))
        fails += bool(budget and a["cost"] > budget)
        print(f"   TOTAL cost {a['cost']:,} tokens, {a['llm']} model calls, "
              f"latency {a['latency']:,} ms{verdict}")
        # design-space grid: maxIterations x fan-out of every fanning stage
        fanning = {n: int(a["attrs"][n].get("fanOut", 1) or 1)
                   for n in a["attrs"] if int(a["attrs"][n].get("fanOut", 1) or 1) > 1}
        iters = sorted({1, a["maxIterations"], a["maxIterations"] + 1}) if a["back"] else [1]
        fans = sorted({1, 2, *fanning.values()}) if fanning else [None]
        if len(iters) * len(fans) <= 1:
            continue
        print(f"   grid (cost tokens / llm calls / latency ms)"
              f"{' - fanOut applied to ' + ', '.join(fanning) if fanning else ''}")
        for f in fans:
            cells = []
            for i in iters:
                ov = {"maxIterations": i}
                if f is not None:
                    ov["fanOut"] = {n: f for n in fanning}
                r = analyse(m, name, ov)
                mark = "" if not budget else ("+" if r["cost"] <= budget else "x")
                cells.append(f"it={i}: {r['cost']:>6,}/{r['llm']:>3}/{r['latency']:>6,}{mark}")
            label = f"fanOut={f}" if f is not None else "no fan-out"
            print(f"   {label:<11} " + "  ".join(cells))
        if budget and a["back"]:
            nxt = analyse(m, name, {"maxIterations": a["maxIterations"] + 1})["cost"]
            if a["cost"] <= budget < nxt:
                print(f"   SENSITIVE: passes at {a['cost']:,}, fails at {nxt:,} with one more "
                      f"iteration (what cost_sensitivity reports)")
    print("\nlegend: + within budget, x over budget. Worst case: cycle stages x maxIterations, "
          "cost x upstream fan-out, exclusive branches counted as if both run.")
    return 1 if fails else 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv[1:]))
