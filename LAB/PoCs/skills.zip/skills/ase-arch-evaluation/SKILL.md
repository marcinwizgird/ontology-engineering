---
name: ase-arch-evaluation
description: >
  Run A5 (explore the architectural options) and A6 (evaluate the
  architecture with the stakeholders) of the ASE process for an agentic
  system in SysML v2 - generate options from perspective tactics, express
  them as scratch design variants and variation/variant, compare them
  numerically with the sysmlagents analysis, run a trade study, apply the
  SEI ATAM vocabulary (utility tree, sensitivity points, tradeoff points,
  risks, non-risks, risk themes) and CBAM where money decides, choose an
  R&W evaluation approach, and build the evidence pack (stakeholder ->
  concern -> viewpoint/perspective -> check -> finding -> decision) that a
  stakeholder decides on. Use when a design fails or barely meets a budget,
  when alternatives must be compared, for design-space exploration, trade
  studies, architecture reviews, ATAM-style evaluations or acceptance of an
  AD. Do not use for writing quality scenarios in the first place (use
  ase-arch-scenarios) or for applying one quality concern's tactics in depth
  (use the matching ase-perspective-* skill).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Architecture evaluation - options (A5) and stakeholder evaluation (A6)

Load `ase-arch-sysml-foundations` first; `ase-arch-definition-process` says
when you are here. Read the frame with `ase_step("A5")`, `ase_step("A6")` and
what governs them with `ase_controls("A5")`. Viewpoints, perspectives and the
pattern library are controls; stakeholder agreement is a control on A8.

Sources, paraphrased: R&W 2nd ed. ch7 (steps 5-6) and ch14 (evaluating the
architecture); SEI ATAM (CMU/SEI-2000-TR-004) and CBAM (CMU/SEI-2002-TR-035);
SysML v2 `TradeStudies` library.

## What the two steps are for

- **A5 Explore the options.** Run the scenarios against the draft models,
  investigate the risk and uncertainty they expose, and where real
  alternatives exist weigh them and pick. Output: more detailed views where
  it mattered, decisions with alternatives.
- **A6 Evaluate with the stakeholders.** Walk a representative set of
  stakeholders through the views *and the perspective outputs*, capture
  deficiencies, and gain acceptance. Output: review comments and accepted
  (or rejected) decisions. Unacceptable results loop through A7/A8 to A5.

**The agent drafts; the stakeholder decides.** The agent builds options,
numbers, the evidence pack and a recommendation. An `@ArchitectureDecision`
with `status = "accepted"` has a stakeholder *role* as `owner`, never the
agent; `evidence_pack.py` fails otherwise.

## Choosing the evaluation approach (R&W ch14)

| Approach | When | Agentic form | SysML output |
|---|---|---|---|
| Presentation | early, to align; low assurance | walk the Context and Functional views with the sweep summary | review comments as `@Risk` / `@Assumption` |
| Formal review / structured walkthrough | a view or a decision needs expert scrutiny | walk each A2 scenario through the walkthrough `action def`s | `@Finding` per defect, owner per action |
| Scenario-based evaluation (ATAM-style) | significant quality tradeoffs; several stakeholder groups | utility tree over `@QualityScenario`s, each analysed with checks and calcs | risks, non-risks, sensitivity and tradeoff points |
| Prototype / proof of concept | an element of unknown behaviour dominates (always: the LLM) | measure `latencyMs`, `costTokens`, groundedness on the eval set | measured values replace estimates; `verification def` |
| Skeleton system | end-to-end risk (integration, providers) | generated program on the chosen option, run on the eval set | `run.json` metrics carried as findings |

Pick by risk, not habit: an option that passes only on declared estimates
needs a prototype before acceptance.

## A5 - explore the options

### 1. Find where options are needed

Run the sweep on the candidate (`python -m sysmlagents.cli explain <RS-xx>`).
Every error-severity finding, every verdict within ~10% of a budget, and
every `cost_sensitivity` hit is a decision point. So is every A2 scenario the
walkthrough could not complete.

### 2. Generate options from tactics

Each option applies named tactics from the perspective skills (make design
compromises, consolidate workload, degrade gracefully, route by data class,
...). Always include the as-matched design as option A, and an option that
*relaxes a requirement* when no design passes - that is an A8 proposal,
labelled as such, never a silent tuning.

### 3. Express the options in SysML

Two forms, used together:

- **Scratch variants for analysis.** One plain `part def` per option in a
  scratch file (e.g. `designs/RS-06/options.sysml`), reusing the design's
  stage defs; change one or two parameters per option. `model_reader`
  cannot resolve variants, so the analysable options stay plain.
- **`variation` / `variant` for the record**, in `ad/decisions.sysml`:

```
variation part def CopilotOption {
    variant part optB : OptionB;
    variant part optC : OptionC;
}
```

The accepted design in `design.sysml` is always variant-free.

### 4. Compare numerically

```
from sysmlagents.analysis import analyse, compare, conformance, viable
r = analyse("designs/RS-06/options.sysml")
print(compare(r)); print(viable(r))
```

`compare` gives stages, LLM calls, latency, cost, bounded, provenance and
fallback count per option; `viable` lists options whose every requirement
holds; `registry.run` on the projected options gives the check findings. For
one option in its own folder, `python -m sysmlagents.cli explain <folder>`.
Build the design-space table from this output, never from prose:

| Option | Change | ms | tokens | LLM calls | Verdict |
|---|---|---|---|---|---|
| A | as matched: fanOut 4, maxIter 5 | 16 575 | 68 600 | 46 | fails both |
| B | fanOut 1, maxIter 1 | 3 715 | 4 900 | 4 | passes |
| C | fanOut 2, no check loop | 3 015 | 6 200 | 4 | passes; FR-4 deferred |
| D | fanOut 2, maxIter 2 | 6 930 | 15 400 | 11 | fails both |

(RS-06, 5 s / 10 000-token budgets, library estimates.) State each option's
sacrifice in requirement terms (C sacrifices FR-4, D sacrifices QR-1).

### 5. Trade study

Among viable options, a weighted-utility trade study (shape of the OMG
`TradeStudyExample`):

```
analysis copilotTrade : TradeStudy {
    subject : CopilotOption = (optB, optC);
    objective : MaximizeObjective;
    calc :>> evaluationFunction {
        in part option :>> alternative : CopilotOption;
        return :>> result : Real;   // weighted utility, computed by the delegate
    }
    return part :>> selectedAlternative : CopilotOption;
}
```

Weights come from the stakeholders' stated priority (RS-06: latency, then
cost, then breadth), recorded in `doc`. If the gate rejects `TradeStudies`,
fall back to an `analysis def` with one `in` per option.

**CBAM, when money decides.** For each option: utility gained per scenario
(expected minus current response, on a 0-100 curve the stakeholders set),
weighted by scenario priority and summed into a benefit; divide by cost
(build effort plus run cost - tokens per question times volume). Rank by
that ratio within the budget. Record the curves and weights as
`@Assumption`s; the ratio goes into the decision's rationale.

### 6. Record the ATAM analysis vocabulary

For each high-priority scenario (utility tree leaves `priority = "H,H"`
first):

| ATAM term | SysML (AD kit) | How to find it in ASE |
|---|---|---|
| Sensitivity point | `@SensitivityPoint { parameter; quality; evidence; }` | a verdict flips on one plausible parameter change (scratch variant, `cost_sensitivity`) |
| Tradeoff point | `@TradeoffPoint { parameter; improves; degrades; evidence; }` | one parameter moves two checks in opposite directions (fanOut: breadth vs cost; maxIterations: groundedness vs latency) |
| Risk | `@Risk { id; decision; statement; concern; severity; }` | a decision problematic for a scenario; an assumption nobody verified |
| Non-risk | `@NonRisk { decision; statement; }` | a decision shown safe, with the number |
| Risk theme | a parent `concern def` or a shared `concern` value grouping risks | several risks on one concern or tactic - report to the business driver |

## A6 - evaluate with the stakeholders

### 7. Build the evidence pack

Per concern, the chain the method requires: stakeholder HOLDS concern ->
FRAMED by viewpoint / perspective -> perspective applied (`satisfy ... by`)
-> DECLARES checks -> `@Finding` -> `@ArchitectureDecision` / `@Risk`.

```
run_skill_script("ase-arch-evaluation", "evidence_pack.py",
                 stdin=<design.sysml + ad/*.sysml [+ methodology/ase-methodology.sysml]>)
```

It prints one chain per design concern (BROKEN with the missing link), then
decision, risk, non-risk, sensitivity and tradeoff tables. Pass the
methodology on stdin to use the live framing; otherwise it uses an embedded
snapshot. A review-only perspective (Location, Usability, Accessibility,
Internationalization) completes a chain only with a decision recording the
review. The Regulation check `evidence_generable` asks the same question
at requirement level in the sweep.

### 8. Present and decide

Present conflicts as tradeoff points with numbers, one table per decision;
give the agent's recommendation and its reason separately from the choice.
Record the stakeholder's words in the decision; set `status = "accepted"`
and `owner` to their role only after they decide. A deferred requirement
keeps its `requirement def` with `// UNALLOCATED <Name> - deferred by AD-x`,
so `requirement_traceability` shows it as deferred, not dropped. A
requirement change is an A8 proposal (`status = "proposed"`) until accepted.

## Analysis this skill runs

| Question | Engine |
|---|---|
| Which verdicts need options? | sweep: `latency_budget`, `cost_budget`, `llm_call_count`, `cost_sensitivity`, security / availability errors |
| Numbers per option | `analyse()` + `compare()`; `viable()`; `conformance()` for `satisfy` claims the analysis contradicts |
| Findings per option | `registry.run` over the projected scratch file |
| Weighted choice among viable options | `TradeStudy` analysis (delegate computes) |
| Is each concern evidenced end to end? | `evidence_pack.py`; `evidence_generable`, `concern_coverage` |
| AD completeness before presenting | `check_ad.py` |

## Reasoning over the model

- **Sensitivity by construction.** Change one parameter per scratch variant;
  a verdict that flips is a sensitivity point, two opposed checks moving is
  a tradeoff point. Do not change two parameters and attribute the effect.
- **Closed world.** A clean check means "no declared counter-example"; each
  non-risk names the attributes and flows it rests on.
- **Projection limits.** AD-kit metadata, views and `verification def`s are
  not projected: `verification_coverage`, `envelope_gate` and
  `progress_conditions` fire on every design. Present them as accepted
  findings citing the limit, not as risks. `evidence_pack.py` reads the
  AD-kit text directly for that reason.
- **Estimates vs measurements.** Every option number is conditional on the
  declared stage estimates; say so in the pack, and schedule the prototype
  that replaces them for the chosen option.

## Pitfalls -> detection

| Pitfall | Detection |
|---|---|
| Option table written from prose | numbers not reproducible by `compare(analyse())` on the scratch file |
| Silent tuning (fanOut / maxIterations changed and presented as meeting the spec) | parameter differs from the matched pattern with no decision naming the sacrificed requirement |
| Design generated for a failing option | `designs/<RS>/design.sysml` fails `latency_budget` / `cost_budget` with no accepted relaxation |
| Agent ratifies its own draft | accepted decision owned by a non-stakeholder (`evidence_pack.py`) |
| Requirement dropped instead of deferred | requirement def removed; no `UNALLOCATED ... deferred` marker |
| Only one stakeholder group consulted | concerns of other holders have no finding in the pack |
| Evaluation by presentation only for a high-risk element | no prototype or `verification def` for the LLM stage whose estimate decides |
| Risks listed, never themed | many `@Risk` on one concern, no theme reported to the business driver |
| Library edited to make an option pass | `models/` diff non-empty |

## Checklist

Every failing or marginal verdict has options, including the as-matched one
and, if nothing passes, a labelled relaxation; option numbers come from the
analysis; each option states the requirement it sacrifices; sensitivity and
tradeoff points recorded with evidence; risks and non-risks attached to
decisions; risk themes named; evaluation approach chosen by risk; evidence
pack complete for every concern; stakeholders chose and own the accepted
decisions; deferred requirements visible; assumptions have `revisitWhen`.

## Output contract

In `ad/decisions.sysml` (options may live in a scratch file alongside):

1. the design-space table (in `doc`) produced by `compare(analyse())`
2. `variation` / `variant` of the options and the trade study analysis
3. `@Finding` per decisive check result; `@SensitivityPoint`,
   `@TradeoffPoint`, `@Risk`, `@NonRisk`
4. `@ArchitectureDecision` per choice - `proposed` from the agent,
   `accepted` only with a stakeholder owner and their words
5. `// UNALLOCATED <Req> - deferred by <AD-id>` for deferred requirements
6. the evidence pack output, and a `verification def` for each re-open trigger

Validate: gate; `check_ad.py` (fragment first, then the whole AD);
`evidence_pack.py` exits 0. Worked RS-06 example: `references/example.sysml`.
