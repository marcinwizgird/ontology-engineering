#!/usr/bin/env python3
"""Tier-3 report: the A6 evidence pack, drafted from the AD text.

Reads an architecture description (SysML v2 files concatenated on stdin:
design + ad/*.sysml, optionally methodology/ase-methodology.sysml) and prints,
per design concern, the evidence chain the ASE method requires:

    stakeholder -> concern -> framing viewpoint / perspective (applied?)
                -> declared checks -> @Finding -> @ArchitectureDecision / @Risk

then tables of decisions, risks, non-risks, sensitivity and tradeoff points.
A break anywhere in a chain is reported as BROKEN with the missing link.

Framing comes from AseMethodology: parsed from stdin when the package is
present, otherwise from the snapshot embedded below (ase-methodology.sysml,
2026-09-30) - pass the methodology on stdin to use the live one.

Also flags an accepted decision whose owner is not a declared stakeholder
role: the agent drafts, the stakeholder decides.

Text-level, closed-world: it sees only what the AD declares. It drafts the
pack for a stakeholder to read; it never accepts anything. Exit 1 when a
chain is broken, a decision is accepted by a non-stakeholder, or the input
has no design concern; 0 otherwise.
"""

import re
import sys

SNAPSHOT = """
package AseMethodology {
viewpoint def ContextViewpoint { frame SystemBreakdown; }
viewpoint def FunctionalViewpoint { frame SystemBreakdown; }
viewpoint def InformationViewpoint { frame InformationFlow; frame AnswerGroundedness; }
viewpoint def ConcurrencyViewpoint { frame ConcurrencyAndFanOut; frame Termination; }
viewpoint def DevelopmentViewpoint { frame Buildability; }
viewpoint def DeploymentViewpoint { frame DeploymentTopology; }
viewpoint def OperationalViewpoint { frame OperationalVisibility; frame FailureBehaviour; }
viewpoint def AutonomyViewpoint { frame AutonomyAndAuthority; }
viewpoint def KnowledgeViewpoint { frame AnswerGroundedness; frame InformationFlow; }
requirement def SecurityPerspective { @Perspective { checks = "trust_escalation,data_exposure,tool_authorisation,sandbox_consistency,trust_declared"; } frame PrivilegeBoundaries; frame DataExposure; }
requirement def PerformanceAndScalabilityPerspective { @Perspective { checks = "latency_budget,critical_path,fanout_compounding"; } frame LatencyBudget; frame ConcurrencyAndFanOut; }
requirement def AvailabilityAndResiliencePerspective { @Perspective { checks = "articulation_points,minimum_cut,fallback_coverage,cascade_depth"; } frame FailureBehaviour; }
requirement def EvolutionPerspective { @Perspective { checks = "variation_rules,vocabulary_conformance,orphan_stages,dangling_exits,duplicate_capability"; } frame Buildability; }
requirement def RegulationPerspective { @Perspective { checks = "requirement_traceability,verification_coverage,evidence_generable,concern_coverage,check_coverage,orphan_stakeholder,high_risk_classification"; } frame RegulatoryEvidence; frame Reproducibility; }
requirement def DevelopmentResourcePerspective { @Perspective { checks = "build_surface"; } frame Buildability; }
requirement def LocationPerspective { @Perspective { checks = ""; } @ReviewOnly { reason = "x"; } frame DeploymentTopology; }
requirement def UsabilityPerspective { @Perspective { checks = ""; } @ReviewOnly { reason = "x"; } frame OperationalVisibility; }
requirement def AccessibilityPerspective { @Perspective { checks = ""; } @ReviewOnly { reason = "x"; } frame OperationalVisibility; }
requirement def InternationalizationPerspective { @Perspective { checks = ""; } @ReviewOnly { reason = "x"; } frame InformationFlow; }
requirement def CostPerspective { @Perspective { checks = "cost_budget,llm_call_count,cost_sensitivity"; } frame CostPerInteraction; }
requirement def GroundednessPerspective { @Perspective { checks = "provenance_paths,citation_carriers,unsourced_stages"; } frame AnswerGroundedness; }
requirement def DriftPerspective { @Perspective { checks = "bounded_cycles,progress_conditions,envelope_gate"; } frame BehaviouralDrift; frame Termination; }
part def SystemsEngineer; part def SoftwareEngineer; part def ProductOwner;
part def ComplianceOfficer; part def SecurityArchitect; part def SiteReliabilityEngineer;
part def FinanceOwner; part def EndUser;
concern def SystemBreakdown { stakeholder a : SystemsEngineer; stakeholder b : SoftwareEngineer; }
concern def InformationFlow { stakeholder a : SystemsEngineer; stakeholder b : ComplianceOfficer; }
concern def AnswerGroundedness { stakeholder a : ComplianceOfficer; stakeholder b : EndUser; }
concern def ConcurrencyAndFanOut { stakeholder a : SoftwareEngineer; stakeholder b : SiteReliabilityEngineer; }
concern def Termination { stakeholder a : SoftwareEngineer; stakeholder b : SiteReliabilityEngineer; }
concern def CostPerInteraction { stakeholder a : FinanceOwner; stakeholder b : ProductOwner; }
concern def LatencyBudget { stakeholder a : EndUser; stakeholder b : SiteReliabilityEngineer; }
concern def PrivilegeBoundaries { stakeholder a : SecurityArchitect; stakeholder b : ComplianceOfficer; }
concern def DataExposure { stakeholder a : SecurityArchitect; stakeholder b : ComplianceOfficer; }
concern def FailureBehaviour { stakeholder a : SiteReliabilityEngineer; stakeholder b : SoftwareEngineer; }
concern def OperationalVisibility { stakeholder a : SiteReliabilityEngineer; stakeholder b : ComplianceOfficer; }
concern def AutonomyAndAuthority { stakeholder a : ComplianceOfficer; stakeholder b : ProductOwner; }
concern def BehaviouralDrift { stakeholder a : ComplianceOfficer; stakeholder b : SystemsEngineer; }
concern def Reproducibility { stakeholder a : ComplianceOfficer; stakeholder b : SoftwareEngineer; }
concern def Buildability { stakeholder a : SoftwareEngineer; stakeholder b : ProductOwner; }
concern def DeploymentTopology { stakeholder a : SiteReliabilityEngineer; stakeholder b : FinanceOwner; }
concern def RegulatoryEvidence { stakeholder a : ComplianceOfficer; }
}
"""


def strip(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"(?m)^\s*//[^\n]*", " ", text)


def body_at(text, i):
    depth, j = 0, i
    while j < len(text):
        depth += {"{": 1, "}": -1}.get(text[j], 0)
        if depth == 0:
            return text[i + 1:j], j
        j += 1
    return text[i + 1:], len(text)


def blocks(text, header):
    for m in re.finditer(header, text):
        i = text.find("{", m.end() - 1)
        if i < 0 or ";" in text[m.end():i]:
            continue
        yield m, body_at(text, i)[0]


def split_methodology(text):
    m = re.search(r"\bpackage\s+AseMethodology\s*\{", text)
    if not m:
        return text, None
    body, end = body_at(text, m.end() - 1)
    return text[:m.start()] + text[end + 1:], body


def metadata(text, name):
    for m in re.finditer(r"@(?:\w+::)*" + name + r"\s*\{(.*?)\}", text, re.S):
        yield dict(re.findall(r"(\w+)\s*=\s*\"(.*?)\"\s*;", m.group(1), re.S))


def read_methodology(text):
    framers, checks, review, stakeholders, holds = {}, {}, set(), set(), {}
    for m, body in blocks(text, r"\b(?:viewpoint|requirement)\s+def\s+(\w+)[^;{]*"):
        name = m.group(1)
        if not (name.endswith("Viewpoint") or name.endswith("Perspective")):
            continue
        for c in re.findall(r"\bframe\s+(?:concern\s+\w+\s*:\s*)?(?:\w+::)*(\w+)", body):
            framers.setdefault(c, []).append(name)
        p = next(metadata(body, "Perspective"), None)
        if p is not None:
            checks[name] = [c for c in p.get("checks", "").split(",") if c]
        if re.search(r"@(?:\w+::)*ReviewOnly\b", body):
            review.add(name)
    stakeholders |= set(re.findall(r"\bpart\s+def\s+(\w+)", text))
    for m, body in blocks(text, r"\bconcern\s+def\s+(\w+)[^;{]*"):
        holds[m.group(1)] = re.findall(r"stakeholder\s+\w+\s*:\s*(?:\w+::)*(\w+)", body)
    return framers, checks, review, stakeholders, holds


def main():
    raw = sys.stdin.read()
    text = strip(raw)
    design, meth = split_methodology(text)
    source = "stdin" if meth is not None else "embedded snapshot 2026-09-30"
    framers, checks, review, meth_sh, meth_holds = read_methodology(meth or SNAPSHOT)

    concerns = []
    for m, body in blocks(design, r"\bconcern\s+def\s+(\w+)\s*(?::>\s*((?:\w+::)*\w+))?[^;{]*"):
        parent = m.group(2).split("::")[-1] if m.group(2) else None
        sh = re.findall(r"stakeholder\s+\w+\s*:\s*(?:\w+::)*(\w+)", body)
        concerns.append((m.group(1), parent, sh or meth_holds.get(parent, [])))
    if not concerns:
        print("FAIL - no concern def in the input: an evidence pack starts from the A1 concerns")
        return 1

    local_frames = {}
    for m, body in blocks(design, r"\b(?:viewpoint|requirement|view)\s+def\s+(\w+)[^;{]*"):
        for c in re.findall(r"\bframe\s+(?:concern\s+\w+\s*:\s*)?(?:\w+::)*(\w+)", body):
            local_frames.setdefault(c, []).append(m.group(1))
    allocated = set(re.findall(r"satisfy\s+(?:requirement\s+)?(?:\w+::)*(\w+Perspective)\s+by", design))
    viewed = set(re.findall(r"satisfy\s+requirement\s+\w+\s*:\s*(?:\w+::)*(\w+Viewpoint)", design))
    design_sh = set(re.findall(r"\bpart\s+def\s+(\w+)\s*:>\s*(?:\w+::)*(?:" +
                               "|".join(sorted(meth_sh)) + r")\b", design)) if meth_sh else set()
    roles = design_sh | meth_sh

    decisions = list(metadata(design, "ArchitectureDecision"))
    findings = list(metadata(design, "Finding"))
    risks = list(metadata(design, "Risk"))
    nonrisks = list(metadata(design, "NonRisk"))
    sens = list(metadata(design, "SensitivityPoint"))
    trades = list(metadata(design, "TradeoffPoint"))
    by_id = {d.get("id", ""): d for d in decisions}
    broken = 0

    print(f"EVIDENCE PACK (draft for stakeholder review) - methodology from {source}")
    print("=" * 72)
    for name, parent, sh in concerns:
        keys = {name} | ({parent} if parent else set())
        fr = sorted(set(framers.get(name, []) + framers.get(parent or "", []) + local_frames.get(name, [])))
        applied = [f for f in fr if f in allocated or f in viewed]
        set_aside = [f for f in fr if f not in applied and
                     any(f in d.get("affects", "") + d.get("decision", "") for d in decisions)]
        chk = sorted({c for f in applied for c in checks.get(f, [])})
        fnd = [f for f in findings if f.get("check") in chk or f.get("perspective") in applied]
        dec_ids = {f.get("decision") for f in fnd if f.get("decision")}
        dec_ids |= {d.get("id") for d in decisions
                    if any(k in d.get("affects", "") for k in keys | set(applied))}
        rk = [r for r in risks if r.get("concern") in keys or r.get("decision") in dec_ids]
        gaps = []
        if not sh:
            gaps.append("no stakeholder")
        if not fr:
            gaps.append("framed by nothing")
        elif not applied and not set_aside:
            gaps.append("no framing viewpoint/perspective applied or set aside")
        only_review = applied and all(f in review for f in applied)
        if applied and not only_review and not fnd:
            gaps.append("no @Finding for any declared check")
        if only_review and not dec_ids:
            gaps.append("review-only framing and no decision recording the review")
        for f in fnd:
            if f.get("disposition") in ("accept", "waive", "defer") and not f.get("decision"):
                gaps.append(f"finding {f.get('check')} {f.get('disposition')} without decision")
        broken += bool(gaps)
        print(f"\n[{'BROKEN' if gaps else 'complete'}] concern {name}" + (f" :> {parent}" if parent else ""))
        print(f"  stakeholders : {', '.join(sh) or '-'}")
        print(f"  framed by    : {', '.join(fr) or '-'}")
        print(f"  applied      : {', '.join(applied) or '-'}" +
              (f"  (set aside by decision: {', '.join(set_aside)})" if set_aside else "") +
              ("  [review-only]" if only_review else ""))
        print(f"  checks       : {', '.join(chk) or '-'}")
        for f in fnd:
            print(f"  finding      : {f.get('check')} [{f.get('severity', '?')}/{f.get('disposition', '?')}] "
                  f"{f.get('subject', '')}: {f.get('message', '')}")
        for i in sorted(x for x in dec_ids if x):
            d = by_id.get(i, {})
            print(f"  decision     : {i} [{d.get('status', 'MISSING RECORD')}] owner {d.get('owner', '-')}")
        for r in rk:
            print(f"  risk         : {r.get('id')} [{r.get('severity')}] {r.get('statement')}")
        for g in gaps:
            print(f"  BROKEN       : {g}")

    print("\nDECISIONS")
    print(f"  {'id':<12}{'status':<12}{'owner':<26}affects")
    bad_owner = 0
    for d in decisions:
        flag = ""
        if d.get("status") == "accepted" and d.get("owner") not in roles:
            flag, bad_owner = "  <- accepted by a non-stakeholder: the agent drafts, the stakeholder decides", bad_owner + 1
        print(f"  {d.get('id', '?'):<12}{d.get('status', '?'):<12}{d.get('owner', '?'):<26}{d.get('affects', '')}{flag}")
    print("\nRISKS")
    for r in risks:
        d = by_id.get(r.get("decision", ""), {})
        state = "decision accepted" if d.get("status") == "accepted" else "OPEN (decision " + d.get("status", "missing") + ")"
        print(f"  {r.get('id', '?'):<10}{r.get('severity', '?'):<8}{r.get('decision', '-'):<12}{state:<32}{r.get('statement', '')}")
    print("\nNON-RISKS")
    for n in nonrisks:
        print(f"  {n.get('decision', '-'):<12}{n.get('statement', '')}")
    print("\nSENSITIVITY POINTS")
    for s in sens:
        print(f"  {s.get('parameter')} -> {s.get('quality')} ({s.get('evidence')})")
    print("\nTRADEOFF POINTS")
    for t in trades:
        print(f"  {t.get('parameter')}: improves {t.get('improves')}; degrades {t.get('degrades')} ({t.get('evidence')})")
    head = "FAIL" if broken or bad_owner else "OK"
    print(f"\n{head} - {len(concerns)} concern(s), {broken} broken chain(s), {len(decisions)} decision(s), "
          f"{bad_owner} accepted by a non-stakeholder, {len(risks)} risk(s)")
    print("note: closed world - chains are what the AD declares; run the sweep for current findings")
    return 1 if broken or bad_owner else 0


if __name__ == "__main__":
    sys.exit(main())
