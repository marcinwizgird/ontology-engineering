---
name: description-to-sysmlv2
description: >
  Convert a natural-language description of a system into a SysML v2 textual
  model - parts, ports, interfaces, attributes, requirements and constraints.
  Use when the request describes a system to be modelled, mentions SysML v2,
  KerML, part def, port def, requirement def, or asks for an architecture
  model in SysML. Do not use for SysML v1, XMI, plain UML class diagrams or
  OWL ontologies - those have their own skills.
version: "0.1.0"
domain: systems-modelling
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# System description to SysML v2

Produces a SysML v2 textual model from prose. The model is a *specification*,
not documentation: every element must be something a reader could build or
verify against.

## Output contract

Emit **SysML v2 textual notation and nothing else**. No prose outside `//`
comments, no code fences, no explanation before or after.

Wrap the whole model in exactly one package:

```
package <SystemName> {
    // definitions, then usages, then requirements
}
```

Naming, applied without exception:

- definition name = PascalCase (`part def QueryExecutor`)
- usage / feature name = camelCase (`part queryExecutor : QueryExecutor`)
- every `def` is declared before it is used as a type

## Step 1 - identify the system boundary

Name the system of interest. Everything inside it is a `part def`; everything
it talks to is an external `part def` referenced through a port. If the
description does not make the boundary clear, choose the narrowest reading and
record the assumption in a `//` comment.

## Step 2 - structure

For each component `C` mentioned in the description:

```
part def C {
    attribute name : Type;          // only attributes the description states
}
```

Then compose them inside the system:

```
part def System {
    part c : C;
    part d : D[1..*];               // multiplicity only when stated
}
```

Do not invent components. A component the description does not mention does
not exist.

## Step 3 - interfaces

For each connection carrying data or control:

```
port def RequestPort {
    out item request : Request;
}

interface def Link {
    end supplier : RequestPort;
    end consumer : RequestPort;
}
```

Attach ports to parts, then connect with `interface`. If the description names
a payload, model it as an `item def`.

## Step 4 - behaviour

Model behaviour only when the description states ordering, states or
conditions.

- sequenced steps -> `action def` with `first`/`then`
- lifecycle or modes -> `state def` with `transition`
- a loop with a bound -> `attribute` for the bound plus a `constraint`

See `references/constructs.md` for the exact syntax of each.

## Step 5 - requirements

Every stated obligation, budget or quality attribute becomes:

```
requirement def <Name> {
    doc /* the obligation, in the description's own words */
    attribute target : Type;
    require constraint { <expression> }
}
```

Then bind it to the design:

```
satisfy <Name> by system.component;
```

A requirement with no `satisfy` is a gap - keep it and mark it with a
`// UNALLOCATED` comment rather than deleting it or inventing an allocation.

## Step 6 - validate, then repair

Run the validator before reporting anything:

```
run_skill_script("description-to-sysmlv2", "check_model.py", stdin=<your model>)
```

- output starts with `OK` -> you are done, return the model
- otherwise -> fix every reported issue and run it again

**Never report a model as complete without a clean validator run.** If the
same diagnostic survives three repair rounds, stop and return the model
together with the diagnostic, stating plainly that it does not validate.

## Traps

Read `references/kerml-traps.md` before using `:>`, `subsets`, `redefines`,
or a multiplicity on a redefined feature. Those four constructs account for
most invalid models.
