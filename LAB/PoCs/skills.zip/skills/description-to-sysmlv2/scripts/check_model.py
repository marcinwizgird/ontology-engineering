#!/usr/bin/env python3
"""Tier-3 validator: structural checks on a draft SysML v2 textual model.

Reads SysML v2 textual notation on stdin, prints a short report on stdout.
Self-contained by design - a skill package must not import the host
application. The script body never enters the agent's context; only this
report does.

Three backends are tried in order, and the report names the one used:

    syside      the Sensmetry CLI, if it is on PATH        (semantic, authoritative)
    sysmlpy     the MIT python parser, if it is importable (syntactic + semantic)
    builtin     the structural checker below               (always available)

The builtin backend is deliberately conservative: it reports what it can prove
from the text alone and never claims spec conformance. Swapping in a real
parser is a one-line change in `run_backends`, which is the whole point of
keeping validation behind this script.

Exit code 0 when clean, 1 when issues were found.
"""

import os
import re
import shutil
import subprocess
import sys
import tempfile

TIMEOUT = 25

DEF_KINDS = (
    "part", "port", "item", "attribute", "action", "state", "interface",
    "constraint", "requirement", "calc", "analysis", "verification",
    "metadata", "enum", "occurrence", "connection", "allocation", "view",
    "viewpoint", "rendering", "concern", "case", "flow",
)

# statements that are complete without a terminator: their body is a
# block comment, which strip_noise has already removed by the time we look
NO_TERMINATOR = {"doc", "comment", "entry", "exit", "do"}

# statement keywords that legitimately open or continue a body
STATEMENT_KEYWORDS = DEF_KINDS + (
    "package", "import", "private", "protected", "public", "abstract",
    "doc", "comment", "ref", "in", "out", "inout", "end", "first", "then",
    "accept", "transition", "satisfy", "verify", "assert", "require",
    "assume", "subject", "objective", "entry", "exit", "do", "return",
    "bind", "connect", "message", "succession", "snapshot", "timeslice",
    "filter", "expose", "alias", "specializes", "subsets", "redefines",
    "perform", "exhibit", "include", "actor", "stakeholder", "frame",
    "variation", "variant", "individual", "def",
)

MULTIPLICITY = re.compile(r"\[\s*([^\]]*)\s*\]")
DEF_DECL = re.compile(
    r"\b(" + "|".join(DEF_KINDS) + r")\s+def\s+([A-Za-z_]\w*)"
)
TYPED_USE = re.compile(r":\s*([A-Za-z_]\w*(?:::[A-Za-z_]\w*)*)")
SPECIALISES = re.compile(r":>\s*([A-Za-z_]\w*)|specializes\s+([A-Za-z_]\w*)")
PACKAGE = re.compile(r"\bpackage\s+([A-Za-z_]\w*)")

# types that resolve outside the model
BUILTIN_TYPES = {
    "Integer", "Real", "Boolean", "String", "Natural", "Number", "Anything",
    "Base", "ScalarValues", "Collections", "SequenceFunctions", "Time",
    "DateTime", "Duration",
}


# --------------------------------------------------------------------------
# external backends
# --------------------------------------------------------------------------

def try_syside(text):
    """Sensmetry CLI. Returns (ok, report) or None when unavailable."""
    exe = shutil.which("syside")
    if not exe:
        return None
    tmp = None
    try:
        fd, tmp = tempfile.mkstemp(suffix=".sysml", text=True)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        proc = subprocess.run(
            [exe, "check", tmp],
            capture_output=True, text=True, timeout=TIMEOUT,
        )
        out = (proc.stdout + proc.stderr).strip()
        return proc.returncode == 0, out
    except Exception as exc:                       # never let a backend crash the gate
        return None if isinstance(exc, FileNotFoundError) else (False, str(exc)[:400])
    finally:
        if tmp and os.path.exists(tmp):
            os.unlink(tmp)


def try_sysmlpy(text):
    """MIT python parser. Returns (ok, report) or None when unavailable."""
    try:
        import sysmlpy                             # noqa: F401
    except Exception:
        return None
    try:
        parse = getattr(sysmlpy, "parse", None) or getattr(sysmlpy, "loads", None)
        if parse is None:
            return None
        parse(text)
        return True, "sysmlpy parsed the model without error"
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"[:400]


# --------------------------------------------------------------------------
# builtin structural checker
# --------------------------------------------------------------------------

def strip_noise(text):
    """Remove fences, block comments and line comments; keep line count.

    String literals are blanked too: their contents are data, and prose like
    `first-class: eight stages` inside a metadata string would otherwise be
    read as a type reference.
    """
    text = re.sub(r"```[a-zA-Z]*", "", text)
    text = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), text, flags=re.S)
    text = re.sub(r'"[^"\n]*"', '""', text)
    lines = []
    for raw in text.splitlines():
        lines.append(raw.split("//")[0].rstrip())
    return lines


def check_builtin(text):
    issues = []
    lines = strip_noise(text)
    body = "\n".join(lines)

    if not body.strip():
        return ["model is empty"]

    # -- brace balance ---------------------------------------------------
    depth = 0
    for n, line in enumerate(lines, 1):
        depth += line.count("{") - line.count("}")
        if depth < 0:
            issues.append(f"line {n}: unmatched '}}'")
            depth = 0
    if depth > 0:
        issues.append(f"{depth} unclosed '{{' at end of model")

    # -- package wrapper -------------------------------------------------
    if not PACKAGE.search(body):
        issues.append("no 'package' declaration; wrap the model in one package")

    # -- declared names --------------------------------------------------
    declared = {m.group(2) for m in DEF_DECL.finditer(body)}
    declared |= {m.group(1) for m in PACKAGE.finditer(body)}

    dupes = {}
    for m in DEF_DECL.finditer(body):
        dupes[m.group(2)] = dupes.get(m.group(2), 0) + 1
    for name, count in sorted(dupes.items()):
        if count > 1:
            issues.append(f"'{name}' is defined {count} times; names must be unique")

    # -- unresolved type references --------------------------------------
    referenced = set()
    for m in TYPED_USE.finditer(body):
        referenced.add(m.group(1).split("::")[-1])
    for m in SPECIALISES.finditer(body):
        referenced.add((m.group(1) or m.group(2)))

    imported = "import" in body
    unresolved = sorted(
        r for r in referenced
        if r and r not in declared and r not in BUILTIN_TYPES
    )
    if unresolved and not imported:
        issues.append(
            "unresolved type reference(s): " + ", ".join(unresolved[:8])
            + ("..." if len(unresolved) > 8 else "")
            + " - declare them or import the library that defines them"
        )

    # -- multiplicity ----------------------------------------------------
    for n, line in enumerate(lines, 1):
        for m in MULTIPLICITY.finditer(line):
            spec = m.group(1).strip()
            if spec in ("*", ""):
                continue
            if ".." in spec:
                lo, _, hi = spec.partition("..")
                lo, hi = lo.strip(), hi.strip()
                if not lo.isdigit():
                    issues.append(f"line {n}: multiplicity lower bound '{lo}' is not a number")
                    continue
                if hi != "*" and not hi.isdigit():
                    issues.append(f"line {n}: multiplicity upper bound '{hi}' is not a number or '*'")
                    continue
                if hi != "*" and int(hi) < int(lo):
                    issues.append(f"line {n}: multiplicity [{spec}] has upper bound below lower bound")
            elif not spec.isdigit():
                issues.append(f"line {n}: multiplicity '[{spec}]' is not a valid bound")

    # -- statement termination -------------------------------------------
    for n, line in enumerate(lines, 1):
        s = line.strip()
        if not s or s.startswith(("//", "/*", "*")):
            continue
        if s.endswith(("{", "}", ";", ",")):
            continue
        # a continued expression inside a constraint body is legal
        first = s.split()[0].rstrip(":").lstrip("@")
        if first in NO_TERMINATOR:
            continue
        if first in STATEMENT_KEYWORDS:
            issues.append(f"line {n}: statement does not end with ';' or '{{' -> {s[:60]!r}")

    # -- redefinition keyword position ------------------------------------
    for n, line in enumerate(lines, 1):
        s = line.strip()
        if re.search(r"\b([A-Za-z_]\w*)\s+(redefines|subsets)\s+\1\b", s):
            issues.append(
                f"line {n}: '<name> redefines <same name>' - the keyword goes "
                f"before the name, e.g. 'part redefines request : T;'"
            )

    # -- naming conventions ----------------------------------------------
    for m in DEF_DECL.finditer(body):
        name = m.group(2)
        if not name[0].isupper():
            issues.append(f"definition '{name}' should be PascalCase")

    # -- requirement allocation -------------------------------------------
    reqs = {m.group(2) for m in DEF_DECL.finditer(body) if m.group(1) == "requirement"}
    satisfied = set(re.findall(r"\bsatisfy\s+([A-Za-z_]\w*)", body))
    unallocated = sorted(r for r in reqs - satisfied)
    for r in unallocated:
        if f"UNALLOCATED" not in text:
            issues.append(
                f"requirement '{r}' has no 'satisfy' - allocate it or mark it "
                f"with a // UNALLOCATED comment"
            )

    return issues


# --------------------------------------------------------------------------
# driver
# --------------------------------------------------------------------------

def run_backends(text):
    for name, fn in (("syside", try_syside), ("sysmlpy", try_sysmlpy)):
        result = fn(text)
        if result is not None:
            ok, report = result
            return name, ok, report
    issues = check_builtin(text)
    return "builtin", not issues, "\n".join(f"  - {i}" for i in issues)


def main():
    text = sys.stdin.read()
    backend, ok, report = run_backends(text)

    if ok:
        print(f"OK - model validates ({backend} backend)")
        if backend == "builtin":
            print("note: builtin structural checks only; not a conformance verdict")
        return 0

    n = report.count("\n  - ") + (1 if report.strip().startswith("- ") else 0)
    header = f"{n} issue(s)" if backend == "builtin" else "validation failed"
    print(f"FAIL - {header} ({backend} backend)")
    print(report or "  - backend reported failure without detail")
    return 1


if __name__ == "__main__":
    sys.exit(main())
