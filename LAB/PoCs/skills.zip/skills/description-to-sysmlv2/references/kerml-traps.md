# KerML specialisation traps

SysML v2 inherits its type system from KerML. Four constructs carry almost all
of the semantic errors in generated models. Read this before using any of
them.

## 1. `:>` is subsetting, not typing

```
part def Backend;
part def VectorBackend :> Backend;      // VectorBackend specialises Backend
part primary : Backend;                 // primary is TYPED BY Backend
```

`:` types a usage. `:>` says one *definition* specialises another. Writing
`part primary :> Backend` is legal but means something different - it makes
`primary` a subset of some other feature named `Backend`, not an instance of
it. When you mean "is a kind of", use `:>` between definitions. When you mean
"is an instance of this kind", use `:`.

Long form, equivalent and clearer:

```
part def VectorBackend specializes Backend;
```

## 2. `subsets` vs `redefines`

Both relate a feature to a feature in a supertype. They differ in what happens
to the original.

```
part def Pipeline {
    part stages : Stage[*];
}

part def RetrievalPipeline :> Pipeline {
    part retrievalStages : Stage[2..*] subsets stages;   // ADDS a narrower set
    part stages : Stage[3];                              // WRONG - shadows silently
    part redefines stages : Stage[3];                    // REPLACES the inherited one
}
```

- `subsets` - the new feature is a subset of the inherited one; **both exist**
- `redefines` - the new feature *is* the inherited one, restated; **one exists**

Rule of thumb: if you are narrowing the type or multiplicity of something that
already exists, you want `redefines`. If you are naming a distinguished
sub-collection alongside the original, you want `subsets`.

## 3. Multiplicity on a redefinition must narrow, never widen

A redefinition may only make the multiplicity **more restrictive**:

```
part def Base {
    part items : Item[1..10];
}

part def Narrowed :> Base {
    part redefines items : Item[2..5];      // OK - inside [1..10]
    part redefines items : Item[0..20];     // INVALID - widens the bound
}
```

The same applies to types: a redefinition's type must be the inherited type or
a specialisation of it, never a generalisation.

## 4. Redefinition inside a usage needs the keyword position right

```
part def Executor {
    port request : QueryPort;
}

part def CachedExecutor :> Executor {
    port redefines request : CachedQueryPort;   // keyword BEFORE the name
}
```

Writing `port request redefines request` is a common malformation. The
keyword goes between the feature kind and the name.

## 5. Definitions cannot be used before they are declared - within reason

The language permits forward references, but generated models are far more
reliably valid when declared in dependency order:

1. `attribute def` and `item def` first
2. `port def` next
3. `part def` after their attribute and port types exist
4. `action def`, `state def`, `constraint def`
5. `requirement def` and `satisfy` last

Emit in that order and most unresolved-reference diagnostics disappear.

## 6. `end` features belong to interfaces, not parts

```
interface def Link {
    end client : QueryPort;     // correct
}

part def Wrong {
    end client : QueryPort;     // meaningless here
}
```

## 7. Every statement terminates

A feature declaration with no body ends with `;`. A declaration with a body
ends with `}` and takes no semicolon:

```
part def A;
part def B { attribute x : Integer; }
part def C { }
```

Missing semicolons are the single most common syntax failure in generated
SysML v2.
