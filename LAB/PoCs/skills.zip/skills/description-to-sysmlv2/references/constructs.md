# SysML v2 construct reference

Minimal correct syntax for every construct this skill emits. Copy the shape;
do not improvise keywords.

## Package

```
package AgenticRetrieval {
    // everything else nests here
}
```

## Definitions and usages

SysML v2 separates the *definition* of a kind of thing from its *usage* in a
context. This distinction is the one beginners collapse; keep it.

```
part def QueryExecutor;                     // definition
part queryExecutor : QueryExecutor;         // usage, typed by the definition
```

## Attributes

```
attribute def Latency;

part def Reranker {
    attribute topK : Integer;
    attribute budgetMs : Integer = 200;     // default value
}
```

Built-in types: `Integer`, `Real`, `Boolean`, `String`. Import others from the
standard libraries when needed.

## Multiplicity

Written after the feature name, before the type colon is *not* correct - it
goes after the type:

```
part backend : Backend[1..*];
part cache : Cache[0..1];
attribute tags : String[*];
```

Forms: `[n]`, `[n..m]`, `[n..*]`, `[*]`. Omit entirely for exactly one.

## Items and flows

```
item def Query {
    attribute text : String;
}

part def Pipeline {
    part reformulator : Reformulator;
    part executor : Executor;

    flow reformulator.out to executor.in;
}
```

## Ports and interfaces

```
port def QueryPort {
    out item query : Query;
}

port def ResultPort {
    in item result : Result;
}

part def Executor {
    port request : QueryPort;
    port response : ResultPort;
}

interface def RetrievalLink {
    end client : QueryPort;
    end server : QueryPort;
}
```

`in` / `out` / `inout` give the direction. A port with no direction is an
error waiting to happen - always state it.

## Actions

```
action def Retrieve {
    in query : Query;
    out results : Result[*];
}

action def Pipeline {
    action reformulate : Reformulate;
    action retrieve : Retrieve;
    action synthesise : Synthesise;

    first reformulate then retrieve;
    then synthesise;
}
```

## States

```
state def LoopState {
    entry; then idle;

    state idle;
    state retrieving;
    state evaluating;

    transition idle_to_retrieving
        first idle
        accept QueryReceived
        then retrieving;

    transition evaluating_to_retrieving
        first evaluating
        accept Insufficient
        then retrieving;
}
```

## Constraints

```
constraint def BudgetBound {
    in iterations : Integer;
    in perIterationMs : Integer;
    in budgetMs : Integer;
    iterations * perIterationMs <= budgetMs
}

part def Loop {
    attribute maxIterations : Integer = 5;
    attribute perIterationMs : Integer = 800;
    attribute budgetMs : Integer = 3000;

    assert constraint bound : BudgetBound {
        in iterations = maxIterations;
        in perIterationMs = perIterationMs;
        in budgetMs = budgetMs;
    }
}
```

## Requirements

```
requirement def GroundedAnswer {
    doc /* Every claim in an answer must cite a retrieved chunk. */

    subject answer : Answer;
    require constraint { answer.citations->size() >= 1 }
}

part def System {
    part synthesiser : Synthesiser;
    satisfy GroundedAnswer by synthesiser;
}
```

## Verification

```
verification def GroundednessCheck {
    subject answer : Answer;
    objective {
        verify GroundedAnswer;
    }
}
```

## Metadata (correspondence links)

Use for traceability to elements outside the model - an ArchiMate element, a
ticket, a source requirement document.

```
metadata def Correspondence {
    attribute externalId : String;
    attribute externalKind : String;
}

part def Orchestrator {
    @Correspondence {
        externalId = "id-4f2a91c8";
        externalKind = "ArchiMate:ApplicationComponent";
    }
}
```

## Comments and documentation

```
// line comment

/* block comment */

part def Executor {
    doc /* Documentation attached to the element itself, not a comment. */
}
```

Prefer `doc` over `//` for anything a reader of the model needs. `//` is for
notes to the author.
