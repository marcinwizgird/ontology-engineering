---
name: ase-perspective-internationalisation
description: >
  Apply the Rozanski & Woods Internationalisation perspective to an agentic
  system's SysML v2 architecture - a review-only perspective in ASE - by
  recording language scope as a decision (e.g. "English only"), tagging
  corpora, eval sets and retrievers with a `language` extension, enforcing
  out-of-scope languages with an explicit behaviour, evaluating per
  language, and handling locale facts (currency, dates, jurisdictions)
  without silent conversion. Use for multilingual, translation, locale,
  language support, non-English users, cross-language retrieval or cultural
  neutrality questions about an ASE design. Do not use for data residency
  and regions (use ase-perspective-location) or for accessibility of the
  surface (use ase-perspective-accessibility).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Internationalisation perspective

Load `ase-arch-sysml-foundations` first. Control (read-only, read with
`ase_perspective("Internationalization")`):
`AseMethodology::InternationalizationPerspective`. The methodology element
is spelled with a z; use that exact name in SysML
(`satisfy AseMethodology::InternationalizationPerspective by ...`) and in
the `check_ad.py` directive (`perspectives=Internationalization`; the
script also accepts the s spelling as an alias). No `AseCatalogue` entry
exists yet.

## Definition

> "The ability of the system to be independent from any particular
> language, country, or cultural group" -
> `AseMethodology::InternationalizationPerspective`, source
> viewpoints-and-perspectives.info/home/perspectives.

## No computable check - and why

The control carries `@Perspective { checks = ""; }` and `@ReviewOnly`:

> "Acutely relevant to agentic systems - retrieval corpora and model
> behaviour are both language-bound - and entirely a matter of evaluation
> rather than structure. A model cannot tell you a retriever performs worse
> in Polish; an eval set can."

So the verdict "works in language X" comes only from an eval set in
language X. What the architecture can do is make the *coverage* question
checkable: which languages are in scope, which the corpus holds, which the
retriever was evaluated on, which eval sets exist. That is structure, and a
missing entry is an absence you can see.

**Applicability.** R&W: systems used, now or later, by people of more than
one language, region or culture. For an agent the test is sharper: any
free-text input channel receives other languages whether or not the spec
supports them. Even an English-only system needs a stated behaviour for
non-English input.

**Concerns.** The control frames `InformationFlow`. R&W's list, paraphrased:
character sets, text presentation and direction, language-specific needs,
cultural norms and machine translation, currency and exchange rates,
cultural neutrality. Agentic concerns: language of the corpus vs the
question, cross-lingual retrieval quality (embedding model coverage),
model quality per language, prompt language, answer language policy,
translation as an unapproved restatement of an authoritative text, per
language eval and per language cost (tokenisers spend more tokens on some
scripts), locale facts (amounts, dates, entitlements by country).

**Stakeholders.** Product owner (sets scope), users by language, content
owners of each corpus language, compliance where a translation could be
read as the authoritative text.

## Activities -> SysML

R&W: identify touch points, identify regions of concern, internationalise
the code, localise resources. In ASE:

### 1. State the language scope as a decision

A spec line like RS-01 FR-4 "English only" is a **scope decision**, not a
behaviour the assistant describes (RS-01's placeholder eval asked the
assistant "what does the system do about: English only?" - a symptom of
treating scope as content). Record it:

```
@ArchitectureDecision {
    id = "AD-I18N-01";
    decision = "Scope English only; detect other languages and answer with the English-only notice and HR pointer.";
    rationale = "Authoritative policy exists only in English; a translated answer is an unapproved policy statement (QR-3).";
    alternatives = "Translate question to English (deferred: needs a probe set per language); answer in the user's language (rejected).";
    ...
}
```

and turn it into requirements: the supported set, and what happens outside
it (`OutOfLanguageNotice`, reusing the abstention path).

### 2. Tag language on everything that is language-bound

The vocabulary has no language attribute, so declare it with `@Extension` on
the design:

```
item def PolicyCorpus {
    @AseProfile::Extension {
        reason = "Internationalization is review-only because no element says which language it covers.";
        extends = "RS01::Chunk and corpus items";
    }
    attribute language : String = "en";
}
part def MultilingualReadyRetriever :> RS01::DenseRetriever {
    @AseProfile::Extension { reason = "Embedding model quality is language-bound."; extends = "Stage vocabulary"; }
    attribute languages : String = "en";
}
```

A `languages` attribute on a stage def trips `vocabulary_conformance`; that
warning keeps the extension visible - accept it with a decision naming the
roadmap item. Tag eval sets the same way (`item def EvalSet` with
`language`, `cases`, `purpose`).

### 3. Evaluate per language - including the out-of-scope ones

One eval set per supported language, each with the same metrics. Plus a
**probe set** in likely unsupported languages that checks the out-of-scope
behaviour. A multilingual metric averaged over languages hides the weak
one; report per language.

### 4. Handle locale facts

Amounts, dates, entitlements and legal references are quoted as the source
states them - currency code, unambiguous date format - and never converted
by the model. If policies differ by country, jurisdiction becomes an
attribute of the corpus item and a retrieval filter (this crosses into
Location and Regulation); if you assume one country, record the assumption.

### 5. Localise resources, not prompts ad hoc

Fixed user-facing strings (abstention notice, HR pointer, progress
messages) live in a message catalogue by language; the synthesiser's
instructions state the answer-language policy. GEPA optimises instructions,
so the answer-language rule belongs in the non-regression set.

## Applying the perspective to each view

| View | What the perspective adds |
|---|---|
| Context | user languages and regions; which externals (model provider, embedding model) support which languages |
| Functional | language detection stage or rule; out-of-language path; translation stage only by decision |
| Information | `language` on corpus and chunk items; jurisdiction on policy items |
| Knowledge | corpus per language; cross-lingual retrieval choice |
| Deployment | model and embedding model versions with their language coverage |
| Operational | per-language quality and volume monitoring; notice rate |
| Development | message catalogue; per-language eval sets in CI |

## What the model can carry, and the rule that would compute it

| Support | SysML |
|---|---|
| Scope | requirement `supportedLanguages`, decision |
| Coverage tags | `language` on corpus / eval set items, `languages` on retriever and model stages (`@Extension`) |
| Rule | `constraint def LanguageCoverage`: every supported language is in the corpus, in the retriever's evaluated languages, and in an eval set |
| Verification | `verification def` per language set, plus the probe set |

With those attributes projected, `LanguageCoverage` is a set-membership
ABSENCE check, closed-world like every absence check: it proves the
coverage is *declared*, never that quality is adequate - that stays with
the eval. Promoting `language` into the vocabulary is the roadmap item.

## Reasoning over the model

- **What-if: add a language.** Add `"pl"` to `supportedLanguages`; list
  what lacks it - corpus, retriever `languages`, eval set, message catalogue.
  That list is the work and the evidence gap.
- **Provenance vs translation.** A translation stage between retrieval and
  answer restates the source; if its output is presented as the policy,
  set `preservesProvenance = false` on it and `provenance_paths`
  (Groundedness) will show the break. That is the computable half of the
  translation risk.
- **Cost.** Non-Latin scripts often cost more tokens per question; re-run
  `cost_budget` with per-language `costTokens` estimates.
- **Correspondence.** Every supported language corresponds to an eval set:
  `@Correspondence { kind = "refines"; rule = "every supported language has an eval set with the full metric suite"; }`.

## Tactics -> SysML change -> expected effect

| Tactic | Agentic form | SysML change | What should move |
|---|---|---|---|
| Separate presentation from content (R&W) | answer content from corpus; fixed strings from a catalogue | message catalogue item; answer contract | strings localised without prompt edits |
| Message catalogues (R&W) | abstention and notices per language | catalogue item with `language` | notice rate per language |
| Unicode throughout (R&W) | ingestion, chunking, tokenisation keep scripts intact | ingestion stage contract | no mojibake in probe set |
| Currency mechanisms (R&W) | quote, never convert | `LocaleNeutralFacts` requirement | converted amounts = 0 |
| Scope explicitly | English only with a notice | scope requirement + probe set | probe verification |
| Cross-lingual retrieval | multilingual embedding model | retriever `languages` | per-language eval |
| Translate query, not answer | question to corpus language, answer cites original | translation stage before retrieval | provenance kept |

## Pitfalls -> detection

| Pitfall (R&W, paraphrased; agentic) | Detection |
|---|---|
| Platform not available in the locale | model or embedding model with no `languages` for a supported language |
| Only similar languages considered | eval sets all in one script family while users are wider |
| Internationalising late | no `language` tag on corpus items at A4 |
| Locale mismatches on servers | date / number formatting left to the model |
| Currency exchange ignored | amounts converted by the model; no `LocaleNeutralFacts` |
| (agentic) scope stated, behaviour not | "English only" with no out-of-language requirement or probe set |
| (agentic) averaged multilingual metric | one eval set tagged with several languages and one score |
| (agentic) translated policy presented as policy | translation stage with provenance still `true` |

## Checklist

Language scope decided and recorded; out-of-scope behaviour specified and
probed; corpus, eval sets and retriever tagged with `language`; one eval
set per supported language, reported separately; locale facts quoted not
converted; jurisdiction assumption recorded; fixed strings in a catalogue;
`@ReviewOnly` reason quoted; extensions accepted by decision.

## Output contract

In `ad/perspectives.sysml`: `satisfy
AseMethodology::InternationalizationPerspective by <Design>;`; the scope
`@ArchitectureDecision`; scope, out-of-language and locale requirement
defs, each satisfied; `language` extensions on corpus, eval sets and
language-bound stages; `LanguageCoverage` constraint def; verification defs
per language plus the probe set; `@Finding` recording the review-only
position; `@Assumption` for jurisdiction.

Validate: gate; `check_ad.py` with
`// ad-check: perspectives=Internationalization`;
`ase-perspective-regulation/scripts/evidence_chain.py` for coverage. Worked
RS-01 example: `references/example.sysml`.
