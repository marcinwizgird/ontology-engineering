#!/usr/bin/env python3
"""Tier-3 analysis: allocation coverage between a design and its Deployment view.

Reads SysML v2 text on stdin - normally `design.sysml` and `ad/deployment.sysml`
concatenated - and checks the Deployment view's central correspondence rule:
every functional element runs somewhere, exactly once, and every node earns
its place.

    design       each part def that declares `flow` statements (a pattern);
                 its part usages are the functional elements (stages)
    nodes        part usages typed by a def that specialises, directly or
                 transitively, the node base (default `Node`)
    hosting      `allocation a : <HostingDef> allocate X to Y;` or a bare
                 `allocate X to Y;` - where the stage's code runs
    model        `allocation a : <ModelDef> allocate X to Y;` - which model
                 endpoint serves a stage's LLM calls

Scope directive, optional, anywhere in the input:

    // allocation-check: hosting=StageToNode model=StageToModel nodes=Node

`model=` (empty) switches model-binding checks off. The Concurrency view reuses
the script with `hosting=ElementToTask model= nodes=ConcurrencyUnit`.

Checks
    error    stage with no hosting allocation
    error    stage allocated more than once (hosting)
    error    allocation source that is no stage of any design
    error    model-calling stage (llmCalls > 0) with no model binding, or more than one
    warning  allocation target that is not a declared node
    warning  node with nothing allocated (skipped when hosting = "external-system")
    warning  stage `region` differs from its node's `region`
    warning  restricted data class on a node whose hosting is "hosted-api"
    info     model calls per pass bound to each rate-limited endpoint

Text-level and closed-world: it sees only declared allocations. Self-contained
stdlib Python. Exit 0 when there are no errors, 1 otherwise.
"""

import re
import sys

RESTRICTED = {"restricted", "pii", "regulated", "secret", "confidential"}


def strip(text):
    text = re.sub(r"\bdoc\s*/\*.*?\*/", " ", text, flags=re.S)   # the whole doc statement
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"//[^\n]*", " ", text)


class Block:
    def __init__(self, header):
        self.header = " ".join(header.split())
        self.statements = []
        self.children = []


def parse(text):
    root = Block("<root>")
    stack, buf = [root], []
    for ch in text:
        if ch == "{":
            child = Block("".join(buf))
            stack[-1].children.append(child)
            stack.append(child)
            buf = []
        elif ch == "}":
            tail = " ".join("".join(buf).split())
            if tail:
                stack[-1].statements.append(tail)
            buf = []
            if len(stack) > 1:
                stack.pop()
        elif ch == ";":
            stmt = " ".join("".join(buf).split())
            if stmt:
                stack[-1].statements.append(stmt)
            buf = []
        else:
            buf.append(ch)
    return root


ATTR = re.compile(r"^attribute\s+(?:(?:redefines|:>>)\s+)?(\w+)\s*(?::\s*[\w:]+)?\s*(?:=\s*(.+))?$")
PART_DEF = re.compile(r"^part\s+def\s+(\w+)(?:\s*(?::>|specializes)\s*([\w:]+))?")
PART_USE = re.compile(r"^part\s+(\w+)\s*:\s*([\w:]+)")
FLOW = re.compile(r"^flow\s+")
ALLOC_TYPED = re.compile(r"\ballocation\s+\w+\s*:\s*([\w:]+)\s+allocate\s+([\w:.]+)\s+to\s+([\w:.]+)")
ALLOC_BARE = re.compile(r"(?<![\w:])allocate\s+([\w:.]+)\s+to\s+([\w:.]+)")


def value(raw):
    if raw is None:
        return None
    raw = raw.strip()
    if raw in ("true", "false"):
        return raw == "true"
    try:
        return int(raw)
    except ValueError:
        return raw.strip('"')


def last(qname):
    return re.split(r"::|\.", qname)[-1]


def attrs_of(block):
    out = {}
    for s in block.statements:
        m = ATTR.match(s)
        if m and m.group(2) is not None:
            out[m.group(1)] = value(m.group(2))
    return out


def main():
    raw = sys.stdin.read()
    d = re.search(r"//\s*allocation-check:([^\n]*)", raw)
    opts = dict(re.findall(r"(\w+)=([\w]*)", d.group(1))) if d else {}
    hosting_def = opts.get("hosting", "StageToNode")
    model_def = opts.get("model", "StageToModel")
    node_base = opts.get("nodes", "Node")

    text = strip(raw)
    root = parse(text)
    defs, patterns, usages_in = {}, {}, {}   # def -> (parent, attrs)

    def walk(block):
        for b in block.children:
            h = b.header
            if h.startswith("package "):
                walk(b)
                continue
            m = PART_DEF.match(h)
            if m:
                name, parent = m.group(1), (last(m.group(2)) if m.group(2) else None)
                defs[name] = (parent, attrs_of(b))
                uses = {}
                for s in b.statements:
                    u = PART_USE.match(s)
                    if u:
                        uses[u.group(1)] = (last(u.group(2)), {})
                for c in b.children:        # part usage with a body of redefinitions
                    u = PART_USE.match(c.header)
                    if u:
                        uses[u.group(1)] = (last(u.group(2)), attrs_of(c))
                usages_in[name] = uses
                if any(FLOW.match(s) for s in b.statements):
                    patterns[name] = uses
            walk(b)

    walk(root)

    def resolved(dname):
        chain, cur, seen = [], dname, set()
        while cur in defs and cur not in seen:
            seen.add(cur)
            chain.append(defs[cur][1])
            cur = defs[cur][0]
        out = {}
        for a in reversed(chain):
            out.update(a)
        return out

    def is_node_type(dname):
        cur, seen = dname, set()
        while cur and cur not in seen:
            if cur == node_base:
                return True
            seen.add(cur)
            cur = defs.get(cur, (None, {}))[0]
        return False

    nodes = {}
    for owner, uses in usages_in.items():
        if owner in patterns:
            continue
        for u, (t, local) in uses.items():
            if is_node_type(t):
                a = resolved(t)
                a.update(local)
                nodes[u] = a

    stages = {}                               # (pattern, usage) -> attrs
    for p, uses in patterns.items():
        for u, (t, local) in uses.items():
            a = resolved(t)
            a.update(local)
            stages[(p, u)] = a

    hosting, binding, errors, warnings, info = [], [], [], [], []
    typed_spans = []
    for m in ALLOC_TYPED.finditer(text):
        typed_spans.append(m.span())
        kind = last(m.group(1))
        if kind == hosting_def:
            hosting.append((m.group(2), m.group(3)))
        elif model_def and kind == model_def:
            binding.append((m.group(2), m.group(3)))
    for m in ALLOC_BARE.finditer(text):
        if not any(a <= m.start() < b for a, b in typed_spans):
            hosting.append((m.group(1), m.group(2)))

    def resolve_source(src):
        parts = re.split(r"::|\.", src)
        u = parts[-1]
        owner = parts[-2] if len(parts) > 1 and parts[-2] in patterns else None
        hits = [k for k in stages if k[1] == u and (owner is None or k[0] == owner)]
        return hits

    host_of, model_of = {}, {}
    for kind, pairs, store in (("hosting", hosting, host_of), ("model", binding, model_of)):
        for src, dst in pairs:
            hits = resolve_source(src)
            if not hits:
                errors.append(f"{kind} allocation source {src} is no stage of any design")
                continue
            if last(dst) not in nodes:
                warnings.append(f"{kind} allocation target {dst} is not a declared node "
                                f"(no part usage typed by a {node_base} specialisation)")
            for k in hits:
                store.setdefault(k, []).append(last(dst))

    if not patterns:
        print("FAIL - no design found (no part def declares a flow)")
        return 1

    for (p, u), a in sorted(stages.items()):
        hs = host_of.get((p, u), [])
        if not hs:
            errors.append(f"{p}.{u}: not allocated to any node")
        elif len(hs) > 1:
            errors.append(f"{p}.{u}: allocated {len(hs)} times ({', '.join(hs)}) - exactly once")
        if model_def:
            ms = model_of.get((p, u), [])
            calls = int(a.get("llmCalls", 0) or 0)
            if calls and not ms:
                errors.append(f"{p}.{u}: makes {calls} LLM call(s) but is bound to no model endpoint")
            elif len(ms) > 1:
                errors.append(f"{p}.{u}: bound to {len(ms)} model endpoints - route with two stages, not one")
            elif ms and not calls:
                warnings.append(f"{p}.{u}: bound to {ms[0]} but declares llmCalls = 0")
        for n in hs[:1]:
            na = nodes.get(n, {})
            if a.get("region") and na.get("region") and a["region"] != na["region"]:
                warnings.append(f"{p}.{u}: region {a['region']} but runs on {n} in {na['region']}")
        for n in model_of.get((p, u), [])[:1]:
            na = nodes.get(n, {})
            home = a.get("region") or nodes.get(hs[0], {}).get("region") if hs else a.get("region")
            if home and na.get("region") and home != na["region"]:
                info.append(f"{p}.{u}: runs in {home}, its model calls go to {n} in {na['region']}")
        for n in hs[:1] + model_of.get((p, u), [])[:1]:
            na = nodes.get(n, {})
            if str(a.get("dataClass", "")).lower() in RESTRICTED and na.get("hosting") == "hosted-api":
                warnings.append(f"{p}.{u}: dataClass {a['dataClass']} reaches hosted API {n} - "
                                f"confirm the contract allows it or rebind to a self-hosted node")

    used = {n for v in host_of.values() for n in v} | {n for v in model_of.values() for n in v}
    for n, na in sorted(nodes.items()):
        if n not in used and na.get("hosting") != "external-system":
            warnings.append(f"node {n}: nothing allocated - remove it or allocate to it")

    for n, na in sorted(nodes.items()):
        rpm = na.get("rateLimitRpm")
        if isinstance(rpm, int) and rpm:
            calls = sum(int(stages[k].get("llmCalls", 0) or 0)
                        for k, v in model_of.items() if n in v)
            if calls:
                info.append(f"node {n}: {calls} LLM call(s) per pass bound here, {rpm} RPM "
                            f"-> ceiling {rpm // calls} passes/min before fan-out and iterations")

    total = len(stages)
    placed = sum(1 for k in stages if len(host_of.get(k, [])) == 1)
    head = "FAIL" if errors else ("OK with warnings" if warnings else "OK")
    print(f"{head} - {placed}/{total} stages allocated exactly once across "
          f"{len(patterns)} design(s); {len(nodes)} node(s)")
    for tag, items in (("error", errors), ("warning", warnings), ("info", info)):
        for i in items:
            print(f"  - {tag}: {i}")
    print("note: closed-world - only declared allocations are seen")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
