---
name: ase-viewpoint-deployment
description: >
  Build, analyse and review the Deployment view of an agentic system in SysML
  v2 following the Rozanski & Woods Deployment viewpoint - runtime platform
  (nodes), network links, technology dependencies and the relationships
  between them - with the agentic specifics first: model serving (hosted API
  vs self-hosted, rate limits in RPM and TPM, context window, GPU), regions
  and data residency, vector and search indices, source systems, and
  environments as individuals. Allocates every stage to a node and every
  model-calling stage to a model endpoint, and checks both with
  allocation_coverage.py. The calibration source for the performance model.
  Use when asked where components run, which model endpoint serves what,
  rate limits, GPU sizing, regions, environments, or to review a deployment
  model. Do not use for threads, pools and loops (use
  ase-viewpoint-concurrency) or for monitoring and runbooks (use
  ase-viewpoint-operational).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Deployment viewpoint

Load `ase-arch-sysml-foundations` first. Control:
`AseMethodology::DeploymentViewpoint` - read with `ase_viewpoint("Deployment")`
and `ase_obligations("Deployment")`. (`ase_obligations` returns the generic
Functional attribute list; this view's own obligations are the allocations
and node attributes below.)

## Definition

> "Describes the environment into which the system will be deployed,
> including capturing the dependencies" - `AseMethodology::DeploymentViewpoint`,
> source viewpoints-and-perspectives.info/home/viewpoints.

**Stakeholders**: system administrators and the SRE (`SiteReliabilityEngineer`),
developers, testers, communicators, assessors, and the `FinanceOwner` - model
serving is where most of the running cost sits. **Applicability** (R&W):
systems with complex or unfamiliar deployment environments. An agentic system
is unfamiliar by construction: a model endpoint with rate limits, a GPU
server, or a data-residency split is new to most platform teams.

**Concerns**: ASE frames `DeploymentTopology` (where does each participant
run, and what does that cost?). R&W's concerns, walked as a checklist:
runtime platform required; specification and quantity of hardware or
hosting; third-party software requirements; technology compatibility;
network requirements; network capacity required; physical constraints.
Agentic additions: model serving capacity (RPM, TPM, context window,
concurrency), hosted vs self-hosted per data class, region of each endpoint,
index and embedding infrastructure.

**Models** (R&W): runtime platform model, network model, technology
dependency model, and the relationships between them. Methodology model
string: "runtime placement, model serving, resource bindings".

## R&W model elements -> SysML v2

| R&W element | SysML v2 | ASE convention |
|---|---|---|
| Processing node | `part def X :> Node`; usage inside a deployment `part def` | every attribute on the base `Node`, subtypes only `redefines` |
| Model serving node | `part def HostedModelApi :> Node` / `OnPremModelServer :> Node` | `hosting`, `provider`, `modelId`, `rateLimitRpm`, `rateLimitTpm`, `contextWindowTokens`, `p95LatencyMs`, `gpu`, `replicas` |
| Data store node | `part def SearchIndexNode :> Node` | vector / lexical index; the *retriever* stays functional |
| External system | `part def SourceSystem :> Node` with `hosting = "external-system"` | a dependency, never a host |
| Network link | `connection def NetworkLink { end a : Node; end b : Node; attribute rttMs; attribute crossesSite; }` + `connection ... connect a to b;` | not `flow` - flows are for the design |
| Element -> node | `allocation def StageToNode` + one `allocation h : StageToNode allocate <Design>::<stage> to <deployment>.<node>;` | exactly one per stage |
| Stage -> model | `allocation def StageToModel`, one per stage with `llmCalls > 0` | routing = two stages, never one stage bound twice |
| Technology dependency | `part def TechnologyStack` with attributes, one per runtime | framework, serving engine, client libraries |
| Environment | `individual part def ProdEnv :> <Deployment>;` + `individual part prod : ProdEnv { snapshot part peak { ... } }` | prod, test tenant, DR |
| Region / residency | `region` on nodes (view) and on design stage defs via `@Extension` | feeds the Location perspective |

Keep all of it in `ad/deployment.sysml`. A deployment `part def` must not
contain `flow` statements, or the reader and the script take it for a design.

## Activities -> SysML

1. **Define the runtime platform.** One node type per kind of host: the
   application cluster, each model endpoint, each index, each external
   system. Declare every attribute on the base `Node` and only `redefines`
   in subtypes - `check_ad.py` treats new attributes on a `:>` def as stage
   attributes needing `@Extension`.
2. **Specify model serving.** For each endpoint: hosted or self-hosted,
   provider and model, region, RPM and TPM limits (hosted) or measured
   sustainable requests/min (self-hosted), context window, p95 latency at a
   stated prompt size, GPU and replicas. Every number gets an `@Assumption`
   with an owner and a revisit trigger until a measurement replaces it.
3. **Allocate.** One `StageToNode` per design usage; one `StageToModel` per
   model-calling usage. When C-2-style constraints split models by data
   class, route with two stages (`synthPublic`, `synthConfidential`) each
   bound once - a per-request binding is invisible to every check.
4. **Model the network.** A `NetworkLink` for every hop that crosses a site,
   a region or the internet, with `rttMs`. Fold the hop into the calling
   stage's `latencyMs` and record that as an assumption; a hop that matters
   architecturally (cross-region, external API) becomes its own stage.
5. **Record technology dependencies.** Framework, serving engine, client
   libraries, source-system APIs, with the version line supported. Unproven
   technology (a new serving engine, a preview model) gets a `@Risk`.
6. **Define environments.** `individual part def` per environment and a
   `snapshot part` for the load it must carry (peak users, confidential
   share). A DR environment, or the decision not to have one.
7. **Calibrate the performance model.** Carry `p95LatencyMs`, rate limits
   and capacity into the stages' `latencyMs` and into an endpoint ceiling
   `calc def`; compare to the throughput requirement. This is the only view
   whose numbers can be measured before the system exists - load-test the
   endpoints first.
8. **Declare residency.** Add `region` to the design stage defs that handle
   restricted data (`@Extension` citing `LocationPerspective`'s `@ReviewOnly`
   reason) and check it against the hosting node.

## The view

```
view def DeploymentView {
    satisfy requirement vp : AseMethodology::DeploymentViewpoint;
    filter @SysML::PartUsage or @SysML::AllocationUsage or @SysML::ConnectionUsage;
}
view runtimePlatform : DeploymentView {
    expose RS06_Deployment::production::**;
    render asInterconnectionDiagram;
}
view allocationTable : DeploymentView {
    expose RS06_Deployment::*;
    render asElementTable;       // stage, node, model endpoint, region
}
```
Keep every `filter` on one line in the file - the builtin gate is line-based.

## Analysis the deployment model supports

| Question | Engine |
|---|---|
| Is every stage placed exactly once; every LLM stage bound to exactly one endpoint? | `run_skill_script("ase-viewpoint-deployment", "allocation_coverage.py", stdin=design + deployment)` |
| Nodes that host nothing | `allocation_coverage.py` (warning; external systems exempt) |
| Stage region differs from its node's region | `allocation_coverage.py` (warning) |
| Restricted data on a hosted API | `allocation_coverage.py` (warning) - `data_exposure` cannot see it, a hosted model is not an external kind |
| Endpoint ceiling vs peak demand | `calc def EndpointCeiling` (min of RPM and TPM ceilings); `allocation_coverage.py` prints calls per pass per endpoint |
| Latency with calibrated stage times | `latency_budget`, `critical_path` after updating `latencyMs` |
| Single points of failure among nodes | none in ASE - by hand: a node hosting every stage on the critical path; `articulation_points` covers stages, not nodes |
| Residency violations | none - `LocationPerspective` is `@ReviewOnly`; the region rule above is the first computable piece |

`allocation_coverage.py` reads the directive
`// allocation-check: hosting=StageToNode model=StageToModel nodes=Node`
(the defaults). It is text-level and closed-world: an allocation not
declared does not exist to it. Exit 1 on errors.

**Calibration caveat.** The ASE analysis assumes fan-out is concurrent and
unlimited. A rate limit or a single-replica GPU server breaks that; compute
the waves with the Concurrency skill's `RateLimitedLatency` and say which
figure the finding uses.

## Reasoning over the deployment model

- *What runs where?* Follow allocations; the table rendering is the answer.
- *What leaves the site?* Every `StageToModel` to a `hosted-api` node sends the
  stage's prompt out - list the data classes those prompts can carry.
- *What if the provider throttles?* Halve `rateLimitRpm` and recompute the
  ceiling; a verdict that flips is a sensitivity point.
- *What if a node fails?* The stages allocated to it fail together; if they
  include every path to the output, that node is the single point of failure.
- Closed world: hops not in any `latencyMs`, endpoints called from inside a
  library, and fallback endpoints configured outside the model are invisible.
- Checks' blind spot: `checks.EXTERNAL_KINDS = {"WebSearchFallback"}`, matched
  on the def a usage names directly. A hosted model endpoint is not an
  external kind, so no security check sees data leaving through it - the
  restricted-on-hosted rule of `allocation_coverage.py` and a decision are the
  only record.
- Correspondences (`@Correspondence`): every design usage has one
  `StageToNode` (Functional); every limiter in the Concurrency view matches a
  rate limit here; every node has monitoring (Operational); stage `latencyMs`
  is at least its endpoint's `p95LatencyMs` plus link rtt (Performance).

## Pitfalls -> detection in the model

| Pitfall | Detection |
|---|---|
| Unclear or inaccurate dependencies | `TechnologyStack` missing, or versions absent; a source system with no node |
| Unproven technology | preview model or new serving engine with no `@Risk` |
| Unsuitable or missing SLAs | model endpoint with empty `sla`; no fallback endpoint decision |
| Lack of specialist knowledge | self-hosted GPU node with no owner in `@Assumption`s |
| Late consideration of the deployment environment | no deployment view by A5; stage `latencyMs` never compared to endpoint figures |
| Ignoring intersite complexity | a link with `crossesSite = true` whose `rttMs` is in no stage's latency |
| Inappropriate headroom | demand > 80% of an endpoint ceiling at peak (`EndpointCeiling`) |
| No DR environment | no second `individual part def` and no decision |
| (agentic) one stage, two models | a stage bound twice (script error) - route with two stages |
| (agentic) confidential prompt to a hosted API | restricted-on-hosted warning |
| (agentic) context window assumed | `contextWindowTokens` absent while a stage's prompt grows per iteration |
| (agentic) rate limit ignored by the analysis | fan-out behind a limited endpoint with no `RateLimitedLatency` |
| (agentic) infrastructure in the functional view | vector DB engine as a stage; it is a node here |

## Checklist

Every stage allocated exactly once; every model-calling stage bound to one
endpoint; every endpoint has hosting, region, limits, latency and an
assumption owner; network hops that cross a site or region modelled; the
technology stack listed with versions; environments including DR (or a
decision) declared; peak demand compared to each endpoint's ceiling;
residency of restricted data checked; stage `latencyMs` calibrated from the
nodes; decisions record hosting choices and their alternatives.

## Output contract

`ad/deployment.sysml` containing: `Node` hierarchy, deployment `part def`
and a usage; `NetworkLink` connections; `StageToNode` and `StageToModel`
allocations; `TechnologyStack`; environment individuals and snapshots;
`EndpointCeiling` calc and capacity requirement with `satisfy`;
`@Assumption`s for every serving number; `@Finding`s; `@Correspondence`;
decisions. Updates to `design.sysml`: stage `latencyMs` calibrated from the
nodes; `region` via `@Extension` where residency matters.

Validate (from `AI Skills/skills`):

```
python description-to-sysmlv2/scripts/check_model.py < ad/deployment.sysml
python ase-arch-sysml-foundations/scripts/check_ad.py < ad/deployment.sysml   # fragment directive
cat design.sysml ad/deployment.sysml | python ase-viewpoint-deployment/scripts/allocation_coverage.py
```
Worked example: `references/example.sysml` (RS-06 option C: on-prem app
cluster, hosted API for public sources, on-prem GPU server for confidential
proposals at 90% of its ceiling).
