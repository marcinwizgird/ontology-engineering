---
name: ase-perspective-accessibility
description: >
  Apply the Rozanski & Woods Accessibility perspective to an agentic
  system's SysML v2 architecture - a review-only perspective in ASE - by
  naming the presenting surface, stating requirements that reference a WCAG
  version and level, adding what an agent changes (streamed replies and
  screen readers, generated text as content, citation links, voice and
  keyboard interaction, conversation memory versus redundant entry), and
  verifying them with automated scans, assistive-technology walkthroughs and
  eval-set readability metrics. Use for accessibility, WCAG, EN 301 549,
  screen reader, keyboard, voice interaction, plain language or disability
  questions about an ASE design. Do not use for general ease of use
  (use ase-perspective-usability) or for languages and locales (use
  ase-perspective-internationalisation).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Accessibility perspective

Load `ase-arch-sysml-foundations` first. Control (read-only, read with
`ase_perspective("Accessibility")`): `AseMethodology::AccessibilityPerspective`.
No `AseCatalogue` entry exists yet.

## Definition

> "The ability of the system to be used by people with disabilities"
> - `AseMethodology::AccessibilityPerspective`, source
> viewpoints-and-perspectives.info/home/perspectives.

## No computable check - and why

The control carries `@Perspective { checks = ""; }` and `@ReviewOnly`:

> "A property of the interface, not of the agent topology. It belongs to
> whatever surface presents the system and is assessed there against WCAG,
> not here."

So no ASE check reads accessibility, and none should be invented over stage
graphs. But "assessed there" is not "absent from the AD": the architecture
must **name the surface**, **set its WCAG target**, and own the two things
the agent itself decides - the *content* (generated text, citations,
abstention messages) and the *timing* (streaming, long turnaround tasks).
Both reach the user only through the surface, and both can defeat a
conformant surface.

**Applicability.** R&W: any system used or operated by people with
disabilities, or subject to disability law. Employees and customers are
such people; treat it as applicable to every user-facing agent. Legal
drivers vary (public-sector web rules, the European Accessibility Act for
some consumer services such as banking, employer duties); EN 301 549 is the
usual EU reference and builds on WCAG. Confirm which apply with the
compliance owner - this skill does not decide that.

**Concerns.** The control frames `OperationalVisibility`. R&W's list,
paraphrased: types of disability, functional availability to disabled
users, disability regulation. Agentic concerns: screen-reader behaviour of
streamed output, readability of generated text, accessible names of
citation links, voice input and output, time limits on sessions, and not
forcing users to re-enter what the agent already knows.

**Stakeholders.** Users of assistive technology (by type: screen reader,
keyboard only, magnification, speech input, cognitive), the organisation's
accessibility lead, compliance, the team that owns the surface.

## Activities -> SysML

R&W: identify touch points, device independence, content equivalence.

### 1. Identify the touch points - the presenting surfaces

Every place a person meets the system: chat widget, email with the answer,
voice channel, operator console, generated documents (RS-08's 30-day plan).
Model each as a `part def` outside the agent topology (Context view),
carrying its target:

```
part def IntranetChatWidget {
    attribute wcagVersion : String = "2.2";
    attribute wcagLevel : String = "AA";
}
```

It is not a `Stage`, so `vocabulary_conformance` never sees it and no
`@Extension` is needed. A touch point missing here is R&W's first pitfall.

### 2. State WCAG-referenced requirements

One requirement per surface for the level, plus one per agent-specific
criterion. Keep the criterion number in `doc`; targets as numbers.

```
requirement def WcagConformanceChatSurface {
    doc /* Company standard: WCAG 2.2 level AA for intranet tools. */
    frame concern access : EqualAccessToPolicyAnswers;
    attribute wcagVersion : String = "2.2";
    attribute wcagLevel : String = "AA";
    attribute seriousViolations : Integer = 0;
}
satisfy WcagConformanceChatSurface by AccessibleDelivery::surface;
```

### 3. Add what the agent changes

| Agent behaviour | WCAG hook | Requirement |
|---|---|---|
| Streamed reply | 4.1.3 Status Messages | announce per sentence or on completion via a polite live region; never move focus |
| Generated answer text | 3.1.5 Reading Level (AAA, adopt as a target) | reading grade target on the eval set; terms explained |
| Citations | 2.4.4 Link Purpose | each link names document and section |
| Abstention / refusal message | 3.3.1 Error Identification (by analogy) | message text states what happened and the next step, as text |
| Memory across turns | 3.3.7 Redundant Entry | the agent does not ask again for what the user already gave |
| Session / long task | 2.2.1 Timing Adjustable | timeout does not discard the question or answer |
| Voice input | 2.5.3 Label in Name; OS dictation | controls are speakable; no custom key traps |
| Voice output | content equivalence | answer and citations readable as plain text; no information only in formatting |
| Mixed-language answer | 3.1.2 Language of Parts | the surface marks the language of quoted passages |
| Rich output (tables, markdown) | 1.3.1 Info and Relationships | rendered with semantic structure, not visual layout |

### 4. Verify on the surface and on the eval set

| Method | Covers | SysML |
|---|---|---|
| Automated rule scan in CI | a subset of AA criteria | `verification def` with `subject` the surface |
| Assistive-technology walkthrough | keyboard, screen readers, magnification, speech | `verification def`, tasks listed in `doc` |
| Readability metric over eval answers | generated content | `verification def` with `subject` the design |
| Test with disabled users | real effectiveness | `verification def`, participants in `doc` |

Include agent states in every scan: a streamed answer mid-flight, a
citation list, an abstention, an error, a long-task progress view.

## Applying the perspective to each view

| View | What the perspective adds |
|---|---|
| Context | every presenting surface as an external with its WCAG target |
| Functional | answer output contract: plain-text equivalent, structured citations, abstention text |
| Information | answer item fields (text, citations with titles, language) the surface needs |
| Concurrency | streaming granularity (sentence, not token) exposed to the surface |
| Operational | accessibility regressions tracked; feedback channel usable with assistive tech |
| Development | scan in CI; prompt changes re-run readability |

## What the model can carry and reason over

- **Coverage by correspondence.** Every surface has a WCAG requirement and a
  verification: `@Correspondence { kind = "refines"; fromView = "Context"; toView = "Operational"; rule = "every presenting surface has a WCAG requirement and an AT walkthrough"; }`.
  `ase-perspective-regulation/scripts/evidence_chain.py` shows requirement ->
  verification coverage.
- **Content reachability.** If the answer item carries citations and
  provenance holds (`provenance_paths`, `citation_carriers`), the surface
  *can* present accessible citations; if not, no surface can. A proxy, not
  a verdict.
- **What-if: new channel.** Adding voice or email adds a surface; the
  correspondence rule shows it has no requirement yet.
- **Would-be-computable.** A `wcagLevel` attribute on every surface part def
  plus a rule "every external reached by an answer flow has a `wcagLevel`"
  is a checkable absence rule - it needs surfaces modelled as flow targets,
  which today's projection does not do. Record it as a roadmap item.
- **Closed world.** Nothing in the model sees markup, contrast or focus.

## Tactics -> SysML change -> expected effect

| Tactic | Agentic form | SysML change | What should move |
|---|---|---|---|
| Assistive technologies (R&W) | test with screen readers and speech input | walkthrough verification def | criteria verified |
| Content equivalence | plain-text answer and citation list alongside rich rendering | `item def Answer` fields | 1.3.1 / voice output |
| Voice recognition (R&W) | dictation-friendly input; voice channel as its own surface | surface part def | 2.5.3 |
| Specialist input devices (R&W) | keyboard-only operability of every control | surface requirement | 2.1.1 |
| Chunked announcement | stream by sentence to the surface | streaming granularity in the answer contract | 4.1.3 |
| Plain-language prompting | readability instruction in the synthesiser; GEPA non-regression metric | contract `doc`; eval metric | reading grade share |
| Use memory | carry user-given facts across turns | memory stage | 3.3.7 |

## Pitfalls -> detection

| Pitfall (R&W, paraphrased; agentic) | Detection |
|---|---|
| Needs ignored until too late | no surface part def or WCAG requirement at A4 |
| Regulation not known | no compliance stakeholder on the accessibility concern |
| Suitable solutions not known | no AT walkthrough; automated scan is the only verification |
| (agentic) token-by-token live region | streaming requirement without granularity |
| (agentic) generated text never assessed | no readability metric in the eval |
| (agentic) optimiser raises reading level | GEPA objective without readability in non-regression |
| (agentic) citations as "[1]" | citation item without a title field |
| (agentic) second surface forgotten | plan document or email with no WCAG requirement |

## Checklist

All touch points modelled with a WCAG version and level; agent-specific
requirements for streaming, generated content, citations, memory, timeouts
and voice; each verified by scan, walkthrough, eval metric or user test;
compliance owner named; `@ReviewOnly` reason quoted; decision recorded.

## Output contract

In `ad/perspectives.sysml`: `satisfy AseMethodology::AccessibilityPerspective
by <Design>;`; surface part defs with `wcagVersion` / `wcagLevel`;
WCAG-referenced requirement defs, each satisfied by the surface or the
design; verification defs; `@Finding` recording the review-only position;
`@ArchitectureDecision` for the target and each agent-specific choice.

Validate: gate; `check_ad.py` with `// ad-check: perspectives=Accessibility`;
`evidence_chain.py` for coverage. Worked RS-01 example:
`references/example.sysml`.
