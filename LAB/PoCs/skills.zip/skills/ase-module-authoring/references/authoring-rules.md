# Authoring rules

Six rules. All six apply to every module. They encode what the programme
design identified as its failure modes, so they are not style preferences.

## R1 — Ship an asset

Every module produces something the factory or the business keeps after the
cohort has moved on: a pattern in the catalogue, a validated model, a rubric,
a tool, a register, a running system.

*Why:* the programme's justification is that coursework and factory build are
the same work. A module producing only learner understanding breaks that
thesis and cannot be defended against its own cost.

*Test:* name the file. If you cannot, the module is a lecture.

## R2 — Reading is load-bearing

The seminar assumes the pre-read is done, and its guiding questions must be
answerable from the cited chapters alone.

*Why:* three hours of seminar cannot also deliver four hours of content. An
instructor who lectures because the reading was skipped teaches the cohort
that reading is optional, and the remaining modules degrade.

*Test:* answer your own guiding questions from the source, without notes. If
you cannot, you cited the wrong chapter.

## R3 — The lab is the module

12 of 22 hours. Concepts serve the lab, not the reverse.

*Test:* if the lab could be removed and the module still "worked", it is a
seminar series, not a module.

## R4 — Assess artifacts, not attendance

Every exit criterion points at a file or a specific observable check. Binary:
met, or returned with specifics. No grades, no partial credit.

*Why:* grades invite negotiation; returns invite repair. Repair is the
engineering behaviour the programme is trying to build.

## R5 — Quarantine volatile content

Label perishable content explicitly, in the section where it appears. A
`volatile` module may never be a prerequisite for a `durable` one.

*Why:* the framework layer has a 12–18 month half-life. Isolation is what
allows a three-year programme to survive it — when a framework dies you
rewrite three modules, not a year.

*Test:* if this section were deleted tomorrow, would any durable module break?
If yes, the durable content is in the wrong place.

## R6 — At least one honest negative

Every module teaches something that does not work, a case where the technique
is wrong, or a limit of the method.

*Why:* a curriculum without negatives produces advocates rather than
engineers. The most valuable judgement in the whole programme — when *not* to
build an agentic system, when a model cannot settle a question, when analysis
is a hypothesis rather than a result — is taught entirely through negatives.

*Test:* find the sentence. If there isn't one, the module is selling something.
