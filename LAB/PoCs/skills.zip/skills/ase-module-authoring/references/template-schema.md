# Module template schema

Exact headings, in order. The checker matches on these.

```
# Module <N> — <title>

## 1. Module card
## 2. The question
## 3. Learning outcomes
## 4. Onramp
## 5. Pre-read (4 h)
## 6. Seminar plan (3 h)
## 7. Lab (12 h)
## 8. Artifacts shipped
## 9. Exit criteria
## 10. Common failures
## 11. Instructor notes
```

## Per-section requirements

### 1. Module card

A markdown table with exactly these keys, in this order:

`module` · `title` · `strand` · `year` / `term` · `classification` ·
`entry_tag` · `hours` · `prerequisites`

- `strand` ∈ {S1, S2, S3, S4, S5, S6}
- `classification` ∈ {durable, semi-durable, volatile} — may carry a
  parenthetical split, e.g. `durable (concepts) + volatile (§6.4)`
- `entry_tag` matches `y<N>-m<NN>-entry`
- `prerequisites` lists **artifact filenames** or the literal `none`

### 2. The question

Exactly one sentence, ending in `?`, rendered in bold.

### 3. Learning outcomes

3–5 numbered items. Each begins with an observable verb in bold.

**Permitted verbs:** specify, classify, derive, allocate, evaluate, build,
justify, reject, decompose, place, contrast, trace, compute, select, detect,
repair, defend, measure.

**Banned:** understand, know, appreciate, be familiar with, learn about,
be aware of, grasp.

### 4. Onramp

≤ 2 h. States artifacts to obtain, a brief to read, and one orientation
exercise. Entry modules may state `none`.

### 5. Pre-read (4 h)

Book references in the form `A ch<N>` / `B ch<N>`, plus **3–6 numbered
guiding questions**.

### 6. Seminar plan (3 h)

Timed segments summing to ~180 min. Must contain exactly one segment labelled
**contested question**, with an instructor brief. Volatile segments are
labelled `VOLATILE`.

### 7. Lab (12 h)

Numbered steps with individual hour budgets summing to ~12. Each step ends
with a `*Done when:*` line. **At least one step is labelled `ADVERSARIAL`.**

### 8. Artifacts shipped

A fenced path listing, plus a schema or skeleton for every artifact the module
originates (not for artifacts it merely updates).

### 9. Exit criteria

A table with columns `#` | `Criterion` | `Evidence`. Every criterion names the
file or check that evidences it. Minimum 4 criteria.

### 10. Common failures

≥ 3 entries, each formatted:

```
**F<n> — <short name>.**
Symptom: <observable>
*Response:* <what the instructor does>
```

### 11. Instructor notes

Must address: timing hazards, what to cut if short, what never to cut. For
`volatile` or partly-volatile modules, must state a **rewrite trigger**.

## Cross-module invariants

These cannot be checked from a single file and are verified at curriculum
review:

1. A `volatile` module is never a prerequisite for a `durable` one.
2. Every artifact named in a module's prerequisites is shipped by some earlier
   module, or supplied with the entry tag.
3. Artifact paths are stable across modules — the same file keeps the same
   path for the life of the programme.
4. Each module's shipped artifacts appear in the year's asset ledger.
