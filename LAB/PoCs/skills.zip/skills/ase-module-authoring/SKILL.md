---
name: ase-module-authoring
description: >
  Author or review a module of the Agentic Systems Engineering School against
  the delivery template. Use when asked to draft, complete, revise or check an
  ASE School module, a course module with seminar and lab sections, or a
  curriculum module card. Do not use for the programme-level design or the
  year curriculum overview - those are separate documents.
version: "1.0.0"
domain: curriculum
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Authoring an ASE School module

Modules are authored against a fixed template so they can be delivered by
someone who did not write them, and so authoring stays inside its 40-80 h
budget. The template is the contract; conformance is checked mechanically.

## Output contract

A single markdown file containing all eleven sections, in order, with the
exact headings given in `references/template-schema.md`. No preamble, no
commentary outside the module.

File name: `M<NN> - <title>.md`

## Step 1 - establish the frame

From the year curriculum, extract for this module: number, title, strand,
classification, the question, the reading, and the artifacts it must ship.
If any is missing, stop and ask rather than invent - a module that ships
different artifacts from the ones downstream modules expect breaks the
programme's interfaces.

## Step 2 - author in dependency order

Not in reading order. This sequence is what keeps labs assessable:

```
card -> question -> outcomes -> EXIT CRITERIA -> lab -> artifacts
     -> pre-read + guiding questions -> seminar -> failures -> notes
```

Exit criteria before the lab. Writing them first forces the lab to produce
evidence rather than activity; writing them last produces criteria that
describe whatever the lab happened to generate.

## Step 3 - apply the authoring rules

Load `references/authoring-rules.md` and satisfy all six. The two most often
missed:

- **R1 ship an asset** - the module produces something the business keeps
- **R6 one honest negative** - something that does not work, a case where the
  technique is wrong, or a limit of the method

## Step 4 - check prerequisites are artifacts

Prerequisites name files, never module numbers. "Module 5" is not a
prerequisite; `functions-sv4a.md` is. If a prerequisite cannot be named as an
artifact, the interface between those modules is not sealed and the module is
not self-contained.

## Step 5 - verify the volatility rule

A `volatile` module may not be a prerequisite for a `durable` one. Check the
year curriculum before finalising. If the rule is violated, the fix is to move
the durable content out of the volatile module, not to relabel it.

## Step 6 - validate, then repair

```
run_skill_script("ase-module-authoring", "check_module.py", stdin=<the module>)
```

Output starts with `OK` - done. Otherwise repair every reported issue and run
again. **Never present a module as finished while the checker reports issues.**
If a diagnostic survives three repair rounds, stop and report it rather than
working around it.

## Step 7 - self-review against the reading

The seminar's guiding questions must be answerable from the cited chapters. If
you cannot answer your own guiding questions from the source, you have cited
the wrong chapter or written questions the reading does not support. This is
the most common quality failure and the checker cannot catch it.

## Escalation

Stop and ask, rather than invent, when: the reading does not cover the
module's question; the artifacts conflict with a downstream module's declared
prerequisites; or the lab cannot be completed in 12 hours. Each indicates a
curriculum defect, not an authoring problem.
