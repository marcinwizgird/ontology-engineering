#!/usr/bin/env python3
"""Tier-3 validator: conformance of an ASE School module to the delivery template.

Reads a module markdown file on stdin, prints a short report on stdout.
Self-contained by design - a skill package must not import the host
application. The script body never enters the agent's context; only this
report does.

What this checks is structure and the mechanically detectable authoring rules.
What it cannot check is whether the guiding questions are answerable from the
cited reading, or whether the lab fits in twelve hours. Those are review
matters and the report says so rather than implying a clean bill of health.

Exit code 0 when conforming, 1 when issues were found.
"""

import re
import sys

SECTIONS = [
    "Module card",
    "The question",
    "Learning outcomes",
    "Onramp",
    "Pre-read",
    "Seminar plan",
    "Lab",
    "Artifacts shipped",
    "Exit criteria",
    "Common failures",
    "Instructor notes",
]

CARD_KEYS = ["module", "title", "strand", "year", "classification",
             "entry_tag", "hours", "prerequisites"]

GOOD_VERBS = {
    "specify", "classify", "derive", "allocate", "evaluate", "build",
    "justify", "reject", "decompose", "place", "contrast", "trace",
    "compute", "select", "detect", "repair", "defend", "measure",
}
BANNED_VERBS = {
    "understand", "know", "appreciate", "learn", "grasp", "familiar", "aware",
}

STRANDS = {"S1", "S2", "S3", "S4", "S5", "S6"}
CLASSES = {"durable", "semi-durable", "volatile"}


def section_bodies(text):
    """Split on '## <n>. <Name>' headings, preserving order.

    Headings inside fenced blocks are content - artifact skeletons routinely
    contain numbered '## ' lines - so fences are tracked and skipped.
    """
    parts, order = {}, []
    cur, buf = None, []
    fenced = False
    for line in text.splitlines():
        if line.lstrip().startswith("```"):
            fenced = not fenced
            if cur:
                buf.append(line)
            continue
        if fenced:
            if cur:
                buf.append(line)
            continue
        m = re.match(r"^##\s+(\d+)\.\s+(.+?)\s*$", line)
        if m:
            if cur:
                parts[cur] = "\n".join(buf)
            cur = m.group(2).strip()
            order.append((int(m.group(1)), cur))
            buf = []
        elif cur:
            buf.append(line)
    if cur:
        parts[cur] = "\n".join(buf)
    return parts, order


def check(text):
    issues = []
    parts, order = section_bodies(text)

    # -- sections present, in order --------------------------------------
    found = [name for _, name in order]
    for want in SECTIONS:
        if not any(want.lower() in f.lower() for f in found):
            issues.append(f"missing section: '{want}'")

    nums = [n for n, _ in order]
    if nums != sorted(nums):
        issues.append("sections are numbered out of order")

    def body(keyword):
        for name, txt in parts.items():
            if keyword.lower() in name.lower():
                return txt
        return ""

    # -- 1 module card -----------------------------------------------------
    card = body("Module card")
    for key in CARD_KEYS:
        if not re.search(rf"`{key}`", card):
            issues.append(f"module card: missing key `{key}`")

    m = re.search(r"`strand`\s*\|\s*(S\d)", card)
    if m and m.group(1) not in STRANDS:
        issues.append(f"module card: strand {m.group(1)} not in S1..S6")

    m = re.search(r"`classification`\s*\|\s*([a-z\- ]+)", card)
    if m and not any(c in m.group(1) for c in CLASSES):
        issues.append("module card: classification must be durable, "
                      "semi-durable or volatile")

    if not re.search(r"y\d+-m\d{2}-entry", card):
        issues.append("module card: entry_tag must match y<N>-m<NN>-entry")

    m = re.search(r"`prerequisites`\s*\|\s*(.+)", card)
    if m:
        pre = m.group(1).strip().strip("|").strip()
        if re.search(r"\bmodule\s+\d+", pre, re.I):
            issues.append("module card: prerequisites name modules, not "
                          "artifacts - name the files instead (R: sealed interfaces)")

    # -- 2 the question ----------------------------------------------------
    q = body("The question").strip()
    sentences = [s for s in re.split(r"(?<=\?)\s", q) if s.strip()]
    if "?" not in q:
        issues.append("the question: must be interrogative")
    elif len([s for s in sentences if s.strip()]) > 1:
        issues.append("the question: more than one sentence - the module is "
                      "doing two things and should be split")

    # -- 3 outcomes --------------------------------------------------------
    out = body("Learning outcomes")
    items = re.findall(r"^\s*\d+\.\s+(.+)$", out, re.M)
    if not 3 <= len(items) <= 5:
        issues.append(f"learning outcomes: {len(items)} found, need 3-5")
    for it in items:
        first = re.sub(r"[^a-zA-Z]", " ", it).split()
        first = first[0].lower() if first else ""
        if first in BANNED_VERBS:
            issues.append(f"learning outcome starts with unassessable verb "
                          f"'{first}' - use an observable verb")
        elif first and first not in GOOD_VERBS:
            issues.append(f"learning outcome verb '{first}' is not in the "
                          f"permitted list; use an observable verb or justify it")

    # -- 5 pre-read --------------------------------------------------------
    pre = body("Pre-read")
    if not re.search(r"\b[AB]\s*ch\s*\d+", pre):
        issues.append("pre-read: no book reference in the form 'A ch<N>'")
    gq = re.findall(r"^\s*\d+\.\s+.+\?\s*$", pre, re.M)
    if not 3 <= len(gq) <= 6:
        issues.append(f"pre-read: {len(gq)} guiding questions, need 3-6 "
                      f"(R2: reading is load-bearing)")

    # -- 6 seminar ---------------------------------------------------------
    sem = body("Seminar plan")
    if "contested question" not in sem.lower():
        issues.append("seminar: no segment labelled 'contested question' "
                      "(R6: at least one honest negative)")
    mins = [int(x) for x in re.findall(r"\((\d+)\s*min\)", sem)]
    if mins and not 150 <= sum(mins) <= 200:
        issues.append(f"seminar: segments sum to {sum(mins)} min, expected ~180")

    # -- 7 lab -------------------------------------------------------------
    lab = body("Lab")
    steps = re.findall(r"^###\s+Step\s+\d+", lab, re.M)
    if len(steps) < 3:
        issues.append(f"lab: {len(steps)} steps, expected at least 3")
    done = len(re.findall(r"\*Done when:\*", lab))
    if done < len(steps):
        issues.append(f"lab: {done} '*Done when:*' lines for {len(steps)} steps "
                      "- every step states what done looks like")
    if "ADVERSARIAL" not in lab:
        issues.append("lab: no step labelled ADVERSARIAL - labs where "
                      "everything succeeds teach nothing about engineering")
    hours = [int(x) for x in re.findall(r"\((\d+)\s*h\)", lab)]
    if hours and not 10 <= sum(hours) <= 14:
        issues.append(f"lab: step hours sum to {sum(hours)}, expected ~12 (R3)")

    # -- 8 artifacts -------------------------------------------------------
    art = body("Artifacts shipped")
    if "```" not in art:
        issues.append("artifacts: no fenced path listing")
    if not re.search(r"schema|skeleton", art, re.I):
        issues.append("artifacts: no schema or skeleton for originated artifacts")

    # -- 9 exit criteria ---------------------------------------------------
    exit_s = body("Exit criteria")
    rows = [r for r in re.findall(r"^\|\s*\d+\s*\|(.+)$", exit_s, re.M)]
    if len(rows) < 4:
        issues.append(f"exit criteria: {len(rows)} rows, need at least 4")
    if "Evidence" not in exit_s:
        issues.append("exit criteria: table needs an Evidence column (R4)")
    for r in rows:
        # markdown rows usually end with a trailing '|', so drop empty tail cells
        cells = [c.strip() for c in r.split("|")]
        while cells and not cells[-1]:
            cells.pop()
        if len(cells) < 2 or not cells[-1]:
            issues.append("exit criteria: a row has no evidence stated")
            break

    # -- 10 failures -------------------------------------------------------
    fail = body("Common failures")
    fs = re.findall(r"\*\*F\d+\s*[—-]", fail)
    if len(fs) < 3:
        issues.append(f"common failures: {len(fs)} found, need at least 3")
    if fail.count("Symptom:") < len(fs) or fail.count("*Response:*") < len(fs):
        issues.append("common failures: each needs a Symptom and a *Response:*")

    # -- 11 instructor notes ------------------------------------------------
    notes = body("Instructor notes")
    for need, label in (("cut if short", "what to cut if short"),
                        ("never cut", "what never to cut")):
        if need not in notes.lower():
            issues.append(f"instructor notes: must state {label}")
    if re.search(r"volatile", card, re.I) and "rewrite trigger" not in notes.lower():
        issues.append("instructor notes: volatile module must state a rewrite trigger (R5)")

    return issues


def main():
    text = sys.stdin.read()
    if not text.strip():
        print("FAIL - empty input")
        return 1

    issues = check(text)
    if not issues:
        print("OK - module conforms to the delivery template")
        print("note: structure and mechanical rules only. Not checked: whether the "
              "guiding questions are answerable from the cited reading, and whether "
              "the lab fits 12 hours. Both are review matters.")
        return 0

    print(f"FAIL - {len(issues)} issue(s)")
    for i in issues:
        print(f"  - {i}")
    return 1


if __name__ == "__main__":
    sys.exit(main())
