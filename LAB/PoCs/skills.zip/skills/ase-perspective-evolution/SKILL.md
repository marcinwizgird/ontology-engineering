---
name: ase-perspective-evolution
description: >
  Apply the Rozanski & Woods Evolution perspective to an agentic system's
  SysML v2 architecture - characterise the changes the system must absorb
  after deployment (model and provider swaps, prompt versions, new tools,
  new stage kinds, pattern variants), assess how far each change ripples
  through the model, weigh flexibility against its cost, and rework with
  containment, stable interfaces, variation points and reliable re-verification.
  Use for changeability, maintainability, modifiability, model or provider
  replacement, prompt versioning, pattern product lines and reuse, vocabulary
  extensions, "what breaks if we change X" questions about an ASE design. Do
  not use for the system changing its own behaviour in production (use
  ase-perspective-drift) or for build effort and team capacity (use
  ase-perspective-development-resource).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Evolution perspective

Load `ase-arch-sysml-foundations` first. Methodology entry (control, read
with `ase_perspective("Evolution")`, cite with
`ase_provenance("EvolutionPerspective")`): `AseMethodology::EvolutionPerspective`,
`origin = "R&W"`, `checks = "variation_rules,vocabulary_conformance,orphan_stages,dangling_exits,duplicate_capability"`.

## Definition

> "The ability of the system to be flexible in the face of the inevitable
> change that all systems experience after deployment, balanced against the
> costs of providing such flexibility" - R&W, viewpoints-and-perspectives.info/home/perspectives
> (quoted in `AseMethodology::EvolutionPerspective`).

The balance clause matters: flexibility nobody uses is cost. Drift is the
separate ASE extension for change the system makes to itself; Evolution is
change people make to it.

**Applicability.** All systems to some degree; most for long-lived, widely
used ones. For agentic systems the change rate is set by the model market -
a hosted model is deprecated or repriced within months - so treat it as
always applicable.

**Concerns.** ASE frames `Buildability` ("Can this be built, tested and
released by the team that owns it?"). R&W's evolution concerns, paraphrased,
to elicit in A1: product management; the magnitude, dimensions, likelihood
and timescale of change; when to pay for flexibility; externally driven
change; development complexity; preserving knowledge; reliability of change.
**Stakeholders:** `SoftwareEngineer`, `ProductOwner` (hold Buildability);
`SystemsEngineer` (pattern library); maintainers and the platform team.

## Agentic dimensions of change

| Dimension | Likelihood / timescale | Where it lands in the model |
|---|---|---|
| Model or provider swap | high / months | `costTokens`, `latencyMs` of every model-calling stage def bound to it |
| Prompt version | very high / weeks (GEPA: continuous) | stage instructions - outside the model; versioned artefact |
| Retrieval backend or index | medium / quarters | retriever stage defs, Knowledge view |
| New tool or source | medium | new external stage, Security and Context impact |
| New stage kind (memory, rewriter) | medium | `@Extension` stage def on the design |
| Pattern variant (product line) | per design | `variation` / `variant`; library `part def` composition |
| Budget change | low | requirement attribute; re-run the sweep |

## Activities -> SysML

R&W's loop: characterise evolution needs -> assess current ease of evolution
-> consider the tradeoffs -> rework the architecture.

### 1. Characterise the evolution needs

Write each expected change as an SEI modifiability scenario on a
requirement def - source, stimulus, artifact, environment, response, and a
measure with a number (files touched, days, regressions allowed). See
`QS-EVO-01` in `references/example.sysml`. Rank by likelihood x magnitude;
do not build flexibility for changes nobody can name.

### 2. Assess the current ease of evolution

Change radius is computable because patterns compose shared stage defs:

```
python ase-perspective-evolution/scripts/change_impact.py < design.sysml
python ase-perspective-evolution/scripts/change_impact.py AnswerSynthesizer costTokens=900 latencyMs=600 < models/rag-patterns.sysml
```

The first lists, per stage def, every pattern that must be re-verified when
it changes. The second is a swap what-if: on the reference library a cheaper
synthesiser touches 6 of 6 patterns (AgenticRag 68,600 -> 42,600 tokens,
still over budget; SelfRag 9,300 -> 5,400). Then run the Evolution checks:

| Check | Kind | Severity | What it reads / what it means |
|---|---|---|---|
| `orphan_stages` | STRUCTURE | error | stage not reachable from an entry (a stage with outflow and no non-back inflow) - typically left behind by an edit |
| `dangling_exits` | STRUCTURE | warning | stage with no inbound *and* no outbound flow; a leaf with inflow is not flagged, so "every path ends somewhere deliberate" is only partly checked |
| `vocabulary_conformance` | CLASSIFICATION | warning | stage-def attributes outside the eight agreed ones; pattern attributes (`maxIterations`) are not stage defs and are not flagged |
| `duplicate_capability` | CORPUS | info | a stage type used by 4 or more designs: a shared component candidate |
| `variation_rules` | CORPUS | info | stage defs with identical attribute profiles under different names |

Reference results: tripwire trips `orphan_stages` ("stranded is
unreachable"), `dangling_exits` ("stranded is isolated") and
`vocabulary_conformance` (`spookiness`); the library trips
`duplicate_capability` for AnswerSynthesizer and DenseRetriever (6 designs
each) and `variation_rules` for GroundednessEvaluator / QueryReformulator.
That last one is two different responsibilities with coincident estimates -
a profile match is evidence to review, not proof of duplication.

CORPUS checks answer only for the designs loaded
(`project_corpus([...])`); a single-design run says nothing about reuse.

### 3. Consider the tradeoffs

Every flexibility mechanism costs something in another perspective: an
indirection layer adds latency; a router adds a model call; a generic
stage contract loses the specific attributes the checks read; a shared
component makes one change ripple everywhere. Record each as a
`@TradeoffPoint` and weigh it against the scenario's likelihood.

### 4. Rework

Apply tactics (below), re-run `change_impact.py` and the sweep, record
before/after radius and numbers in the decision.

## Applying the perspective to each view

| View | What the perspective adds or checks in SysML |
|---|---|
| Context | external model providers and tools as replaceable externals; which are contractually pinned |
| Functional | stage defs as the unit of change; containment of new stage kinds; variation points |
| Information / Knowledge | corpus and index versioning, schema of chunk metadata, memory format migration |
| Concurrency | fan-out and loop parameters as configuration, not code |
| Autonomy | tool and authority changes go through the same approval as code |
| Deployment | model endpoints and versions per environment; platform independence |
| Operational | upgrade and rollback of prompt sets and models; migration of stored memory |
| Development | codeline, generated vs hand-written, prompt and eval-set versioning, the preserved build and eval environment |

## Tactics -> SysML change -> expected effect

| Tactic (R&W) | Agentic form | SysML change | Check / measure that should move |
|---|---|---|---|
| Contain change | new stage kinds on the design, not in the library | `@Extension` stage def in `design.sysml`; library untouched | `vocabulary_conformance` warns (accepted); `change_impact.py` radius 1 |
| Create flexible interfaces | model behind a provider-neutral contract | `port def ModelEndpoint` with `modelId`, `pinnedVersion` | swap radius = binding only |
| Change-oriented styles | pipeline of small single-purpose stages | split a god stage; flows between stages | `change_impact.py` smaller per-def radius |
| Metamodel-based style | the stage vocabulary + pattern library as metamodel; designs instantiate | compose library defs; parameters as attributes | `duplicate_capability` (reuse visible) |
| Build variation points | rewriter always vs on follow-up; hybrid vs dense | `variation part def` / `variant part` in a view file | review; accepted design stays variant-free |
| Standard extension points | `@Extension` with reason + roadmap | extension metadata | `check_ad.py` extensions clean |
| Achieve reliable change | every change re-runs sweep + eval before release | verification defs; Drift release gate | regression count 0 |
| Preserve development environments | frozen eval sets, pinned models, recorded GEPA config | Development / Deployment view attributes | review |

`model_reader` cannot resolve variants: keep `variation` in `ad/`, never in
`design.sysml`.

## Pitfalls -> how to detect them in the model

| Pitfall (R&W + agentic) | Detection |
|---|---|
| Prioritising the wrong dimensions | flexibility built where no `QS-EVO` scenario exists; the model-swap scenario missing |
| Changes that never happen | variation points with one variant for more than a release |
| Evolution harms critical qualities | swap what-if fails a budget (`change_impact.py` after-numbers over budget) |
| Lost development environments | eval sets, model versions or GEPA settings not recorded |
| Ad hoc release management | prompt or model change released without the sweep and eval (no verification def) |
| Overreliance on specific software | provider SDK or model name inside stage defs instead of an endpoint contract |
| Edited controls | a diff under `models/` or `methodology/` - fails the design outright |
| Copy instead of reuse | design copies library defs (RS-01's PatternCopier does) and later diverges - `variation_rules` over the corpus |
| Silent vocabulary growth | non-vocabulary attribute without `@Extension` (`check_ad.py` warns) |
| Stage left behind | `orphan_stages` / `dangling_exits` after an edit |
| Prompt as untracked code | prompt text changes with no version or owner in the Development view |

## Checklist

Change scenarios written with numeric measures and ranked; model-swap and
prompt-version scenarios present; change radius computed for every stage
def a likely change touches; swap what-if run and within budget or recorded;
new stage kinds contained on the design with `@Extension`; model identity
behind one contract; variation points only where a variant is planned;
Evolution checks run on the design and on the corpus it belongs to;
tradeoffs recorded; release path re-verifies every requirement.

## Output contract

In `ad/perspectives.sysml` (variants in `ad/functional.sysml`, interfaces in
`ad/context.sysml` or `ad/development.sysml`):

1. `satisfy AseMethodology::EvolutionPerspective by <Design>;`
2. change-scenario requirement defs with `@QualityScenario`, allocated
3. `@Extension` on every non-vocabulary stage attribute; model endpoint `port def`
4. `variation part def` for planned variants
5. `@Finding` per Evolution check result (design and corpus scope), with disposition and decision
6. `change_impact.py` results as `@SensitivityPoint` / `@TradeoffPoint`; `@Tactic` + `@ArchitectureDecision` per rework

Validate (from `AI Skills/skills`):

```
python description-to-sysmlv2/scripts/check_model.py < <file>
python ase-arch-sysml-foundations/scripts/check_ad.py < <file>   # // ad-check: perspectives=Evolution
python ase-perspective-evolution/scripts/change_impact.py < <design.sysml>
```

then `ase_gap(<design>)` and `python -m sysmlagents.cli explain <RS-xx>`.
Worked RS-08 example (contained extensions, rewriter variation point, model
endpoint contract): `references/example.sysml`.
