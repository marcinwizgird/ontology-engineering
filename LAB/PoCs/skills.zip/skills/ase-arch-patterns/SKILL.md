---
name: ase-arch-patterns
description: >
  The ASE agent pattern catalogue - 55 agentic architecture patterns
  (single agent, reasoning, guardrails, evaluation, production, multi-agent
  coordination, self-improvement) ordered into eight adoption stages P1-P8
  with prerequisites, code-level detection signals, the ASE checks that verify
  each, and a test metric. Use when choosing patterns for a new agentic design
  (ASE step A3), when deciding what to build next, when checking which
  patterns an existing agent implements (coverage matrix and report), or when
  asked "which pattern solves X", "what must exist before Y", or "how mature
  is this agent". Do not use for retrieval-pipeline (RAG) stage design in
  depth - that is the RAG pattern library in models/rag-patterns.sysml - or
  for applying one quality concern's tactics (use the ase-perspective-* skill).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Agent pattern catalogue (P1-P8)

The catalogue is a **control**: obey it, never edit it during a project. A
gap you find is recorded as a finding or an `@Extension` on the design with
a reason; the catalogue owner promotes it later. The single source is
`references/patterns.json`; `references/catalogue.md` is generated from it.

Source: *Agentic Architectural Patterns for Building Multi-Agent Systems*
(Packt, 2026), chapters 5-11, re-sequenced single-agent first. Summaries are
paraphrased; cite chapter and page (`ch7 p252`), never quote at length.

## The adoption rule

**Build a pattern only after the patterns it requires.** The order is a
dependency order, not a popularity ranking: a self-correcting agent without
timeouts loops forever, an orchestrator without escalation has nowhere to
send what it cannot handle. Stages:

| Stage | Title | You can claim it when |
|---|---|---|
| P1 | Minimal single agent | tool loop, session memory, grounding, timeouts, escalation to a person |
| P2 | Reasoning and self-correction | explicit reasoning, anchored constraints, output audited before action, bounded adaptive retry |
| P3 | Auditable and guarded | decision trail, injection defence, least privilege, sandbox for risky tools, policy gate, rate limits |
| P4 | Evaluated and optimised | requirement-derived metrics, red-team set, token budgets, generator + judge optimisation |
| P5 | Production single agent | fallback model, staged escalation, checkpoints, cross-checked critical outputs, events, non-text input |
| P6 | Top-down multi-agent | router, supervisor, delegation, planning, scoped tools, shared memory, registry |
| P7 | Resilient, governed teams | supervision trees, self-healing, mesh defence, proxies, allocation, trust scores, canaries, voting |
| P8 | Decentralised, self-improving | consensus, negotiation, swarms, synthetic preference data, co-trained planner and scorer |

A system is "at stage Pn" only when every pattern it *requires* in P1..Pn is
present. Not every system needs every pattern: required-ness comes from the
requirements and risks, and an `n/a` needs a reason.

## Commands

```
run_skill_script("ase-arch-patterns", "catalogue.py", stdin="list P1 P2")
run_skill_script("ase-arch-patterns", "catalogue.py", stdin="show watchdog-timeout")
run_skill_script("ase-arch-patterns", "catalogue.py", stdin="matrix P1 P2 P3 P4 P5")
run_skill_script("ase-arch-patterns", "catalogue.py", stdin="coverage\n<filled matrix>")
run_skill_script("ase-arch-patterns", "catalogue.py", stdin="validate")
```

From a shell: `python scripts/catalogue.py <command> [args]`, with the
matrix on stdin for `coverage`. Read `references/catalogue.md` for every card
at once.

## Selecting patterns for a new design (A3)

1. From the A1 requirements and A2 scenarios, list the capabilities the
   system needs (tools, grounding, escalation, audit, multi-agent, ...).
2. Map each capability to catalogue patterns (`show <key>` for the card).
   Prefer the lowest stage that meets the requirement: a single agent with
   P1-P5 beats a team of agents unless a requirement forces P6+.
3. Close over prerequisites: every pattern's `requires` is added, recursively.
   `matrix` then `coverage` on the planned set shows the closure.
4. Record the choice as an `@ArchitectureDecision`: chosen patterns, the
   ones considered and rejected with the reason, and the stage targeted.
5. For retrieval, pattern 4 (Sensing with RAG) points into the RAG library;
   select the concrete RAG pattern there (`ase-arch-definition-process`, A3).

## Coverage of an existing agent

1. `matrix` for the stages in scope (P1-P5 for a single agent; add P6-P8
   when there is more than one agent).
2. For each line decide **status** from evidence in the code and tests:
   - `present`: the card's detection signals are there *and* the property
     holds everywhere it must (every model client has a timeout, not one);
     evidence is `file:line` plus a test if one exists.
   - `partial`: exists but a defining property is missing (retry without a
     bound, RAG without citations, escalation with no context passed).
   - `missing`: not there.
   - `n/a`: the system genuinely does not need it - write the reason.
3. Decide **required** from the requirements and risks, not from the
   catalogue: `yes` when a requirement, scenario or risk depends on it.
4. Run `coverage`. It reports per-stage counts, the stage reached,
   prerequisite violations (a pattern built on a missing foundation - these
   are usually the most important findings), and the remediation list in
   sequence order with each pattern's metric.
5. Turn each violation and each required gap into a `@Finding` with the
   evidence, and the remediation list into the build plan
   (`ase-build-from-design`).

## Reasoning with the catalogue

- **Detection signals are hints, not proof.** A `timeout=` in one client
  does not make the system bounded; check every call path. When the code
  cannot be read with confidence, mark `partial` and say what is unknown.
- **ASE checks need a model.** The `checks` on a card run on a SysML design
  (`sysmlagents.workflow.walk`), not on code. For an existing agent, model
  it first (`ase-arch-review`), then the checks apply.
- **Metrics belong in tests.** A pattern is not done when the code exists;
  it is done when a test or eval measures its metric.
- **Two facets, one mechanism.** Knowledge Sharing (34) and Shared Epistemic
  Memory (35) are coordination and governance views of the same store;
  review them together.

## Output contract

For a selection: the decision record (chosen, rejected with reasons, target
stage) and the closed pattern list. For a coverage review: the filled
matrix, the `coverage` output verbatim, and one finding per violation and
per required gap. Report the stage reached exactly as the script prints it.
