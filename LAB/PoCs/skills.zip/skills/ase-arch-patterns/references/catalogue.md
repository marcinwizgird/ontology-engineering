# Agent pattern catalogue

Generated from `patterns.json` by `scripts/catalogue.py markdown --write`. Do not edit; edit the JSON and regenerate.

Source: Agentic Architectural Patterns for Building Multi-Agent Systems (Packt, 2026), ASE School/library/9781806029570.pdf. Summaries are paraphrased; cite chapter and page, never quote at length.

Adoption rule: a pattern is built only after the patterns it requires. Stages P1-P5 are single-agent, P6-P8 multi-agent.

# P1 Minimal single agent

Goal: One agent that calls tools in a bounded reasoning-acting loop, remembers the session, is grounded in a knowledge source, cannot hang, and can hand over to a person.

Book: Agentic maturity L1-L2; GenAI L1/L5; ch9 rollout phase 1

## 1. Single Agent Baseline  [P1]

- key: `single-agent-baseline`; scope: agent; book level: L1; source: ch9 p347
- requires: none
- techniques: static function calling, dynamic tool selection, ReAct loop

One LLM-driven agent with a goal prompt and a set of tools decides which tools to call, in what order and with what arguments, inside a reason-act loop. It is the reference point every richer architecture is measured against.

Detect in code: one agent object or graph node owns the whole task; tool/function schemas passed to the model; a loop that alternates model call and tool execution.
ASE checks: `orphan_stages`, `dangling_exits`, `vocabulary_conformance`.
Metric: task completion rate; tool-call success rate.

## 2. Human Calls Agent  [P1]

- key: `human-calls-agent`; scope: interaction; book level: H1; source: ch8 p329
- requires: 1 single-agent-baseline

A person sends a direct, single-turn command or question and the agent answers it. The basic transactional entry point of any agent.

Detect in code: a request handler, CLI or chat endpoint that invokes the agent per request.
ASE checks: none yet (review by reading).
Metric: first-contact resolution rate; end-to-end response time.

## 3. Agent-Specific Context and Memory  [P1]

- key: `agent-memory`; scope: agent; book level: L1; source: ch9 p351
- requires: 1 single-agent-baseline

The agent keeps its own state: short-term memory of the current session (windowed or summarised history) and, later, long-term memory of facts and preferences in a store it can query.

Detect in code: conversation history passed back to the model; summarisation or sliding window of history; a key-value or vector store keyed by user or session.
ASE checks: none yet (review by reading).
Metric: rate of repeated questions; session coherence score.

## 4. Sensing with RAG  [P1]

- key: `sensing-with-rag`; scope: agent; book level: L2; source: ch9 p355
- requires: 1 single-agent-baseline
- techniques: advanced RAG (re-ranking, query transformation), agentic RAG, graph-vector hybrid retrieval

Before answering, the agent retrieves relevant passages from an external knowledge source and conditions its answer on them, which grounds it in current domain facts and reduces fabrication. The RAG pattern library (NaiveRag ... AgenticRag) is this pattern's family.

Detect in code: retriever, vector index or search call before generation; retrieved passages inserted into the prompt; citations in the output.
ASE checks: `citation_carriers`, `unsourced_stages`, `provenance_paths`.
Metric: hallucination rate / groundedness; citation recall.

## 5. Watchdog Timeout Supervisor  [P1]

- key: `watchdog-timeout`; scope: agent+ops; book level: L1, R2; source: ch7 p252
- requires: 1 single-agent-baseline
- related: 10 adaptive-retry, 24 delayed-escalation
- techniques: simple retry

Every call to a model, tool or other agent runs under a deadline; when it expires the call is abandoned and a defined failure path runs instead of the whole system hanging.

Detect in code: timeout argument on every model and HTTP client; asyncio.wait_for or equivalent around tool calls; maximum iteration count on agent loops.
ASE checks: `bounded_cycles`, `latency_budget`, `progress_conditions`.
Metric: P99 latency; timeout violations per hour.

## 6. Agent Calls Human (Human-in-the-Loop Escalation)  [P1]

- key: `agent-calls-human`; scope: interaction; book level: L1, H2; source: ch8 p321
- requires: 1 single-agent-baseline
- related: 24 delayed-escalation

When the agent meets ambiguity, low confidence or a critical step, it pauses and asks a person, handing over the context needed to decide, and resumes with the answer.

Detect in code: an interrupt / approval step in the graph; confidence threshold that routes to a person; a queue or notification for pending human decisions.
ASE checks: `trust_escalation`.
Metric: escalation rate; time to human resolution.

# P2 Reasoning and self-correction

Goal: The agent reasons in explicit steps, keeps its instructions in force over long tasks, checks its own output before acting and recovers from bad outputs.

Book: Agentic maturity L3 (ReAct, Reflexion)

## 7. Structured Reasoning and Self-Correction  [P2]

- key: `structured-reasoning`; scope: agent; book level: L3; source: ch9 p360
- requires: 1 single-agent-baseline
- related: 9 instruction-fidelity-auditing, 11 fractal-cot
- techniques: chain-of-thought, ReAct, Reflexion

The agent works through a problem in explicit steps and reviews its preliminary answer against the instructions before finalising, combining chain-of-thought, act-observe loops and self-critique.

Detect in code: explicit reasoning field or step in the program (e.g. DSPy ChainOfThought); a critique/verify step after the draft answer; revision loop driven by the critique.
ASE checks: `bounded_cycles`.
Metric: self-correction trigger rate; error rate preliminary vs final.

## 8. Persistent Instruction Anchoring  [P2]

- key: `instruction-anchoring`; scope: agent; book level: ch12 L2; source: ch6 p227
- requires: 1 single-agent-baseline
- related: 9 instruction-fidelity-auditing

Critical goals and constraints are marked with distinct tags and kept salient at every step (repeated, placed at start and end, passed down to sub-agents) so they survive long contexts and deep delegation.

Detect in code: tagged constraint block in prompts; constraints re-injected at each step or hop; system prompt assembled from a fixed constraint list.
ASE checks: none yet (review by reading).
Metric: constraint violations over long tasks (target 0).

## 9. Instruction Fidelity Auditing  [P2]

- key: `instruction-fidelity-auditing`; scope: agent; book level: L3; source: ch6 p219
- requires: 7 structured-reasoning
- related: 8 instruction-anchoring, 17 compliance-monitoring

An independent check compares an agent's output or planned action with the original instructions and constraints before it takes effect, catching silent misalignment that looks like success.

Detect in code: a validator or auditor step between generation and action; rule list derived from the task instructions; audit result logged with the output.
ASE checks: `verification_coverage`.
Metric: fidelity violations caught before action; escaped violations.

## 10. Adaptive Retry with Prompt Mutation  [P2]

- key: `adaptive-retry`; scope: agent+ops; book level: L3, R2; source: ch7 p256
- requires: 5 watchdog-timeout
- related: 24 delayed-escalation

On a failed or invalid output the agent analyses the failure and retries with a modified prompt (more context, stricter format, different decomposition) instead of repeating the same call, within a bounded number of attempts.

Detect in code: retry loop that changes the prompt or parameters; error message fed back into the next attempt; retry counter with a maximum.
ASE checks: `bounded_cycles`, `progress_conditions`.
Metric: recovery rate (successful retries / initial failures).

## 11. Fractal Chain-of-Thought Embedding  [P2]

- key: `fractal-cot`; scope: agent; book level: T6.1 single-agent; ch13; source: ch6 p223
- requires: 7 structured-reasoning
- related: 48 consensus

Reasoning is organised as nested, self-contained units that can be revisited and refined at different levels of detail as new evidence arrives. Single-agent mode here; the inter-agent mode, where agents revise plans from each other's reasoning, belongs to P8.

Detect in code: hierarchical plan with sub-steps that are re-evaluated; explicit revise step that can reopen earlier conclusions; reasoning trace stored per level.
ASE checks: `bounded_cycles`.
Metric: reasoning-trace completeness; corrected conclusions.

## 12. Human Delegates to Agent  [P2]

- key: `human-delegates-to-agent`; scope: interaction; book level: H2; source: ch8 p325
- requires: 2 human-calls-agent, 6 agent-calls-human, 7 structured-reasoning

A person hands over a goal rather than a command; the agent plans and executes the multi-step task autonomously and reports back, escalating where it must.

Detect in code: goal-level request object; agent-produced plan executed over several steps; final report or status updates to the requester.
ASE checks: none yet (review by reading).
Metric: delegated-goal completion rate; user satisfaction.

# P3 Auditable and guarded single agent

Goal: Every action is traceable to an input and a decision; the agent resists injection, holds least privilege, runs risky tools in a sandbox and is stopped by policy before a violation.

Book: ch12 L1-L2 governance; robustness R4-R5 moved early

## 13. Causal Dependency Graph  [P3]

- key: `causal-dependency-graph`; scope: governance; book level: ch12 L1-L2, R4; source: ch7 p275
- requires: 1 single-agent-baseline
- related: 17 compliance-monitoring
- techniques: basic audit logging

Every action, input, output and decision is recorded as a node with causal links, so any result can be traced to what produced it. It starts as structured audit logging and grows into a queryable provenance graph.

Detect in code: structured log per step with ids, timestamps, inputs, outputs; parent/causal ids linking steps; trace store queryable per run.
ASE checks: `provenance_paths`, `requirement_traceability`, `evidence_generable`.
Metric: share of outputs traceable to inputs and decisions (target 100%).

## 14. Agent Self-Defense  [P3]

- key: `agent-self-defense`; scope: security; book level: R5 (moved early); source: ch7 p280
- requires: 1 single-agent-baseline
- related: 20 red-teaming, 40 mesh-defense

The agent separates its own instructions from untrusted input: it sanitises inputs and wraps them in unambiguous delimiters, and the prompt tells the model to treat delimited content as data, never as instructions.

Detect in code: input sanitiser before prompt assembly; untrusted content wrapped in tags or fences; instruction stating delimited content is data.
ASE checks: `data_exposure`, `trust_declared`.
Metric: prompt-injection success rate on an attack set.

## 15. Agent Authentication and Authorization  [P3]

- key: `agent-authn-authz`; scope: system; book level: ch10 phase 1; source: ch10 p387
- requires: 1 single-agent-baseline
- related: 16 execution-envelope-isolation, 33 tool-routing

The agent acts under its own service identity with least-privilege, scoped permissions checked at every tool or API call, never with a person's or an all-powerful credential.

Detect in code: service account or token per agent; scopes declared per tool; permission check before tool execution; no shared admin keys in code.
ASE checks: `tool_authorisation`.
Metric: forbidden calls refused (target 100%); privilege findings.

## 16. Execution Envelope Isolation (Sandboxing)  [P3]

- key: `execution-envelope-isolation`; scope: security; book level: R5 (moved early); source: ch7 p289
- requires: 15 agent-authn-authz

Code, shell or other high-risk tools run in an isolated environment with limited filesystem, network and time, so a malicious or faulty action cannot reach the host.

Detect in code: container, VM or restricted interpreter for code tools; no network or filesystem allow-list; resource limits on tool execution.
ASE checks: `sandbox_consistency`.
Metric: escape attempts contained (target 100%).

## 17. Real-Time Compliance Monitoring  [P3]

- key: `compliance-monitoring`; scope: system; book level: ch10 L4; source: ch10 p382
- requires: 13 causal-dependency-graph, 15 agent-authn-authz
- related: 9 instruction-fidelity-auditing

A policy service intercepts agent actions and data access and checks them against rules (action, record and field level, e.g. personal data) before they proceed, logging every verdict.

Detect in code: policy engine or guard called before actions; PII/field filters on outputs; logged allow/deny verdicts.
ASE checks: `high_risk_classification`, `concern_coverage`, `data_exposure`.
Metric: violations blocked before action; false-block rate.

## 18. Rate-Limited Invocation  [P3]

- key: `rate-limited-invocation`; scope: ops; book level: R3; source: ch7 p297
- requires: 1 single-agent-baseline
- related: 21 tokenomics

Calls to models and external APIs pass through a limiter that enforces request and token quotas, protecting downstream services and costs.

Detect in code: token bucket or quota around clients; 429 handling with backoff; per-tenant or per-user limits.
ASE checks: `cost_budget`.
Metric: API rejection rate; quota breaches.

# P4 Evaluated and optimised single agent

Goal: Quality, cost and safety are measured against requirement-derived metrics and attack sets, and prompts are optimised by a generator-judge loop under a budget.

Book: ch11 / ch12 L3 moved early

## 19. Custom Evaluation Metrics  [P4]

- key: `custom-evaluation-metrics`; scope: learning; book level: ch12 L3 (moved early); source: ch11 p407
- requires: 1 single-agent-baseline
- related: 22 planner-scorer

Quality is measured with domain-specific metrics derived from the requirements and scored against a golden dataset, including consistency across samples, so improvement can be measured rather than asserted.

Detect in code: eval dataset with expected outputs; metric functions tied to requirements; eval run producing a report per version.
ASE checks: `verification_coverage`, `requirement_traceability`.
Metric: the metrics themselves; coverage of requirements by metrics.

## 20. Adversarial Testing and Red Teaming  [P4]

- key: `red-teaming`; scope: learning; book level: ch11; source: ch11 p422
- requires: 14 agent-self-defense, 19 custom-evaluation-metrics
- related: 16 execution-envelope-isolation, 17 compliance-monitoring

The agent is attacked systematically (injection, jailbreak, data extraction, tool abuse) with generated and curated attack sets, and the results gate releases.

Detect in code: attack dataset; red-team test suite in CI; attack success tracked per release.
ASE checks: none yet (review by reading).
Metric: attack success rate below threshold.

## 21. Cost Management and Tokenomics  [P4]

- key: `tokenomics`; scope: ops; book level: ch11; source: ch11 p426
- requires: 1 single-agent-baseline
- related: 18 rate-limited-invocation

Token use and compute cost are tracked per call, task and process against budgets; when a budget is exceeded, less critical work is paused or degraded.

Detect in code: token counting per call; budget per task or run; stop or degrade when budget is spent.
ASE checks: `cost_budget`, `llm_call_count`, `fanout_compounding`, `cost_sensitivity`.
Metric: cost per task within budget; budget overruns.

## 22. Hybrid (Planner + Scorer) Architecture  [P4]

- key: `planner-scorer`; scope: learning; book level: ch12 L3; source: ch11 p403
- requires: 19 custom-evaluation-metrics
- related: 52 synthetic-preference-data, 53 coevolved-training

Generation and evaluation are separate roles: a planner produces candidate outputs or workflows and an independent scorer grades them; the scores drive selection and optimisation (e.g. DSPy/GEPA with a judge).

Detect in code: separate judge/scorer component; candidates ranked by score; optimiser using the scorer as objective.
ASE checks: `envelope_gate`.
Metric: optimised >= baseline on held-out data.

# P5 Production single agent

Goal: The agent survives model outages, recovers long tasks, cross-checks critical outputs, reacts to events and reads non-text inputs.

Book: Robustness R2-R3; ch10 single-agent production

## 23. Fallback Model Invocation  [P5]

- key: `fallback-model`; scope: ops; book level: R3, ch12 L2; source: ch7 p301
- requires: 5 watchdog-timeout
- related: 24 delayed-escalation

When the primary model fails or is unavailable, calls are routed to an alternative model or provider, with the quality difference known in advance.

Detect in code: model list or router with fallback order; provider-agnostic model configuration; fallback path exercised in tests.
ASE checks: `fallback_coverage`.
Metric: accuracy delta fallback vs primary on the golden set; availability.

## 24. Delayed Escalation Strategy  [P5]

- key: `delayed-escalation`; scope: ops+interaction; book level: R3; source: ch7 p248
- requires: 6 agent-calls-human, 10 adaptive-retry, 23 fallback-model
- related: 5 watchdog-timeout

Failures go through tiers of automatic recovery (retry, alternative tool or agent, fallback model) before a person is involved, and the person receives the full context packet.

Detect in code: ordered recovery chain; escalation only after the chain is exhausted; context packet attached to the escalation.
ASE checks: `trust_escalation`, `fallback_coverage`.
Metric: share of failures resolved automatically; human escalation rate.

## 25. Incremental Checkpointing  [P5]

- key: `incremental-checkpointing`; scope: ops; book level: R3; source: ch7 p265
- requires: 3 agent-memory
- related: 39 auto-healing

Long tasks save their state after each step to a durable store, so a crashed or restarted agent resumes from the last checkpoint instead of starting over.

Detect in code: checkpointer configured on the graph; state persisted per step; resume entry point.
ASE checks: none yet (review by reading).
Metric: successful resume after kill; work lost per failure.

## 26. Parallel Execution Consensus  [P5]

- key: `parallel-execution-consensus`; scope: robustness; book level: R2; source: ch7 p245
- requires: 19 custom-evaluation-metrics
- related: 47 majority-voting

A critical task is run by two or more independent agents or models in parallel; agreeing results are accepted, disagreements go to a resolver or a person.

Detect in code: same task dispatched to several models; comparison with tolerance; disagreement path.
ASE checks: `minimum_cut`, `articulation_points`.
Metric: disagreement rate; errors caught by cross-check.

## 27. Event-Driven Reactivity  [P5]

- key: `event-driven-reactivity`; scope: system; book level: ch10 L4; source: ch10 p392
- requires: 15 agent-authn-authz
- related: 51 swarm

Agents subscribe to events on a bus or webhook and act when they arrive, instead of being called synchronously, which decouples them and lets them work in parallel.

Detect in code: consumer on a queue, topic or webhook; agent triggered by events; events published as outputs.
ASE checks: `cascade_depth`.
Metric: event-to-action latency; lost or duplicated events.

## 28. Multimodal Sensory Input  [P5]

- key: `multimodal-input`; scope: agent; book level: ch9 phase 3; source: ch9 p364
- requires: 1 single-agent-baseline

The agent ingests images, scans, audio or screens alongside text, converting them into structured information before reasoning.

Detect in code: image/audio inputs to a multimodal model or OCR; extraction to structured fields; validation of extracted fields.
ASE checks: none yet (review by reading).
Metric: extraction accuracy against ground truth.

# P6 Top-down multi-agent

Goal: A supervisor routes, plans and delegates to specialist agents with scoped tools, shared memory and a registry.

Book: Agentic maturity L4; ch12 L1-L2

## 29. Agent Router (intent-based routing)  [P6]

- key: `agent-router`; scope: coordination; book level: L2; source: ch5 p157
- requires: 1 single-agent-baseline
- related: 33 tool-routing

A routing layer extracts the intent of a request and dispatches it to the right specialist agent, separating understanding the request from choosing who handles it.

Detect in code: intent classifier; routing table or graph from intent to agent; fallback route for unknown intents.
ASE checks: `dangling_exits`.
Metric: routing accuracy; misroute rate.

## 30. Supervisor Architecture (centralised orchestration)  [P6]

- key: `supervisor`; scope: coordination; book level: L4, ch12 L1; source: ch5 p162
- requires: 29 agent-router, 5 watchdog-timeout, 6 agent-calls-human
- related: 32 multi-agent-planning, 38 supervision-tree

One orchestrator agent owns the workflow, delegates sub-tasks to worker agents and assembles the result, giving a clear chain of command that is easy to debug and govern.

Detect in code: orchestrator node that calls worker agents; workers do not call each other directly; result aggregation in the orchestrator.
ASE checks: `articulation_points`, `minimum_cut`, `critical_path`.
Metric: end-to-end success; orchestrator as single point of failure.

## 31. Agent Delegates to Agent  [P6]

- key: `agent-delegates-to-agent`; scope: interaction; book level: H3; source: ch8 p333
- requires: 30 supervisor
- related: 37 tool-agent-registry

An agent hands a sub-task to a specialist agent through a defined interface (e.g. A2A) and receives the result, hiding the internal collaboration from the user.

Detect in code: typed request/response between agents; agent-to-agent protocol or interface; delegation logged.
ASE checks: `dangling_exits`.
Metric: orchestration overhead; sub-task failure rate.

## 32. Multi-Agent Planning  [P6]

- key: `multi-agent-planning`; scope: coordination; book level: L4; source: ch5 p178
- requires: 30 supervisor
- related: 22 planner-scorer

A planner decomposes a goal into ordered sub-tasks and assigns them to agents, statically at first and dynamically as maturity grows.

Detect in code: explicit plan object with steps and assignees; plan executed step by step; replanning on failure.
ASE checks: `critical_path`, `bounded_cycles`.
Metric: plan completion rate; replans per task.

## 33. Tool Routing in Multi-Agent Contexts  [P6]

- key: `tool-routing`; scope: coordination; book level: -; source: ch5 p185
- requires: 29 agent-router, 15 agent-authn-authz
- related: 37 tool-agent-registry

Each agent sees only the tools relevant to its role; a router sends a task to the agent whose tool set fits, which improves tool-choice accuracy and limits privileges.

Detect in code: tool sets declared per agent; no agent holds all tools; router selects agent by tool fit.
ASE checks: `tool_authorisation`, `duplicate_capability`.
Metric: tool-choice accuracy; tools per agent.

## 34. Knowledge Sharing  [P6]

- key: `knowledge-sharing`; scope: coordination; book level: L4; source: ch5 p182
- requires: 30 supervisor
- related: 35 shared-epistemic-memory

Agents contribute what they learn to a common store and consult it, so the system builds collective knowledge instead of fragmented, drifting copies. The coordination facet of Shared Epistemic Memory.

Detect in code: agents write findings to a shared store; agents read the store before acting.
ASE checks: none yet (review by reading).
Metric: reuse rate of shared knowledge; contradictory entries.

## 35. Shared Epistemic Memory  [P6]

- key: `shared-epistemic-memory`; scope: governance; book level: L4; source: ch6 p231
- requires: 3 agent-memory
- related: 34 knowledge-sharing, 42 blackboard

A persistent, governed store (graph, vector or database) that all agents treat as ground truth, with concurrency control, expiry and indexing. The governance facet of Knowledge Sharing.

Detect in code: shared database or graph with write rules; concurrency control or versioning; TTL / expiry policy.
ASE checks: `provenance_paths`.
Metric: stale or conflicting facts; write conflicts.

## 36. Optimizing for Translation Overhead  [P6]

- key: `translation-overhead`; scope: ops; book level: -; source: ch7 p293
- requires: 31 agent-delegates-to-agent
- related: 35 shared-epistemic-memory

Large payloads are stored once and agents pass references to them instead of the data itself, keeping messages small and prompts cheap.

Detect in code: payload stored and referenced by id; messages between agents carry ids, not documents.
ASE checks: `cost_budget`.
Metric: tokens per hop; message size.

## 37. Tool and Agent Registry  [P6]

- key: `tool-agent-registry`; scope: system; book level: ch10 L5; source: ch10 p378
- requires: 31 agent-delegates-to-agent
- related: 33 tool-routing, 44 contract-net

Tools and agents register their capabilities, schemas and endpoints in a directory; others discover them by name or meaning at runtime instead of hard-coding them (e.g. an MCP server or skill catalogue).

Detect in code: registry service or catalogue file; lookup by capability before invocation; MCP or similar discovery.
ASE checks: `duplicate_capability`, `build_surface`.
Metric: discovery success; duplicate capabilities.

# P7 Meta-agents, resilience and governance of teams

Goal: Teams heal themselves, isolate faults and threats, allocate work by capability and trust, and release new agent versions safely.

Book: Agentic maturity L5; robustness R3-R5

## 38. Supervision Tree with Guarded Capabilities  [P7]

- key: `supervision-tree`; scope: coordination; book level: L5; source: ch5 p176
- requires: 30 supervisor, 15 agent-authn-authz
- related: 39 auto-healing

Supervisors form a hierarchy that manages the life cycle of their child agents (restart on failure) and grants capabilities per subtree, so a branch cannot use another branch's tools.

Detect in code: hierarchy of supervisors; restart strategy per child; capabilities scoped per subtree.
ASE checks: `tool_authorisation`, `cascade_depth`.
Metric: failures contained in subtree; restart success.

## 39. Auto-Healing Agent Resuscitation  [P7]

- key: `auto-healing`; scope: ops; book level: R3, ch12 L2; source: ch7 p261
- requires: 25 incremental-checkpointing, 5 watchdog-timeout
- related: 38 supervision-tree

A crashed or unresponsive agent is detected and restarted automatically from its last checkpoint, with backoff and a maximum to avoid crash loops.

Detect in code: health checks; restart policy with backoff; resume from checkpoint after restart.
ASE checks: `fallback_coverage`.
Metric: resuscitation success rate; crash loops.

## 40. Agent Mesh Defense  [P7]

- key: `mesh-defense`; scope: security; book level: R5; source: ch7 p284
- requires: 14 agent-self-defense, 15 agent-authn-authz, 31 agent-delegates-to-agent
- related: 16 execution-envelope-isolation

Communication between agents is restricted by an allow-list firewall, so a compromised agent cannot reach data or agents outside its permitted paths.

Detect in code: allow-list of agent-to-agent channels; messages checked at a gateway; denied calls logged.
ASE checks: `data_exposure`, `trust_escalation`.
Metric: blocked unauthorised inter-agent calls.

## 41. Agent Calls Proxy Agent  [P7]

- key: `agent-calls-proxy`; scope: interaction; book level: H4; source: ch8 p337
- requires: 15 agent-authn-authz, 31 agent-delegates-to-agent
- related: 40 mesh-defense

All interaction with third-party systems goes through a dedicated proxy agent that alone holds the credentials and logic for that boundary.

Detect in code: one component owns each external integration; credentials only in the proxy; other agents call the proxy, not the API.
ASE checks: `trust_declared`, `data_exposure`.
Metric: external API error rate; security incidents at the boundary.

## 42. Blackboard Knowledge Hub  [P7]

- key: `blackboard`; scope: coordination; book level: L5; source: ch5 p170
- requires: 35 shared-epistemic-memory
- related: 51 swarm

Agents post typed, versioned facts and hypotheses to a shared board and react to each other's entries; a controller validates contributions and drives convergence.

Detect in code: shared board with typed entries; agents triggered by board changes; controller deciding convergence.
ASE checks: `bounded_cycles`, `progress_conditions`.
Metric: time to convergence; invalid entries rejected.

## 43. Resource Allocation  [P7]

- key: `resource-allocation`; scope: coordination; book level: L5; source: ch5 p198
- requires: 30 supervisor
- related: 44 contract-net

Shared, limited resources (compute, tools, physical assets, budget) are assigned to agents by explicit policy or optimisation rather than first come, first served.

Detect in code: allocator component; resource requests and grants; allocation policy.
ASE checks: `cost_budget`.
Metric: utilisation; starved requests.

## 44. Contract-Net Marketplace (Mediator + Bids)  [P7]

- key: `contract-net`; scope: coordination; book level: L5; source: ch5 p173
- requires: 37 tool-agent-registry, 43 resource-allocation
- related: 45 trust-decay

A manager announces a task, capable agents bid with cost, time and confidence, and the manager awards the task to the best bid.

Detect in code: task announcement; bids with cost / ETA / confidence; award function.
ASE checks: none yet (review by reading).
Metric: award quality vs best possible; bidding overhead.

## 45. Trust Decay and Scoring  [P7]

- key: `trust-decay`; scope: governance; book level: L6, R4; source: ch7 p305
- requires: 19 custom-evaluation-metrics, 31 agent-delegates-to-agent
- related: 44 contract-net

The orchestrator keeps a reputation score per agent that rises with good results, falls with failures and decays toward a baseline, and prefers trusted agents when delegating.

Detect in code: score per agent updated from outcomes; decay over time; routing weighted by score.
ASE checks: none yet (review by reading).
Metric: reliability trend per agent.

## 46. Canary Agent Testing  [P7]

- key: `canary-testing`; scope: governance; book level: R4; source: ch7 p310
- requires: 19 custom-evaluation-metrics, 13 causal-dependency-graph
- related: 22 planner-scorer

A new agent version receives a small share of real traffic and is compared with the current one; it is promoted only if its metrics hold, otherwise rolled back.

Detect in code: traffic split between versions; side-by-side metrics; automatic promote / rollback.
ASE checks: `envelope_gate`.
Metric: regression rate of canary vs stable.

## 47. Majority Voting Across Agents  [P7]

- key: `majority-voting`; scope: robustness; book level: R5, ch12 L3; source: ch7 p271
- requires: 26 parallel-execution-consensus, 31 agent-delegates-to-agent
- related: 48 consensus

For the most critical decisions a panel of independent agents votes and the majority outcome is taken; no majority means escalation.

Detect in code: odd-sized panel of agents; vote tally; no-majority escalation.
ASE checks: `minimum_cut`.
Metric: conflict rate (no majority); decision error rate.

# P8 Decentralised coordination and self-improvement

Goal: Agents agree, negotiate and self-organise without a central authority, and the system improves its own models from generated and real feedback.

Book: Agentic maturity L6; ch12 L3

## 48. Consensus  [P8]

- key: `consensus`; scope: coordination; book level: L6; source: ch5 p189
- requires: 31 agent-delegates-to-agent, 35 shared-epistemic-memory
- related: 47 majority-voting, 50 conflict-resolution

Agents with conflicting information debate in rounds, exchanging evidence and revising positions, until they converge on a shared answer.

Detect in code: debate rounds between agents; convergence criterion; round limit.
ASE checks: `bounded_cycles`, `progress_conditions`.
Metric: rounds to consensus; accuracy vs single agent.

## 49. Agent Negotiation  [P8]

- key: `negotiation`; scope: coordination; book level: L6; source: ch5 p194
- requires: 31 agent-delegates-to-agent
- related: 44 contract-net

Agents with competing goals exchange offers and counter-offers under a protocol until they reach a compromise or walk away.

Detect in code: offer / counter-offer messages; utility or limit per agent; deadline or walk-away rule.
ASE checks: `bounded_cycles`.
Metric: agreement rate; outcome utility.

## 50. Conflict Resolution  [P8]

- key: `conflict-resolution`; scope: coordination; book level: L5-L6; source: ch5 p204
- requires: 30 supervisor
- related: 48 consensus, 49 negotiation

Conflicting plans, claims or resource demands are detected and resolved, first by central policy, at higher maturity by the agents themselves through consensus or negotiation.

Detect in code: conflict detection between outputs or plans; resolution policy or protocol; resolution recorded.
ASE checks: none yet (review by reading).
Metric: conflicts resolved without escalation.

## 51. Swarm Architecture (emergent decentralised coordination)  [P8]

- key: `swarm`; scope: coordination; book level: L5-L6; source: ch5 p166
- requires: 35 shared-epistemic-memory, 37 tool-agent-registry
- related: 42 blackboard, 27 event-driven-reactivity

There is no central controller: agents pull tasks from a shared board, do their part and update the task for the next agent, giving resilience and parallelism.

Detect in code: shared task board; agents self-select work; no orchestrator in the call graph.
ASE checks: `articulation_points`, `progress_conditions`.
Metric: throughput; stuck tasks.

## 52. Preference-Controlled Synthetic Data Generation  [P8]

- key: `synthetic-preference-data`; scope: learning; book level: ch12 L3; source: ch11 p411
- requires: 22 planner-scorer
- related: 53 coevolved-training
- techniques: SFT / PEFT, DPO

An LLM generates pairs of better and worse outputs under controlled conditions to build preference datasets for training a scorer or agent (e.g. with DPO), checked against offline benchmarks and periodic human review.

Detect in code: generator producing preferred / rejected pairs; benchmark checks on generated data; human spot review.
ASE checks: none yet (review by reading).
Metric: scorer agreement with human judgement.

## 53. Coevolved Agent Training  [P8]

- key: `coevolved-training`; scope: learning; book level: L6; source: ch11 p417
- requires: 22 planner-scorer, 52 synthetic-preference-data
- related: 46 canary-testing

Planner and scorer are improved in turns: the scorer's feedback tunes the planner, the improved planner's outputs train a better scorer; external grounding prevents drift and collusion.

Detect in code: alternating training of generator and judge; golden-set check each cycle; drift monitoring.
ASE checks: `envelope_gate`.
Metric: held-out quality per cycle; divergence from golden set.

## 54. Measuring Business Value (ROI)  [P8]

- key: `roi`; scope: governance; book level: ch11; source: ch11 p429
- requires: 19 custom-evaluation-metrics, 21 tokenomics

The system's effect is measured in business terms (time saved, errors avoided, revenue, cost) against its full cost, and reported to the people who fund it.

Detect in code: business KPIs captured per task; cost attribution; periodic value report.
ASE checks: `concern_coverage`.
Metric: value delivered / total cost.

## 55. Formation Control  [P8]

- key: `formation-control`; scope: coordination; book level: L6; source: ch5 p211
- requires: 51 swarm

Physical agents such as drones or robots keep a collective spatial structure by local rules. Kept in the knowledge base; applies only when a spec involves physical swarms.

Detect in code: position-based coordination rules; neighbour sensing.
ASE checks: none yet (review by reading).
Metric: formation error; collisions.
