"""The agent pattern catalogue: list, show, validate, coverage matrix, report.

Stdlib only. Reads ../references/patterns.json (the single source of truth).

    python catalogue.py list [P1 P2 ...]        patterns, in adoption order
    python catalogue.py show <key|id>           one pattern card
    python catalogue.py validate                catalogue integrity (exit 1 on error)
    python catalogue.py matrix [P1 P2 ...]      blank coverage matrix to fill in
    python catalogue.py coverage < matrix.txt   report on a filled matrix
    python catalogue.py markdown [--write]      the catalogue as markdown
                                                (--write: references/catalogue.md)

Through run_skill_script (stdin only, no argv) the first stdin line is the
command and the rest is its input, e.g. "coverage\\n<matrix lines>".

Matrix line format, one per pattern (comments start with #):

    05 watchdog-timeout | missing | yes | llm.py:40 client has no timeout

    status   present | partial | missing | n/a
    required yes | no     (does this system need the pattern now?)
    evidence free text: file:line, test name, or why n/a
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE.parent / "references" / "patterns.json"
MARKDOWN = HERE.parent / "references" / "catalogue.md"

#: the computable checks in ASE (sysmlagents.checks); ASE's tests keep this in step
KNOWN_CHECKS = {
    "orphan_stages", "dangling_exits", "vocabulary_conformance", "cost_budget",
    "latency_budget", "llm_call_count", "fanout_compounding", "cost_sensitivity",
    "trust_escalation", "data_exposure", "provenance_paths", "unsourced_stages",
    "articulation_points", "minimum_cut", "cascade_depth",
    "requirement_traceability", "bounded_cycles", "progress_conditions",
    "trust_declared", "fallback_coverage", "verification_coverage",
    "concern_coverage", "check_coverage", "orphan_stakeholder",
    "high_risk_classification", "sandbox_consistency", "tool_authorisation",
    "build_surface", "duplicate_capability", "variation_rules", "envelope_gate",
    "critical_path", "citation_carriers", "evidence_generable",
}
STATUSES = ("present", "partial", "missing", "n/a")


def load() -> dict:
    return json.loads(DATA.read_text("utf-8"))


def _index(cat: dict) -> tuple[dict, dict]:
    by_id = {p["id"]: p for p in cat["patterns"]}
    by_key = {p["key"]: p for p in cat["patterns"]}
    return by_id, by_key


def _find(cat: dict, ref: str) -> dict:
    by_id, by_key = _index(cat)
    if ref.isdigit() and int(ref) in by_id:
        return by_id[int(ref)]
    if ref in by_key:
        return by_key[ref]
    raise SystemExit(f"no pattern {ref!r}; try `list`")


def _stages(cat: dict, wanted: list[str]) -> list[dict]:
    ids = [s["id"] for s in cat["stages"]]
    bad = [w for w in wanted if w not in ids]
    if bad:
        raise SystemExit(f"unknown stage(s) {bad}; stages are {ids}")
    return [p for p in cat["patterns"] if not wanted or p["stage"] in wanted]


# -- commands ------------------------------------------------------------

def cmd_list(cat: dict, args: list[str]) -> int:
    titles = {s["id"]: s["title"] for s in cat["stages"]}
    stage = None
    for p in _stages(cat, args):
        if p["stage"] != stage:
            stage = p["stage"]
            print(f"\n{stage}  {titles[stage]}")
        print(f"  {p['id']:>2}  {p['key']:<30} {p['name']}  (ch{p['chapter']} p{p['page']})")
    return 0


def card(cat: dict, p: dict) -> str:
    by_id, _ = _index(cat)
    name = lambda i: f"{i} {by_id[i]['key']}"
    lines = [
        f"## {p['id']}. {p['name']}  [{p['stage']}]",
        "",
        f"- key: `{p['key']}`; scope: {p['scope']}; book level: {p['book_level']}; "
        f"source: ch{p['chapter']} p{p['page']}",
        f"- requires: {', '.join(name(i) for i in p['requires']) or 'none'}",
    ]
    if p.get("related"):
        lines.append(f"- related: {', '.join(name(i) for i in p['related'])}")
    if p.get("techniques"):
        lines.append(f"- techniques: {', '.join(p['techniques'])}")
    lines += [
        "",
        p["summary"],
        "",
        "Detect in code: " + "; ".join(p["detect"]) + ".",
        f"ASE checks: {', '.join(f'`{c}`' for c in p['checks']) or 'none yet (review by reading)'}.",
        f"Metric: {p['metric']}.",
    ]
    return "\n".join(lines)


def cmd_show(cat: dict, args: list[str]) -> int:
    if not args:
        raise SystemExit("show <key|id>")
    print(card(cat, _find(cat, args[0])))
    return 0


def validate(cat: dict) -> list[str]:
    errors = []
    ps = cat["patterns"]
    ids = [p["id"] for p in ps]
    if ids != list(range(1, len(ps) + 1)):
        errors.append("ids must be 1..N in file order")
    keys = [p["key"] for p in ps]
    if len(set(keys)) != len(keys):
        errors.append("duplicate keys")
    stage_ids = [s["id"] for s in cat["stages"]]
    order = {s: i for i, s in enumerate(stage_ids)}
    last = -1
    for p in ps:
        where = f"{p['id']} {p['key']}"
        for f in ("name", "stage", "chapter", "page", "scope", "summary",
                  "requires", "detect", "checks", "metric"):
            if f not in p:
                errors.append(f"{where}: missing field {f}")
        if p.get("stage") not in order:
            errors.append(f"{where}: unknown stage {p.get('stage')}")
            continue
        if order[p["stage"]] < last:
            errors.append(f"{where}: stage {p['stage']} out of order")
        last = order[p["stage"]]
        for r in p.get("requires", []):
            if r not in ids:
                errors.append(f"{where}: requires unknown {r}")
            elif r >= p["id"]:
                errors.append(f"{where}: prerequisite {r} does not precede it")
        for r in p.get("related", []):
            if r not in ids or r == p["id"]:
                errors.append(f"{where}: bad related {r}")
        for c in p.get("checks", []):
            if c not in KNOWN_CHECKS:
                errors.append(f"{where}: unknown check {c}")
        if not p.get("detect"):
            errors.append(f"{where}: no detection signals")
    return errors


def cmd_validate(cat: dict, args: list[str]) -> int:
    errors = validate(cat)
    for e in errors:
        print("ERROR", e)
    n = len(cat["patterns"])
    print(f"{'CATALOGUE OK' if not errors else 'CATALOGUE FAILED'}: "
          f"{n} patterns, {len(cat['stages'])} stages")
    return 1 if errors else 0


def cmd_matrix(cat: dict, args: list[str]) -> int:
    print("# coverage matrix - fill status, required, evidence; keep one line per pattern")
    print("# status: present | partial | missing | n/a    required: yes | no")
    print("# system: <name>    reviewed: <date>    reviewer: <role>")
    stage = None
    for p in _stages(cat, args):
        if p["stage"] != stage:
            stage = p["stage"]
            print(f"\n# {stage}")
        print(f"{p['id']:02d} {p['key']:<30} | missing | yes | ")
    return 0


def parse_matrix(cat: dict, text: str) -> tuple[dict, list[str]]:
    by_id, by_key = _index(cat)
    rows, errors = {}, []
    for n, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [x.strip() for x in line.split("|")]
        if len(parts) < 3:
            errors.append(f"line {n}: expected 'NN key | status | required | evidence'")
            continue
        head = parts[0].split()
        ref = head[1] if len(head) > 1 else head[0]
        p = by_key.get(ref) or (by_id.get(int(head[0])) if head[0].isdigit() else None)
        if p is None:
            errors.append(f"line {n}: unknown pattern {parts[0]!r}")
            continue
        status, req = parts[1].lower(), parts[2].lower()
        if status not in STATUSES:
            errors.append(f"line {n}: status {status!r} not in {STATUSES}")
            continue
        if req not in ("yes", "no"):
            errors.append(f"line {n}: required must be yes or no")
            continue
        rows[p["id"]] = {"status": status, "required": req == "yes",
                         "evidence": parts[3] if len(parts) > 3 else ""}
    return rows, errors


def coverage(cat: dict, text: str) -> tuple[str, int]:
    by_id, _ = _index(cat)
    rows, errors = parse_matrix(cat, text)
    out = []
    if errors:
        out += [f"ERROR {e}" for e in errors]
        return "\n".join(out), 1
    if not rows:
        return "ERROR empty matrix", 1

    def status(i):
        return rows.get(i, {}).get("status", "unreviewed")

    # requirements are transitive: a required pattern makes its prerequisites required
    required = {i for i, r in rows.items() if r["required"]}
    implied = set()
    frontier = list(required)
    while frontier:
        for r in by_id[frontier.pop()]["requires"]:
            if r not in required and r not in implied:
                implied.add(r)
                frontier.append(r)
    need = required | implied

    stage_ids = [s["id"] for s in cat["stages"]]
    titles = {s["id"]: s["title"] for s in cat["stages"]}
    out.append("Per stage (required patterns present / required):")
    reached = "none"
    still = True
    for s in stage_ids:
        ids = [p["id"] for p in cat["patterns"] if p["stage"] == s]
        req = [i for i in ids if i in need]
        ok = [i for i in req if status(i) == "present"]
        part = [i for i in req if status(i) == "partial"]
        out.append(f"  {s} {titles[s]:<48} {len(ok)}/{len(req)}"
                   + (f"  partial: {', '.join(by_id[i]['key'] for i in part)}" if part else ""))
        if still and len(ok) == len(req):
            reached = s if req else reached
        else:
            still = False
    out.append(f"\nStage reached (all required patterns present up to and including): {reached}")

    viol = []
    for i, r in sorted(rows.items()):
        if r["status"] in ("present", "partial"):
            for pre in by_id[i]["requires"]:
                if status(pre) in ("missing", "n/a", "unreviewed"):
                    viol.append(f"  {by_id[i]['key']} is {r['status']} but prerequisite "
                                f"{by_id[pre]['key']} is {status(pre)}")
    out.append("\nPrerequisite violations (built on a missing foundation):")
    out += viol or ["  none"]

    gaps = [i for i in sorted(need) if status(i) != "present"]
    out.append("\nRemediation order (sequence order; * = implied by a prerequisite):")
    for i in gaps:
        p = by_id[i]
        ev = rows.get(i, {}).get("evidence", "")
        out.append(f"  {p['id']:>2} {p['stage']} {p['key']:<30} {status(i):<10}"
                   f"{' *' if i in implied else '  '} metric: {p['metric']}"
                   + (f"  [{ev}]" if ev else ""))
    if not gaps:
        out.append("  none")

    na_req = [i for i in sorted(implied) if status(i) == "n/a"]
    if na_req:
        out.append("\nMarked n/a but needed by a required pattern - justify or reconsider:")
        out += [f"  {by_id[i]['key']}" for i in na_req]
    unreviewed = [p["key"] for p in cat["patterns"] if p["id"] not in rows]
    if unreviewed:
        out.append(f"\nNot in the matrix (unreviewed): {len(unreviewed)} patterns")
    return "\n".join(out), 0


def cmd_coverage(cat: dict, args: list[str], stdin: str) -> int:
    text, code = coverage(cat, stdin)
    print(text)
    return code


def markdown(cat: dict) -> str:
    lines = [
        "# Agent pattern catalogue",
        "",
        "Generated from `patterns.json` by `scripts/catalogue.py markdown --write`. "
        "Do not edit; edit the JSON and regenerate.",
        "",
        f"Source: {cat['source']}",
        "",
        "Adoption rule: a pattern is built only after the patterns it requires. "
        "Stages P1-P5 are single-agent, P6-P8 multi-agent.",
        "",
    ]
    for s in cat["stages"]:
        lines += [f"# {s['id']} {s['title']}", "", f"Goal: {s['goal']}", "",
                  f"Book: {s['book']}", ""]
        for p in cat["patterns"]:
            if p["stage"] == s["id"]:
                lines += [card(cat, p), ""]
    return "\n".join(lines).rstrip() + "\n"


def cmd_markdown(cat: dict, args: list[str]) -> int:
    text = markdown(cat)
    if "--write" in args:
        MARKDOWN.write_text(text, encoding="utf-8")
        print(f"wrote {MARKDOWN.name}")
    else:
        print(text)
    return 0


COMMANDS = {"list": cmd_list, "show": cmd_show, "validate": cmd_validate,
            "matrix": cmd_matrix, "markdown": cmd_markdown}


def main(argv: list[str]) -> int:
    stdin = ""
    if not argv:
        stdin = sys.stdin.read().lstrip("﻿")
        first, _, stdin = stdin.partition("\n")
        argv = first.split()
    elif argv[0] == "coverage":
        stdin = sys.stdin.read()
    if not argv:
        print(__doc__)
        return 1
    cmd, args = argv[0], argv[1:]
    cat = load()
    if cmd == "coverage":
        return cmd_coverage(cat, args, stdin)
    if cmd not in COMMANDS:
        print(__doc__)
        return 1
    return COMMANDS[cmd](cat, args)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.exit(main(sys.argv[1:]))
