---
name: ase-perspective-development-resource
description: >
  Apply the Rozanski & Woods Development Resource perspective to an agentic
  system's SysML v2 architecture - measure the build surface a design
  obliges (distinct stage definitions, model-calling ones, generated vs
  hand-written), estimate the model-API token spend of developing,
  evaluating and optimising it, record staffing, skills and time as
  stakeholder-owned assumptions, and apply scoping tactics. Use for "can the
  team build this", effort, build surface, component count, eval or GEPA
  spend, prototyping, descoping or iteration-planning questions about an ASE
  design. Do not use for per-interaction runtime token cost (use
  ase-perspective-cost) or for module structure and codeline organisation
  (use ase-viewpoint-development).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Development Resource perspective

Load `ase-arch-sysml-foundations` first. Control (read-only, read with
`ase_perspective("DevelopmentResource")`):
`AseMethodology::DevelopmentResourcePerspective`. No `AseCatalogue` entry
exists yet; cite the methodology entry.

## Definition

> "The ability of the system to be designed, built, deployed, and operated
> within known constraints around people, budget, time, and materials"
> - `AseMethodology::DevelopmentResourcePerspective`, source
> viewpoints-and-perspectives.info/home/perspectives.

**What the model can and cannot say.** The control is explicit: the one
computable part at model level is the hand-written surface; budget and
staffing are not in the model and are not pretended to be. Say that in
every finding. People, calendar and money enter only as `@Assumption`
records owned by a stakeholder, and every verdict is conditional on them.
Token spend of development is the exception: it follows from the design
plus the eval plan, so it can be computed.

**Applicability.** R&W: tight timescales, scarce skills, unfamiliar
technology. Agentic systems usually hit the last two - prompt and eval
engineering is a scarce skill, and each new stage kind is unfamiliar until
it has a contract and a test.

**Concerns.** Framed by the control: `Buildability` (can this be built,
tested and released by the team that owns it?). R&W's list, paraphrased:
time and cost constraints, required skills, available resources, budgets,
external dependencies. Agentic additions: model-API spend of development
and evaluation, labelled data (reference answers, approved plans), access to
the domain experts who label it, and provider quotas during load testing.

**Stakeholders.** `SoftwareEngineer` and `ProductOwner` hold `Buildability`;
add the `FinanceOwner` when evaluation spend is material, and the domain
expert who labels data (RS-01: HR approves generated reference answers).

## Activities -> SysML

R&W's activities: cost and time estimation, planning, dependency
management, scoping, prototyping, expectation management. In ASE:

### 1. Read the build surface

Run the sweep; `build_surface` reports, per pattern, distinct stage
definitions and how many call a model. Split that count by origin, because
only part of it is hand-written:

| Origin | What decides it | Hand-written? |
|---|---|---|
| Control flow, loop bound, budgets | the design (LangGraph emitted by `sysmlagents.codegen`) | no |
| Model stage with a codegen contract | `STAGE_CONTRACTS` has the kind (today: QueryOrchestrator, QueryReformulator, MultiQueryExpander, HydeGenerator, AnswerSynthesizer, RelevanceEvaluator, GroundednessEvaluator) | no - signature generated, instructions optimised by GEPA |
| Model stage without a contract | new kind | signature is a marked stub - write it, or add the contract |
| Non-model stage | retriever, fusion, reranker, memory, gate | yes - an implementation registered by kind; reusable across designs |
| Eval harness, datasets, release gate | spec and eval plan | yes - not counted by `build_surface` at all |

Record the split on the design with `@Extension` when you need it computed:

```
part def ContextualQueryRewriter :> Stage {
    @AseProfile::Extension {
        reason = "Development Resource needs generated vs hand-written; vocabulary lacks it.";
        extends = "Stage vocabulary (RagPatterns::Stage)";
    }
    attribute redefines llmCalls = 1;
    attribute origin : String = "stub";   // generated | stub | reused | handwritten
}
```

`vocabulary_conformance` will warn on `origin`; that warning is how the
extension stays visible - accept it with a decision naming the roadmap item.

### 2. Estimate the token spend of development

Development of an agentic system spends model tokens before it serves a
user: every eval run, every LLM-judge call, every optimisation rollout.
State the formula as `calc def` and the numbers as assumptions:

```
calc def EvalRunTokens {
    in cases : Integer;
    in programTokensPerCase : Integer;   // worst case from cost_budget
    in judgeTokensPerCase : Integer;
    return : Integer = cases * (programTokensPerCase + judgeTokensPerCase);
}
```

`programTokensPerCase` comes from the Cost perspective's analysis
(`cost_budget` worst case), not from a guess. Add `OptimisationTokens`
(rollouts x tokens + reflections x tokens) per GEPA run and multiply by the
planned number of runs. The model states tokens; the FinanceOwner converts
to money.

### 3. Record people, time and skills as assumptions

```
@Assumption {
    id = "A-DEV-04";
    statement = "10 full eval runs during development. Team size, skills and calendar are outside the model.";
    owner = "ProductOwner";
    revisitWhen = "plan review";
}
```

Name the external dependencies with lead times: labelled data, domain
expert time, provider quota increases, on-prem model procurement (RS-10 C-2).

### 4. Scope, prototype, set expectations

Compare planned spend with a budget requirement (named after its concern so
`evidence_generable` reaches it, e.g. `BuildabilityTokenBudget`); when over,
apply a tactic below and record before/after numbers in the decision.
Prototype the least familiar stage first (the stub signatures).

## Applying the perspective to each view

| View | What the perspective adds or checks |
|---|---|
| Context | external dependencies with lead times: model provider, labelling experts, data owners |
| Functional | stage count by origin; each new stage kind is build, contract and test work |
| Information / Knowledge | labelled datasets as items with owner and size; corpus ingestion work |
| Concurrency | loops and fan-out raise eval tokens per case, not only runtime cost |
| Development | generated vs hand-written modules; the harness and release gate |
| Deployment | environments needed for eval and load test; provider quotas |
| Operational | skills to run it: prompt regression triage, eval refresh |

## Analysis the model supports

| Question | Engine |
|---|---|
| How many distinct components, how many model-calling? | `build_surface` (CORPUS, info) |
| Is the same component reimplemented across designs? | `duplicate_capability`, `variation_rules` (Evolution) - reuse lowers the surface |
| How many are hand-written? | `calc def HandWrittenSurface` over the origin split |
| Token spend per eval run / per GEPA run | `calc def EvalRunTokens`, `OptimisationTokens`; inputs from `cost_budget` |
| Spend vs budget | requirement with `budgetTokens`; comparison in a `@Finding` |
| Staffing, calendar, money | none - review; assumptions only |

`build_surface` counts stage *types* in a pattern: two usages of one def
count once, and the harness, datasets and gates count zero. It is a floor.
A calc result goes in `@Finding.check` under the calc def's name, not a
check id.

## Reasoning over the model

- **What-if: swap a pattern.** Re-run `build_surface` on the alternative
  (A5). RS-01 NaiveRag is 2 kinds, 1 model-calling; RS-08's composition is
  about 13 and 6. The difference is the build cost of the richer pattern -
  put it in the trade study next to latency and quality.
- **Corpus reasoning.** A stage kind already implemented for another design
  is reuse, not new work; `duplicate_capability` lists them.
- **Sensitivity.** Spend is usually dominated by the number of full eval
  runs; record it as `@SensitivityPoint`.
- **Closed world.** Work the model does not declare (harness, data
  labelling, UI) is invisible to every check here; list it in `doc`.
- **Correspondence.** Every stage kind corresponds to a module in the
  Development view: `@Correspondence { kind = "realises"; rule = "every stage def has a module or a generated signature"; }`.

## Tactics -> SysML change -> expected effect

| Tactic (R&W) | Agentic form | SysML change | What should move |
|---|---|---|---|
| Incremental and iterative development | dev subset for daily runs, full sets at iteration end | fewer runs in the assumption, subset dataset item | planned spend |
| Prototyping and piloting | walking skeleton: stub retriever, real synthesiser | stage `origin = "stub"`, decision to replace | risk closed earlier |
| Descoping | drop one workload class or entry point for release 1 | remove a flow or path; requirement marked UNALLOCATED with reason | `build_surface` down |
| Fitness for purpose | reuse library stages, add codegen contracts | reuse library defs; contract added | hand-written surface down |
| Expectation management | publish the assumption list and spend | `@Assumption` + `@Finding` with numbers | - |
| (agentic) Cheaper judge | smaller model or heuristic metric for dev runs | judge tokens per case lowered | eval spend |

## Pitfalls -> detection in the model

| Pitfall (R&W, paraphrased) | Detection |
|---|---|
| Over-ambitious timescales | no time assumption, or one with no owner |
| Ignoring lead times | external dependency (labels, quota, hardware) with no `revisitWhen` |
| Underbudgeting | no token budget requirement; planned spend never computed |
| Insufficient testing and rollout resource | requirements without verification; no eval runs in the plan |
| No time for rework | one eval run planned |
| Limited access to business experts | reference data "to be generated" with no approving stakeholder |
| (agentic) stub counted as done | stage `origin = "stub"` in a release design |
| (agentic) eval cost ignored | GEPA planned with no `OptimisationTokens` estimate |
| (agentic) "the model will do it" | model-calling stage with no contract and no test |

## Checklist

Build surface read and split by origin; reuse identified; token spend of
eval and optimisation computed from the cost analysis; budget stated and
compared; people, time, skills and dependencies recorded as assumptions
with owners; least familiar parts prototyped first; every scoping choice a
decision with before/after numbers; findings say what the model cannot see.

## Output contract

In `ad/perspectives.sysml`:

1. `satisfy AseMethodology::DevelopmentResourcePerspective by <Design>;`
2. concern specialising `Buildability`; the build inventory by origin
3. `calc def`s for hand-written surface and token spend, results as `@Finding`
4. a token-budget requirement with a verification def
5. `@Assumption` for people, time, skills, dependencies
6. `@Finding` for `build_surface`; `@Tactic` + `@ArchitectureDecision` per change

Validate: gate on every file; `check_ad.py` with
`// ad-check: perspectives=DevelopmentResource`; `ase_gap`; the sweep. A
worked RS-08 example is in `references/example.sysml`.
