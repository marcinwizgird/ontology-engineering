---
name: ase-arch-scenarios
description: >
  Identify, write, prioritise and model architectural scenarios for an
  agentic system (ASE step A2) in SysML v2 - Rozanski & Woods functional and
  system-quality scenarios, SEI six-part quality attribute scenarios, a
  QAW-style elicitation, and the ATAM utility tree ranked by importance and
  difficulty - and turn them into derived requirements, verification cases
  and eval questions that drive pattern choice (A3) and walkthroughs (A5).
  Use when asked for quality attribute scenarios, a utility tree, "what
  situations must the architecture handle", acceptance criteria for an
  agent's qualities, or to turn vague quality requirements ("fast",
  "reliable", "safe") into testable ones. Do not use for evaluating an
  architecture against scenarios once views exist (use ase-arch-evaluation)
  or for a single view's walkthrough mechanics (use the matching
  ase-viewpoint-* skill).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Architectural scenarios (A2)

Load `ase-arch-sysml-foundations` first. Step: `ase_step("A2")` - *Identify
Scenarios*; consumes the consolidated inputs (A1); **controlled by** the
quality property requirements (you may sharpen them into scenarios, never
change them - a changed target is an A8 revision); produces architectural
scenarios; mechanism: architect, stakeholders, `ScenarioAgent` (retrieves
Concern, Perspective, Pattern nodes).

## Definition

> "A scenario is a description of a situation that the system is likely to
> encounter, allowing assessment of the effectiveness of the architecture in
> that situation. Scenarios cover required functional behaviour and desired
> quality properties." - `AseProcessIdef0::IdentifyScenarios` doc
> (`methodology/ase-process-idef0.sysml`), after R&W 2nd ed. ch7 and ch10.

**Two kinds (R&W).** *Functional scenarios* - a sequence of external events
the system must respond to ("how does it do X?"). *System quality
scenarios* - how the system reacts to a change in its environment: load,
failure, attack, a new requirement, a model upgrade. R&W give a scenario an
overview, system state, environment, stimulus and required response; the SEI
form below carries the same content with a testable measure.

**SEI six-part quality attribute scenario.** Source (who or what raises the
stimulus) - stimulus - artifact (what is stimulated) - environment (normal,
peak, degraded, startup, optimisation run...) - response - response measure
(a number with a unit, a dataset and a percentile). *General* scenarios are
per-quality templates; *concrete* scenarios instantiate them for one system.
Only concrete scenarios with a numeric measure are requirements.

**Uses.** Scenarios are the yardstick of the whole process: they select
patterns (A3), are walked through the draft views (A4/A5), become the
questions of the evaluation (A6), find missing requirements, and become the
verification cases and eval questions of the built system.

**Applicability.** Every design. **Stakeholders**: every concern holder -
each stakeholder in `ad/00-stakeholders.sysml` should source at least one
scenario.

## Procedure

1. **Collect the drivers.** From A1: requirement defs, concerns, `@Assumption`s,
   the perspectives you will apply. Each quality requirement and each
   applied perspective needs at least one scenario; each FR at least one
   functional scenario (the ones A5 walkthroughs will use).
2. **Elicit (QAW, compressed).** The SEI Quality Attribute Workshop runs:
   method and business presentation, architectural plan, identify drivers,
   **brainstorm** (each stakeholder contributes), **consolidate** (merge
   duplicates), **prioritise** (each stakeholder votes, about a third of the
   scenario count each), **refine** the top ones into six parts. An agent
   runs steps 4-8 against the spec: draft per concern, merge, and put the
   ranking to the stakeholder; unscripted answers become `@Assumption`s.
3. **Write six parts.** Replace every adjective with a measure: "feels
   instant" -> "p100 <= 2000 ms over the 60 replayed conversations at 30
   concurrent users". For model-dependent qualities the measure is
   statistical: name the metric, the dataset, its size and the threshold.
4. **Build the utility tree (ATAM).** Utility -> quality (perspective) ->
   refinement (the concern) -> leaf scenarios, each rated (importance to the
   business, difficulty/risk to achieve) H/M/L. (H,H) leaves are analysed
   first; (L,*) leaves may be dropped with a recorded decision. Run
   `utility_tree.py` to rank and to flag untestable leaves.
5. **Derive requirements.** Each concrete quality scenario is carried by a
   `requirement def` with the measure as numeric attributes and the scenario
   as `@QualityScenario` metadata; `satisfy` or `// UNALLOCATED X - reason`.
6. **Derive verification and eval questions.** Each (H,*) scenario gets a
   `verification def` whose `doc` names dataset, metric and threshold - the
   same names the eval harness uses.
7. **Hand on.** (H,H) scenarios select and reject patterns in A3 (a
   pattern's Context and Consequences either match the stimulus and response
   or they do not - record rejections with the scenario id); they are walked
   in A5 against the views, and their verdicts become `@Finding`s.

### Agentic general scenarios (templates to instantiate)

| Quality | Typical stimulus | Environment | Response measure |
|---|---|---|---|
| Performance | follow-up turn; plan request | peak, long conversation | p100 latency per workload class |
| Cost | any request; loop at max iterations | worst case | tokens per request, per class |
| Groundedness | question with no supporting source | corpus gap | abstention rate; unsupported-claim rate = 0 |
| Availability | model API 429 / outage; web search down | peak, degraded | % answered, fallback used, 0 unhandled errors |
| Security | injected instruction in a retrieved page; PII in a query to a tool | normal | instruction-following count = 0; PII leak rate = 0 |
| Drift | GEPA candidate prompt | optimisation run | no drop on the frozen release set |
| Evolution | provider retires the model | upgrade | eval delta within N points, days to re-release |
| Regulation | deletion request; audit query | normal | fragments retrievable = 0; record produced in N s |
| Usability (review-only) | first-time user | normal | task success in user evaluation |

## SysML guidelines

**Modeling.** Functional scenario: `use case def` with `subject` (the
design), `actor`s, `objective`, and `@FunctionalScenario { id; trigger;
expectedOutcome; }`. Quality scenario: `@QualityScenario { id; quality;
source; stimulus; artifact; environment; response; responseMeasure;
priority; }` inside the derived `requirement def`:

```
requirement def ChatReplyLatency {
    @QualityScenario {
        id = "QS-PERF-01";
        quality = "PerformanceAndScalability";
        source = "New hire";
        stimulus = "Sends a follow-up chat turn";
        artifact = "Chat path";
        environment = "Peak: 30 concurrent users, turn 12";
        response = "Cited answer resolving the follow-up";
        responseMeasure = "p100 <= 2000 ms over the 60 replayed conversations";
        priority = "H,H";
    }
    attribute budgetMs : Integer = 2000;
}
satisfy ChatReplyLatency by RS08::RS08Design;
verification def ChatLatencyReplay {
    subject design : RS08::RS08Design;
    objective {
        verify requirement ChatReplyLatency;
    }
}
```

Conventions: `quality` is a perspective name without the suffix (so
`utility_tree.py` can match allocated perspectives); `priority` is
"importance,difficulty"; keep `@QualityScenario` on one element per scenario;
scenarios live in `ad/00-stakeholders.sysml`. A budget the checks read
(`LatencyBudget.budgetMs`, `CostBudget.budgetTokens`) stays in
`design.sysml` - the scenario requirement references it in `doc` rather than
duplicating the number in a second place the checks do not read.

**Analysis.**

| Question | Engine |
|---|---|
| Six parts present, measure numeric | `check_ad.py` (scenarios) - accepts any digit |
| Ranked tree, (H,H) list, untestable leaves (stricter: `p95` alone is not a number), duplicate ids, allocated perspectives with no scenario | `run_skill_script("ase-arch-scenarios", "utility_tree.py", stdin=<AD files>)` |
| Derived requirement allocated | `requirement_traceability` (only for requirement defs in `design.sysml`) |
| Requirement traceable to a concern by name | `evidence_generable` (name match against concern names) |
| Scenario verified | `verification_coverage` - always fires (projection limit); review the `verification def`s |
| Does the design meet a quantity scenario? | `latency_budget` / `cost_budget` when the scenario's number is the design budget |

**Reasoning.** Scenarios are not projected into the graph (AD-kit metadata
and use cases are not), so graph questions go through their requirements:
*which concern has no scenario?* (concerns held vs `quality` values);
*which applied perspective has no scenario?* (`utility_tree.py` info);
*which (H,H) scenario has no verification?* (text search of `verify
requirement`); *which pattern satisfies the (H,H) set?* (A3: compare
scenario measures with `analyse()` numbers per library pattern -
`compare(analyse("models/rag-patterns.sysml"))`). A what-if on a
scenario is a what-if on its parameter: if one plausible change (one more
iteration, one more stage) flips the verdict, record a `@SensitivityPoint`
naming the scenario. Closed world: a missing scenario is a missing input,
not evidence that the situation will not occur.

## Pitfalls -> detection

| Pitfall | Detection |
|---|---|
| Too many scenarios | > ~30 leaves, or many (L,L); prune with a decision |
| Scenarios not prioritised | `priority` missing (`utility_tree.py` warning) |
| Wrong scenarios - nobody holds them | scenario `source` matching no stakeholder; concern with no scenario |
| Insufficient detail | missing part (`check_ad.py`, `utility_tree.py` error) |
| Untestable measure | no number (`utility_tree.py` error): "fast", "instant", "reliable" |
| Only sunny-day functional scenarios | every `environment` = "normal"; no failure, peak or change stimulus |
| Scenario never used | (H,H) scenario with no `verification def`, no walkthrough, no A3 rejection citing it |
| (agentic) average-case measure | p50 or "typically" for an LLM stage; worst case or p100 needed for budgets |
| (agentic) measure without dataset | eval metric with no named set and size |
| (agentic) deterministic expectation of a stochastic stage | exact output text as the response measure |
| (agentic) no adversarial scenario | no Security scenario with injected content in retrieved data or tool output |
| (agentic) ignores the model supply chain | no scenario with provider throttling, outage, retirement or silent update |
| (agentic) optimisation set scores as the measure | measure named on the set GEPA trains on |

## Checklist

Every stakeholder sources a scenario; every quality requirement and applied
perspective has one; every FR has a functional scenario; every quality
scenario has six parts and a numeric, dataset-backed measure; failure, peak,
attack and change environments present; tree ranked with the stakeholder,
(H,H) listed; each scenario carried by a requirement with `satisfy` or an
UNALLOCATED reason; (H,*) scenarios have verification defs naming eval
metrics; A3 decisions cite the scenario ids they rest on.

## Output contract

In `ad/00-stakeholders.sysml` (after stakeholders and concerns):
`use case def` + `@FunctionalScenario` per functional scenario; one
`requirement def` + `@QualityScenario` per quality scenario, with numeric
attributes and `satisfy` / UNALLOCATED; a `verification def` per (H,*)
scenario; `@SensitivityPoint` / `@ArchitectureDecision` where a scenario
forces a structural choice; the `utility_tree.py` output pasted into the A2
report.

Validate (from `AI Skills/skills`):

```
python description-to-sysmlv2/scripts/check_model.py < ad/00-stakeholders.sysml
python ase-arch-sysml-foundations/scripts/check_ad.py < ad/00-stakeholders.sysml
cat ad/*.sysml | python ase-arch-scenarios/scripts/utility_tree.py
```

Worked example (RS-08, two workload classes; (H,H): QS-PERF-01 chat
latency, QS-GRND-01 plan groundedness): `references/example.sysml`.
