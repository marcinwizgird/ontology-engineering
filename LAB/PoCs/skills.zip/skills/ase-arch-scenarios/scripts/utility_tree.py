#!/usr/bin/env python3
"""Tier-3 analysis: the ATAM utility tree from @QualityScenario metadata.

Reads SysML v2 text on stdin (any AD files, concatenated) and prints the
quality attribute utility tree:

    Utility -> quality (the scenario's `quality`, a perspective name)
            -> leaf scenarios ranked by priority (importance, difficulty)

`priority` is the AD-kit form "H,M" = importance H, difficulty M. Leaves rank
H > M > L on importance, then on difficulty; (H,H) leaves are listed again as
"analyse first" - they drive A3 pattern choice and A5 walkthroughs.

Flags (the scenario cannot be evaluated or ranked as written):
    missing part     one of source, stimulus, artifact, environment,
                     response, responseMeasure is empty or absent
    no number        responseMeasure has no number once percentile labels
                     (p50, p95, p100) are removed - "feels instant" is not
                     testable
    no priority      priority absent or not two of H/M/L
    duplicate id     two scenarios share an id
Info:
    perspectives allocated (`satisfy <X>Perspective by`) in the input that no
    scenario exercises.

Exit 1 when no scenario is found or any scenario has a missing part or no
number; 0 otherwise (priority and duplicate flags are warnings).
"""

import re
import sys

PARTS = ["source", "stimulus", "artifact", "environment", "response", "responseMeasure"]
RANK = {"H": 0, "M": 1, "L": 2}


def strip_comments(text):
    text = re.sub(r"/\*.*?\*/", lambda m: " " * len(m.group(0)), text, flags=re.S)
    return re.sub(r'//[^\n"]*$', "", text, flags=re.M)


def owner_of(text, pos):
    heads = list(re.finditer(r"\b((?:use\s+case|requirement|part|action|verification|concern)\s+def)\s+(\w+)", text[:pos]))
    return heads[-1].group(2) if heads else "-"


def main():
    raw = sys.stdin.read()
    text = strip_comments(raw)
    scenarios = []
    for m in re.finditer(r"@(?:\w+::)*QualityScenario\s*\{(.*?)\}", text, re.S):
        f = dict(re.findall(r"(\w+)\s*=\s*\"(.*?)\"\s*;", m.group(1), re.S))
        f["_owner"] = owner_of(text, m.start())
        scenarios.append(f)

    if not scenarios:
        print("FAIL - no @QualityScenario found - A2 has produced no quality scenarios")
        return 1

    errors, warnings, info = [], [], []
    seen = {}
    for s in scenarios:
        sid = s.get("id", "").strip() or f"<no id in {s['_owner']}>"
        s["_id"] = sid
        seen[sid] = seen.get(sid, 0) + 1
        missing = [p for p in PARTS if not s.get(p, "").strip()]
        if missing:
            errors.append(f"{sid}: missing part(s) {', '.join(missing)}")
        measure = re.sub(r"\bp\d{1,3}\b", "", s.get("responseMeasure", ""), flags=re.I)
        if s.get("responseMeasure", "").strip() and not re.search(r"\d", measure):
            errors.append(f"{sid}: response measure has no number - not testable: {s['responseMeasure']!r}")
        pr = re.findall(r"[HML]", s.get("priority", "").upper())
        if len(pr) < 2:
            warnings.append(f"{sid}: no priority (importance,difficulty as H/M/L) - ranked last")
            s["_rank"], s["_label"] = (3, 3), "(?,?)"
        else:
            s["_rank"], s["_label"] = (RANK[pr[0]], RANK[pr[1]]), f"({pr[0]},{pr[1]})"
    for sid, n in seen.items():
        if n > 1:
            warnings.append(f"{sid}: id used by {n} scenarios")

    tree = {}
    for s in scenarios:
        tree.setdefault(s.get("quality", "").strip() or "<no quality>", []).append(s)
    order = sorted(tree, key=lambda q: (min(x["_rank"] for x in tree[q]), q))

    print(f"Utility tree - {len(scenarios)} scenario(s), {len(tree)} quality attribute(s)")
    print("Utility")
    for q in order:
        leaves = sorted(tree[q], key=lambda x: (x["_rank"], x["_id"]))
        print(f"  {q}")
        for s in leaves:
            measure = s.get("responseMeasure", "").strip() or "<no measure>"
            print(f"    {s['_label']} {s['_id']} [{s['_owner']}] {measure}")

    first = [s["_id"] for s in scenarios if s["_rank"] == (0, 0)]
    print(f"Analyse first (H,H): {', '.join(sorted(first)) or 'none - check the ranking with stakeholders'}")

    covered = {re.sub(r"Perspective$", "", s.get("quality", "")) for s in scenarios}
    for p in sorted(set(re.findall(r"satisfy\s+(?:requirement\s+)?(?:\w+::)*(\w+)Perspective\s+by", text))):
        if p not in covered:
            info.append(f"perspective {p} is allocated but no scenario exercises it")

    head = "FAIL" if errors else ("OK with warnings" if warnings else "OK")
    print(f"{head} - {len(errors)} error(s), {len(warnings)} warning(s)")
    for tag, items in (("error", errors), ("warning", warnings), ("info", info)):
        for i in items:
            print(f"  - {tag}: {i}")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
