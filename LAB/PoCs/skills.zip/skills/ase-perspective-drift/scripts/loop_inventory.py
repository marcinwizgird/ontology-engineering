#!/usr/bin/env python3
"""Loop inventory for an ASE pattern or design (Drift perspective).

Reads a SysML v2 model (the ASE stage subset) on stdin and lists, per pattern,
every cycle (back edge), its declared bound, its members, the model-calling
members, cost per pass and the loop's share of worst-case cost. Reports
progress conditions and governance gates declared as design extensions -
which progress_conditions and envelope_gate cannot read (projection limit),
so the AD must carry them as accepted findings.

    python loop_inventory.py < design.sysml

Stdlib only. Exit 1 when a cycle has no maxIterations (bounded_cycles), else 0.
"""

import re


VOCAB = ("llmCalls", "latencyMs", "costTokens", "fanOut",
         "preservesProvenance", "hasFallback", "trustLevel", "dataClass")
ATTR = re.compile(r"^attribute\s+(?:(?:redefines|:>>)\s+)?(\w+)\s*(?::\s*[\w:]+)?\s*(?:=\s*(.+))?$")
PART_USE = re.compile(r"^part\s+(\w+)\s*:\s*(?:\w+::)*(\w+)")
FLOW = re.compile(r"^flow\s+(\w+)\s+to\s+(\w+)$")
PART_DEF = re.compile(r"^part\s+def\s+(\w+)(?:\s*(?::>|specializes)\s*(?:\w+::)*(\w+))?$")
ITEM_DEF = re.compile(r"^item\s+def\s+(\w+)")
REQ_DEF = re.compile(r"^requirement\s+def\s+(\w+)$")


def _val(raw):
    if raw is None:
        return None
    raw = raw.strip().rstrip(";").strip()
    if raw in ("true", "false"):
        return raw == "true"
    try:
        return int(raw)
    except ValueError:
        return raw.strip('"')


def _blocks(text):
    root = {"head": "<root>", "stmts": [], "kids": []}
    stack, buf = [root], []
    for ch in text:
        if ch == "{":
            kid = {"head": " ".join("".join(buf).split()), "stmts": [], "kids": []}
            stack[-1]["kids"].append(kid)
            stack.append(kid)
            buf = []
        elif ch == "}":
            tail = " ".join("".join(buf).split())
            if tail:
                stack[-1]["stmts"].append(tail)
            buf = []
            if len(stack) > 1:
                stack.pop()
        elif ch == ";":
            s = " ".join("".join(buf).split())
            if s:
                stack[-1]["stmts"].append(s)
            buf = []
        else:
            buf.append(ch)
    return root["kids"]


def read(text):
    """-> dict(defs={name:(parent, attrs)}, patterns={name:{attrs,usages,flows}},
    items={name:[attr names]}, reqs={name:attrs})"""
    text = re.sub(r"doc\s*/\*.*?\*/", " ", text, flags=re.S)
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    text = re.sub(r"//[^\n]*", " ", text)
    m = {"defs": {}, "patterns": {}, "items": {}, "reqs": {}}

    def attrs(b):
        out = {}
        for s in b["stmts"]:
            a = ATTR.match(s)
            if a:
                out[a.group(1)] = _val(a.group(2))
        return out

    def walk(bs):
        for b in bs:
            h = b["head"]
            if h.startswith("package "):
                for st in b["stmts"]:                  # bodiless `part def X :> Y;`
                    pd = PART_DEF.match(st)
                    if pd:
                        m["defs"].setdefault(pd.group(1), (pd.group(2), {}))
                walk(b["kids"])
                continue
            pd = PART_DEF.match(h)
            if pd:
                us = [PART_USE.match(s) for s in b["stmts"]]
                fl = [FLOW.match(s) for s in b["stmts"]]
                if any(us) or any(fl):
                    m["patterns"][pd.group(1)] = {
                        "attrs": attrs(b),
                        "usages": {u.group(1): u.group(2) for u in us if u},
                        "flows": [(f.group(1), f.group(2)) for f in fl if f]}
                else:
                    m["defs"][pd.group(1)] = (pd.group(2), attrs(b))
                continue
            it = ITEM_DEF.match(h)
            if it:
                m["items"][it.group(1)] = list(attrs(b))
                continue
            rq = REQ_DEF.match(h)
            if rq:
                m["reqs"][rq.group(1)] = attrs(b)
    walk(_blocks(text))
    return m


def resolved(m, name):
    chain, seen, cur = [], set(), name
    while cur and cur in m["defs"] and cur not in seen:
        seen.add(cur)
        chain.append(m["defs"][cur][1])
        cur = m["defs"][cur][0]
    out = {}
    for a in reversed(chain):
        out.update({k: v for k, v in a.items() if v is not None})
    return out


def back_edges(nodes, edges):
    succ = {n: [] for n in nodes}
    for a, b in edges:
        succ[a].append(b)
    colour, back = {n: 0 for n in nodes}, set()

    def visit(n):
        colour[n] = 1
        for x in succ[n]:
            if colour[x] == 1:
                back.add((n, x))
            elif colour[x] == 0:
                visit(x)
        colour[n] = 2
    for n in nodes:
        if colour[n] == 0:
            visit(n)
    return back


def _reach(succ, start):
    seen, stack = set(), [start]
    while stack:
        n = stack.pop()
        if n not in seen:
            seen.add(n)
            stack.extend(succ.get(n, []))
    return seen


def cycle_members(nodes, edges, back):
    succ = {n: [] for n in nodes}
    for a, b in edges:
        succ[a].append(b)
    mem = set()
    for tail, head in back:
        seen = _reach(succ, head)
        if tail in seen:
            mem |= {n for n in seen if tail in _reach(succ, n)}
        mem |= {head, tail}
    return mem


def analyse(m, pname, override=None):
    """Worst-case numbers, same assumptions as sysmlagents.analysis.
    override: {"maxIterations": n, "fanOut": {usage: n}, "defs": {def: {attr: v}}}"""
    ov = override or {}
    p = m["patterns"][pname]
    nodes = list(p["usages"])
    edges = [(a, b) for a, b in p["flows"] if a in p["usages"] and b in p["usages"]]
    at = {}
    for n in nodes:
        d = p["usages"][n]
        at[n] = dict(resolved(m, d))
        at[n].update(ov.get("defs", {}).get(d, {}))
        if n in ov.get("fanOut", {}):
            at[n]["fanOut"] = ov["fanOut"][n]
    mi = int(ov.get("maxIterations", p["attrs"].get("maxIterations", 1)) or 1)
    back = back_edges(nodes, edges)
    dag = [e for e in edges if e not in back]
    oncyc = cycle_members(nodes, edges, back)
    it = {n: (mi if n in oncyc else 1) for n in nodes}
    indeg = {n: 0 for n in nodes}
    succ = {n: [] for n in nodes}
    preds = {n: [] for n in nodes}
    for a, b in dag:
        succ[a].append(b)
        indeg[b] += 1
        preds[b].append(a)
    order, q = [], [n for n in nodes if indeg[n] == 0]
    while q:
        n = q.pop(0)
        order.append(n)
        for x in succ[n]:
            indeg[x] -= 1
            if indeg[x] == 0:
                q.append(x)
    fan = {}
    for n in order:
        fan[n] = max((fan.get(x, 1) * int(at[x].get("fanOut", 1) or 1) for x in preds[n]),
                     default=1)
    for n in nodes:
        fan.setdefault(n, 1)
    best = {n: 0 for n in nodes}
    for n in order:
        own = int(at[n].get("latencyMs", 0) or 0) * it[n]
        best[n] = (max(best[x] for x in preds[n]) if preds[n] else 0) + own
    rows = []
    for n in nodes:
        c = int(at[n].get("costTokens", 0) or 0)
        l = int(at[n].get("llmCalls", 0) or 0)
        rows.append((n, p["usages"][n], c, fan[n], it[n], c * fan[n] * it[n], l * fan[n] * it[n]))
    return {"rows": rows, "cost": sum(r[5] for r in rows), "llm": sum(r[6] for r in rows),
            "latency": max(best.values()) if best else 0, "maxIterations": mi,
            "back": sorted(back), "on_cycle": oncyc, "attrs": at, "edges": edges,
            "dag": dag, "declared_bound": "maxIterations" in p["attrs"]}


PROGRESS = re.compile(r"progress|minGain|stall|patience|noImprovement|exitWhen|stopWhen", re.I)
GATE = re.compile(r"gate|oversight|approval|approver", re.I)


def main(argv):
    import sys
    text = sys.stdin.read()
    m = read(text)
    if not m["patterns"]:
        print("no pattern found (a part def with part usages or flows)")
        return 1
    errors = 0
    for name, p in m["patterns"].items():
        a = analyse(m, name)
        print(f"\n== {name}")
        if not a["back"]:
            print("   acyclic - no runtime loop; Drift applies only to the optimiser")
        for tail, head in a["back"]:
            members = sorted(a["on_cycle"])
            judges = [n for n in members if int(a["attrs"][n].get("llmCalls", 0) or 0)]
            per = sum(r[5] for r in a["rows"] if r[0] in a["on_cycle"]) // max(a["maxIterations"], 1)
            loop_share = sum(r[5] for r in a["rows"] if r[0] in a["on_cycle"])
            if a["declared_bound"]:
                bound = f"maxIterations={a['maxIterations']}"
            else:
                bound = "NO BOUND (bounded_cycles error)"
                errors += 1
            print(f"   cycle {tail} -> {head}: {bound}; members {members}")
            print(f"      model-calling members: {judges or 'none'}; "
                  f"cost per pass {per:,} tok; loop total {loop_share:,} of {a['cost']:,}")
            prog = {n: [k for k in a["attrs"][n] if PROGRESS.search(k)] for n in members}
            prog = {n: ks for n, ks in prog.items() if ks}
            if prog:
                shown = "; ".join(f"{n}: {', '.join(ks)}" for n, ks in prog.items())
                print(f"      progress condition declared as extension ({shown}) - "
                      f"progress_conditions cannot read it and still fires; record @Finding accept")
            else:
                print("      no progress condition declared - a bound stops runaway, not livelock")
        gates = [n for n, d in p["usages"].items() if GATE.search(d) or GATE.search(n)]
        outs = [n for n in p["usages"] if not [e for e in a["dag"] if e[0] == n]]
        if gates:
            gated = [o for o in outs if o in gates]
            print(f"   gate stage(s) {gates}; outputs {outs}; "
                  f"{'every output is a gate' if set(outs) <= set(gates) else 'an output bypasses the gate'}")
    decl = sorted({d for d in re.findall(r"part\s+def\s+(\w+)", text) if GATE.search(d)})
    print(f"\ngovernance gate defs in the text: {decl or 'none'} - envelope_gate never sees them "
          f"(no Gate node is projected); it fires on every design")
    return 1 if errors else 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv[1:]))
