---
name: ase-perspective-drift
description: >
  Apply the ASE Drift perspective (an extension to Rozanski & Woods) to an
  agentic system's SysML v2 architecture - keep self-improvement (GEPA prompt
  optimisation, learned memory, provider model updates) inside the envelope
  the specification declared, bound and progress-check every runtime loop,
  model the governance gate that re-checks requirements over an optimised
  candidate, and record the checks that cannot yet see those constructs. Use
  for self-improving or self-modifying agents, prompt optimisation
  governance, release gates for prompt or model changes, loop termination,
  livelock, retry bounds, and "can it change itself outside the spec" in an
  ASE design. Do not use for design-time changeability, variation and reuse
  (use ase-perspective-evolution) or for what an agent may act on without
  approval (use ase-viewpoint-autonomy).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Drift perspective

Load `ase-arch-sysml-foundations` first. Methodology entry (control, read
with `ase_perspective("Drift")`, cite with `ase_provenance("DriftPerspective")`):
`AseMethodology::DriftPerspective`, `origin = "extension"`,
`checks = "bounded_cycles,progress_conditions,envelope_gate"`.

## Definition

> "The ability of the system to improve itself without leaving the
> constraints its specification declared." - `AseMethodology::DriftPerspective`
> doc, ase-methodology.sysml.

The recorded extension reason (quoted): *"R&W's Evolution perspective is
design-time changeability - flexibility against future change, balanced
against its cost. An agentic system changes its own behaviour in production,
which is a different property requiring a different check: not can it be
changed, but can it change itself outside the envelope."*

**Applicability.** Any design with (a) a runtime cycle, (b) an optimiser
that rewrites prompts, demonstrations or routing (ASE generates GEPA for
every pattern), (c) memory that accumulates across sessions, or (d) a model
endpoint that is not version-pinned. In practice: every ASE design.

**Concerns.** `BehaviouralDrift` ("If the system improves itself, what stops
it leaving the envelope?") and `Termination` ("Does every loop stop, and does
it make progress?"). **Stakeholders:** `ComplianceOfficer`, `SystemsEngineer`
(drift); `SoftwareEngineer`, `SiteReliabilityEngineer` (termination);
model risk management and internal audit where the spec names them (RS-10).

## Four sources of drift

| Source | What changes | Envelope instrument |
|---|---|---|
| Runtime loop | behaviour within one request (retry, re-plan, critic loop) | `maxIterations` + progress condition + exit on exhaustion |
| Optimiser | stage instructions and demos between releases (GEPA) | declared mutable surface + release gate over the requirement set |
| Memory / corpus | what the agent knows, session to session | retention and provenance rules (Knowledge view); re-evaluation on corpus change |
| Provider | the model behind an endpoint | pinned model version; a version bump is a candidate that goes through the same gate |

## Activities -> SysML

### 1. Declare the envelope

The envelope is the design's requirement set plus the evaluation thresholds
that stand for requirements a structure cannot prove. Make it one
requirement a candidate must satisfy:

```
requirement def EnvelopeHolds {
    doc /* RS-10 FR-5: "Any drop in statement support or refusal recall
         on the compliance set." */
    attribute minStatementSupportPct : Integer = 100;
    attribute maxRegressionPct : Integer = 0;
}
```

### 2. Bound every runtime loop

`maxIterations` on the pattern part def - the only construct the checks
read. A bound stops runaway; it does not stop a loop that repeats the same
failed step (livelock) or oscillates. Add a progress condition and an exit
on exhaustion as `@Extension` attributes on the design's judge / critic stage
def (e.g. `progressMetric`, `minGainPct`, `onExhaust`). `vocabulary_conformance`
will warn on them - intended. Keep the bound in the graph (generated
`MAX_ITERATIONS`), never only in a prompt.

### 3. Declare what the optimiser may change

A `part def PromptOptimiser` (in a view file, not `design.sysml` - a part def
with parts would be read as a pattern) with `mutableSurface` and `frozen`
attributes. In ASE's generated code GEPA rewrites signature *instructions*;
fields, the LangGraph topology and the loop bound are outside its reach.
State that, and freeze the rest: tools, authority, model version, release set.

The generated GEPA metric scores iterations inside the bound as +0.1 - a
preference a better score can outweigh. A constraint belongs in the gate,
not as a weighted term in the metric.

### 4. Model the governance gate

A `part def ReleaseGate` that re-runs the sweep and the frozen evaluation
set over each candidate, a `state def CandidateLifecycle`
(proposed -> gated -> released | rejected), and a `verification def`
verifying `EnvelopeHolds`. Separate the optimisation set from the release
set (RS-10: 200 synthetic for GEPA, 400 compliance pairs for release only).
Rejected candidates are evidence - keep them.

### 5. Analyse

| Question | Engine | Kind | What it reads / its limit |
|---|---|---|---|
| Does every cycle carry a bound | `bounded_cycles` (error) | STRUCTURE | back edges + presence of `maxIterations`; never the value (1,000 passes) - `cost_budget` and `latency_budget` judge the value |
| Does every bounded loop make progress | `progress_conditions` (warning) | ABSENCE | **fires on every back edge** of every pattern: no construct exists to declare a progress condition, so the check cannot be satisfied |
| Is there a gate re-checking requirements after optimisation | `envelope_gate` (warning) | ABSENCE | **fires on every design**: no `Gate` node is ever projected, whatever the AD declares |
| Loop cost per pass, share, progress / gate declarations | `scripts/loop_inventory.py` | text | sees extension attributes and gate defs the projection drops |
| Is the bound robust | `cost_sensitivity`, `cost_grid.py` | QUANTITY | RS-10 sketch: 6,200 tokens at 2 passes, 9,300 at 3 |

On the reference model `progress_conditions` fires on SelfRag
(grounded -> dense) and AgenticRag (grounded -> reformulator);
`envelope_gate` fires once on every model, including RS-01 which has no loop.

**Recording the two projection limits.** Do not suppress them and do not
treat them as open defects. For each: model the construct anyway (step 2 or
4), then carry the check result as

```
@Finding { check = "envelope_gate"; severity = "warning";
           disposition = "accept"; decision = "AD-DRIFT-02";
           message = "fires on every design - no Gate node is projected. Gate modelled as ReleaseGate ..."; }
```

with a decision citing `ase-arch-sysml-foundations/references/reasoning.md`
section 1 and naming the roadmap item (project `Gate`; add a progress
construct). The finding then says *what the model does declare*, which the
check cannot.

### 6. Verify

Runtime loops: eval metrics `critic_loop_count` / iterations per question,
and a stall test (a question the judge can never accept must exit at the
bound and escalate). Optimiser: the gate run is the verification; the
evidence pack lists every candidate and its verdict.

## Applying the perspective to each view

| View | What the perspective adds or checks in SysML |
|---|---|
| Context | the regulator / auditor who needs the change record; the model provider as a source of drift |
| Functional | `maxIterations`, judge and critic stages, progress and exhaustion extensions |
| Concurrency | cycles and their bounds; loops inside fan-out |
| Autonomy | who approves a candidate; optimiser has no authority to release; escalation on exhaustion |
| Knowledge | memory growth, retention, corpus versioning |
| Deployment | pinned model versions; candidate and live prompts deployed side by side |
| Operational | loop-count and gate telemetry; rollback to the last released prompt set |
| Development | prompt versioning, the release gate script in CI, frozen eval sets under version control |

## Tactics -> SysML change -> expected effect

| Tactic | SysML change | Check / evidence that should move |
|---|---|---|
| Bound every loop | `maxIterations` on the pattern | `bounded_cycles` clean |
| Progress-check loops | `@Extension` progress attributes on the judge | `loop_inventory.py` shows it; `progress_conditions` accepted |
| Exit and escalate on exhaustion | fallback / oversight stage after the loop | `fallback_coverage`; stall test |
| Gate every self-modification | `ReleaseGate` + `verification def` over `EnvelopeHolds` | `envelope_gate` accepted with evidence |
| Constrain the mutable surface | `PromptOptimiser.mutableSurface`, `frozen` | review; diff of candidate vs released |
| Separate optimisation and release data | two eval sets with sizes and owners | review; evidence pack |
| Pin the model | Deployment-view version attribute; bump = candidate | review |
| Shadow before release | candidate runs beside live, not serving | Operational-view state |
| Keep rollback | released prompt sets versioned; lifecycle state | review |

## Pitfalls -> how to detect them in the model

| Pitfall | Detection |
|---|---|
| Unbounded loop | `bounded_cycles` error; `loop_inventory.py` NO BOUND |
| Bound without progress (livelock) | no progress extension on any cycle member (`loop_inventory.py`) |
| Absurd bound | bound present, `cost_budget` / `latency_budget` fail at it |
| Bound in the prompt only | cycle in the graph with no `maxIterations`; generated code has none |
| Constraint as metric term | GEPA metric weights the constraint; no gate part or verification |
| Optimising on the release set | one eval set named for both; no size split |
| Optimiser may change structure | no `frozen` list; topology or bound differs between candidate and released design |
| Unpinned model | no version attribute on the model endpoint |
| Judge drifts with the generator | judge prompt in the mutable surface with no human-labelled check of the judge |
| Silent acceptance of the two limits | `progress_conditions` / `envelope_gate` absent from `@Finding`, or accepted without a decision |
| No record of rejected candidates | lifecycle has no `rejected` state; evidence pack lists winners only |

## Checklist

Envelope stated as one requirement with thresholds; every cycle bounded,
the bound's cost and latency computed; progress condition and exhaustion
exit declared for every loop; optimiser's mutable surface and frozen list
declared; release gate modelled with lifecycle and verification; optimisation
and release data separated; model versions pinned; both projection-limit
findings recorded with decision and roadmap item.

## Output contract

In `ad/perspectives.sysml` (optimiser and gate in `ad/autonomy.sysml` or
`ad/operational.sysml`):

1. `satisfy AseMethodology::DriftPerspective by <Design>;`
2. `maxIterations` on every cyclic pattern (`design.sysml`), progress / exhaustion `@Extension` on the judge stage def
3. `requirement def EnvelopeHolds` allocated, `verification def` verifying it
4. optimiser part with mutable surface and frozen list; `ReleaseGate`; `CandidateLifecycle`
5. `@Finding` per `bounded_cycles`, `progress_conditions`, `envelope_gate` result - the latter two `accept` with a projection-limit decision
6. `@ArchitectureDecision` for bound, progress rule, gate rule and data split

Validate (from `AI Skills/skills`):

```
python description-to-sysmlv2/scripts/check_model.py < <file>
python ase-arch-sysml-foundations/scripts/check_ad.py < <file>   # // ad-check: perspectives=Drift
python ase-perspective-drift/scripts/loop_inventory.py < <design.sysml>
```

then `ase_gap(<design>)` and `python -m sysmlagents.cli explain <RS-xx>`.
Worked RS-10 example (bounded SelfRag, governed GEPA): `references/example.sysml`.
