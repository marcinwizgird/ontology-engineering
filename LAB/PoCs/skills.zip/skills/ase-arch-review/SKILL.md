---
name: ase-arch-review
description: >
  Review an existing agentic system's implementation with the ASE
  architecture methodology - inventory the code, reconstruct the spec and
  scenarios, model the as-built architecture in SysML v2, run the ASE
  analysis and perspective checks, map it against the agent pattern
  catalogue (coverage matrix, stage reached, prerequisite violations), check
  tests and evaluation against the requirements, and produce findings, risks
  and a remediation plan in pattern-sequence order. Use when asked to review,
  audit or assess an agent, an LLM application or a vibe-coded prototype,
  "is this agent production ready", "what is missing", or before rebuilding
  one. Read-only: it does not change the reviewed code (use
  ase-build-from-design for the fixes). Do not use for designing a new
  system from a spec (use ase-arch-definition-process).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Architecture review of an existing agent

Retrospective use of the ASE process: the code exists, the architecture
description does not. Reconstruct it, then evaluate it with the same
controls a new design gets. Load first: `ase-arch-sysml-foundations`
(conventions), `ase-arch-patterns` (catalogue). Process context:
`ase-arch-definition-process`; read any step's frame with `ase_step`.

## Rules you are held to

- **Read-only.** The review changes nothing in the reviewed code. Fixes are
  a separate build step with its own plan.
- **Evidence for every claim.** Each fact carries `file:line`, a test name, a
  command output or the owner's words. No evidence, no finding.
- **As-built, not as-intended.** Model what the code does. What the owner
  intended goes into the spec; the difference is a finding.
- **Stated vs inferred.** A requirement from the owner or a document is
  *stated*; one read off the code is *inferred* and stays an `@Assumption`
  until the owner confirms it.
- **The reviewer drafts; the owner decides.** Findings carry a recommended
  action; acceptance, waiver or deferral is the owner's decision, recorded
  with their role.
- **No invented numbers.** Latency, cost and quality are measured, taken
  from logs, or labelled estimates with their basis.

## Output folder

In the reviewed repository (create it; it is the only thing you write):

```
architecture/
  spec.md                 reconstructed spec, RS-xx structure (see ASE docs/specs/RS-01-*.md)
  design.sysml            as-built analysable design (gate-clean)
  ad/                     00-stakeholders.sysml, context.sysml, functional.sysml,
                          knowledge.sysml, autonomy.sysml (+ others by risk), decisions.sysml
  review/
    inventory.md          R1
    scenarios.md          R3 (also modelled in ad/00-stakeholders.sysml)
    analysis.txt          R5 output, verbatim
    coverage.txt          R6 filled matrix
    coverage-report.txt   R6 script output, verbatim
    tests.md              R7
    findings.md           R8
    report.md             R9
```

## Steps

### R0 Scope
Name the system, the commit reviewed, the reviewer role, the owner role,
and what is out of scope. One paragraph at the top of `review/report.md`.

### R1 Inventory the implementation
Read the code; write `review/inventory.md` as facts with locations:

| Area | What to record |
|---|---|
| Entry points | how a request arrives (CLI, API, schedule, event) |
| Control flow | the agent loop or graph; who decides the next step; loop bounds |
| Model calls | provider, model, parameters, timeout, retries, where configured |
| Prompts | where they live, how assembled, what untrusted input enters them |
| Tools | each tool: purpose, side effects (read / write / external), credentials, sandbox |
| Knowledge | data sources, retrieval, ontologies or schemas, freshness |
| State | session memory, persistence, checkpoints |
| Outputs | format, schema validation, who consumes them |
| Observability | logs, traces, ids linking steps |
| Tests and evals | what exists, what it asserts, datasets |
| Deployment | how it runs, configuration, secrets handling |

### R2 Reconstruct the spec (A1, retrospective)
Write `spec.md`: purpose, stakeholders, functional requirements,
quality requirements with numbers where known, constraints. Mark each
requirement *stated* or *inferred*. Run `ase_obligations` for the
viewpoints you will use and list what is missing; ask the owner only about
those gaps. Unanswered items become `@Assumption` with `revisitWhen`.

### R3 Scenarios (A2) -> `ase-arch-scenarios`
5-10 scenarios: the main success path, the important variants, at least one
failure (model or tool down, timeout), one adversarial input, one
ambiguous input that should reach a person. Quality scenarios carry a
numeric response measure.

### R4 As-built model (A4, retrospective)
Model what exists in `design.sysml` (stages / agents / tools as parts,
flows, `latencyMs` and `costTokens` from measurement or labelled estimate,
`trustLevel` on stages touching untrusted input) and the views in `ad/`.
Draft from the inventory with `description-to-sysmlv2`; reuse library stage
defs where they fit and mark new kinds as `@Extension` with a reason. Gate
every file:

```
run_skill_script("description-to-sysmlv2", "check_model.py", stdin=<file>)
```

### R5 Analyse (A5)
Run the ASE analysis on the as-built design (ASE repository on `sys.path`):

```python
import sys; sys.path.insert(0, r"<path to>/ASE Agentic System")
from sysmlagents.workflow import walk
from sysmlagents.analysis import analyse, compare
r = walk("architecture/design.sysml")
for f in r.findings: print(f)                 # the perspective sweep
print(compare(analyse("architecture/design.sysml")))   # latency, cost, LLM calls, bounded, provenance, fallbacks
```

Save the output verbatim to `review/analysis.txt`. Walk each R3 scenario
through the model and note where it breaks. Load the `ase-perspective-*`
skill for every perspective with an error or warning.

### R6 Pattern coverage -> `ase-arch-patterns`
`matrix P1 P2 P3 P4 P5` (add P6-P8 for multi-agent), fill status, required
and evidence from R1, run `coverage`, save both files. Prerequisite
violations and required gaps become findings.

### R7 Tests and evaluation
`review/tests.md`: for each requirement and scenario, the test that
covers it or "none"; for each present pattern, whether a test measures its
metric; whether an eval dataset exists, how it was made, and whether results
are reproducible (pinned model, seed, versioned data).

### R8 Findings (A6 draft)
`review/findings.md`, one row per finding:

| Id | Severity | Finding | Evidence | Perspective / pattern | Recommendation | Owner decision |
|---|---|---|---|---|---|---|

Severity: **high** (wrong or unsafe results reach users, unbounded cost or
time, data exposure), **medium** (fails under a plausible scenario, not
auditable, not testable), **low** (maintainability, clarity). Mirror high
findings as `@Risk` / `@Finding` in `ad/decisions.sysml`.

### R9 Report
`review/report.md`: verdict in two sentences; stage reached (from the
script); top risks; remediation plan **in pattern-sequence order** (lower
stages first, prerequisite violations first within a stage), each item with
the metric that will show it is fixed; open assumptions; and an "ASE spec
candidate" section - the reconstructed spec plus the findings as its oracle,
so the system can later become an RS-xx spec for ASE.

## What vibe-coded agents typically miss

| Look for | Pattern / perspective |
|---|---|
| No timeout on model or HTTP clients; loops without a maximum | 5 watchdog-timeout; Concurrency |
| Retries that repeat the same failing call, unbounded | 10 adaptive-retry |
| Model and provider hard-coded; no fallback | 23 fallback-model; Availability |
| The LLM decides what a deterministic tool could compute (a reasoner, validator, parser, SQL) | design principle: deterministic where the model determines the answer; Groundedness |
| Free-text output parsed without a schema; no validation before use | 9 instruction-fidelity-auditing |
| Untrusted content pasted straight into prompts | 14 agent-self-defense; Security |
| Tools with write access and no permission check; secrets in code | 15 agent-authn-authz; 16 sandbox |
| No structured log linking input, steps and output | 13 causal-dependency-graph |
| No eval set; "it worked on my examples" | 19 custom-evaluation-metrics |
| No path to a person for ambiguous cases | 6 agent-calls-human |
| Prompts inline in code, untested, unversioned | Development viewpoint; 22 planner-scorer |

For an **ontology-validation agent** specifically, check first that formal
checks (consistency, SHACL / OWL constraints, schema) run in a reasoner or
validator and that the LLM only explains, proposes fixes or handles what
cannot be computed; that every reported violation cites the axiom, shape
or triple it comes from; and that a gold set of ontologies with known
defects measures precision and recall.

## Checklist

Scope stated; inventory with locations; spec with stated / inferred marked;
scenarios incl. failure, adversarial and ambiguous; as-built model
gate-clean; analysis output saved verbatim; coverage matrix and report
saved; tests mapped to requirements and patterns; findings with evidence and
severity; remediation in sequence order with metrics; owner decisions
recorded or marked pending; reviewed code unchanged (`git status` clean
outside `architecture/`).
