#!/usr/bin/env python3
"""Boundary report for an ASE Context view.

Reads SysML v2 text on stdin - the Context view file, ideally concatenated
with design.sysml - and reports what crosses the system boundary and whether
the Security checks can see it. Self-contained stdlib; text-level, not a
parser. Run check_model.py first.

Conventions it relies on (from ase-viewpoint-context):
    externals     part defs specialising ExternalEntity (directly or not),
                  with kind / slaLatencyMs / rateLimitRpm attributes
    context model a part def holding `flow of <Item> from a.p to b.q;`
    boundary item an item def with `attribute dataClass ... = "<class>";`
    design        part defs with part usages and `flow a to b;` (as
                  model_reader sees them); stage dataClass; the only
                  external stage kind the checks know is WebSearchFallback

Sections
    externals     each external, its kind and service levels
    crossings     each boundary flow: direction, item, dataClass
    design        what data_exposure will actually reason over
Exit 0 when there are no errors, 1 otherwise.
"""

import re
import sys

EXTERNAL_KINDS = {"WebSearchFallback"}       # mirrors sysmlagents.checks
RESTRICTED = {"restricted", "pii", "regulated", "secret"}
DECLASSIFIER = re.compile(r"anonymi|redact|saniti|mask|scrub|pseudonym", re.I)
SLA_ATTRS = ("slaLatencyMs", "rateLimitRpm")


def strip(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"//[^\n]*", " ", text)


def block_after(text, i):
    """Body of the brace block starting at or after index i, or ''."""
    j = text.find("{", i)
    k = text.find(";", i)
    if j < 0 or (0 <= k < j):
        return ""
    depth = 0
    for n in range(j, len(text)):
        if text[n] == "{":
            depth += 1
        elif text[n] == "}":
            depth -= 1
            if depth == 0:
                return text[j + 1:n]
    return text[j + 1:]


def top_level(body):
    """Body with nested blocks removed - statements of this level only."""
    out, depth = [], 0
    for ch in body:
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
        elif depth == 0:
            out.append(ch)
    return "".join(out)


def last(name):
    return name.split("::")[-1]


def attrs(body):
    found = {}
    for m in re.finditer(r"\battribute\s+(?:redefines\s+|:>>\s*)?(\w+)\s*"
                         r"(?::\s*[\w:]+)?\s*(?:=\s*([^;{]+))?;", top_level(body)):
        val = m.group(2).strip().strip('"') if m.group(2) else None
        found[m.group(1)] = val
    return found


def main():
    text = strip(sys.stdin.read())
    errors, warnings, info = [], [], []

    items = {}
    for m in re.finditer(r"\bitem\s+def\s+(\w+)", text):
        items[m.group(1)] = attrs(block_after(text, m.end())).get("dataClass")

    defs = {}                                   # name -> (parent, attrs, body)
    for m in re.finditer(r"\bpart\s+def\s+(\w+)\s*(?::>\s*((?:\w+::)*\w+))?", text):
        body = block_after(text, m.end())
        parent = last(m.group(2)) if m.group(2) else None
        defs[m.group(1)] = (parent, attrs(body), body)

    def chain(name):
        seen = []
        while name in defs and name not in seen:
            seen.append(name)
            name = defs[name][0]
        if name and name not in seen:
            seen.append(name)
        return seen

    def resolved(name):
        merged = {}
        for d in reversed(chain(name)):
            if d in defs:
                merged.update({k: v for k, v in defs[d][1].items() if v is not None})
        return merged

    externals = {n for n in defs if n != "ExternalEntity" and "ExternalEntity" in chain(n)[1:]}

    # -- externals -----------------------------------------------------------
    print(f"externals: {len(externals)}")
    for n in sorted(externals):
        a = resolved(n)
        sla = ", ".join(f"{k}={a[k]}" for k in SLA_ATTRS if a.get(k))
        print(f"  {n:22} kind={a.get('kind', '?'):8} {sla or 'no service levels'}")
        if a.get("kind") in ("system", "service") and not sla:
            warnings.append(f"external {n}: kind {a.get('kind')} with no slaLatencyMs / "
                            "rateLimitRpm - Performance cannot bound this dependency")
    for m in re.finditer(r"\bactor\s+\w+\s*:\s*((?:\w+::)*\w+)", text):
        if last(m.group(1)) not in externals:
            warnings.append(f"actor type {last(m.group(1))}: not an ExternalEntity - "
                            "use case actor missing from the context model")

    # -- crossings -----------------------------------------------------------
    crossings, touched = [], set()
    for name, (_, _, body) in defs.items():
        flows = re.findall(r"\bflow\s+of\s+((?:\w+::)*\w+)\s+from\s+([\w.]+)\s+to\s+([\w.]+)\s*;", body)
        if not flows:
            continue
        usages = {u: last(t) for u, t in
                  re.findall(r"\bpart\s+(\w+)\s*:\s*((?:\w+::)*\w+)", body)}
        for item, src, dst in flows:
            s, d, item = src.split(".")[0], dst.split(".")[0], last(item)
            for end in (s, d):
                if end not in usages:
                    errors.append(f"{name}: flow end '{end}' is not a part usage of the context model")
            if s not in usages or d not in usages:
                continue
            s_ext, d_ext = usages[s] in externals, usages[d] in externals
            if s_ext == d_ext:
                info.append(f"{name}: flow {s} -> {d} does not cross the boundary")
                continue
            ext = usages[s] if s_ext else usages[d]
            touched.add(ext)
            direction = "in " if s_ext else "out"
            if item not in items:
                errors.append(f"crossing {s} -> {d}: item {item} has no item def")
                dc = None
            else:
                dc = items[item]
                if not dc:
                    warnings.append(f"crossing {s} -> {d}: item {item} declares no dataClass")
            crossings.append((direction, item, dc, ext))
            if direction == "out" and (dc or "").lower() in RESTRICTED:
                if resolved(ext).get("kind") == "person":
                    info.append(f"restricted item {item} ({dc}) returns to person {ext} - "
                                "confirm the person is entitled to it")
                    continue
                warnings.append(f"restricted item {item} ({dc}) leaves the boundary to {ext} - "
                                "needs a decision and a matching stage dataClass")
    print(f"crossings: {len(crossings)}")
    for direction, item, dc, ext in crossings:
        arrow = "<-" if direction.strip() == "in" else "->"
        print(f"  {direction} {item:18} dataClass={dc or '?':10} {arrow} {ext}")
    for n in sorted(externals - touched):
        warnings.append(f"external {n}: declared but no flow crosses to or from it")

    # -- design: what data_exposure will read --------------------------------
    patterns = {}
    for name, (_, _, body) in defs.items():
        own = top_level(body)
        uses = dict(re.findall(r"\bpart\s+(\w+)\s*:\s*(\w+)\s*;", own))
        flows = re.findall(r"\bflow\s+(\w+)\s+to\s+(\w+)\s*;", own)
        if uses and flows:
            patterns[name] = (uses, flows)
    for pname, (uses, flows) in sorted(patterns.items()):
        sinks = [u for u, t in uses.items() if t in EXTERNAL_KINDS]
        for u, t in uses.items():
            if t not in EXTERNAL_KINDS and set(chain(t)[1:]) & EXTERNAL_KINDS:
                warnings.append(f"{pname}.{u}: {t} specialises an external kind but checks read "
                                "the usage's own type - invisible to data_exposure")
        classes = {u: str(resolved(t).get("dataClass") or "") for u, t in uses.items()}
        declared = [u for u, c in classes.items() if c]
        print(f"design {pname}: {len(uses)} stages, external sinks {sinks or 'none'}, "
              f"dataClass on {len(declared)}/{len(uses)}")
        if sinks and not declared:
            warnings.append(f"{pname}: external sink(s) but no stage declares dataClass - "
                            "a clean data_exposure here is a missing input, not a finding")
        succ = {}
        for a, b in flows:
            succ.setdefault(a, []).append(b)
        for u in uses:
            if classes[u].lower() not in RESTRICTED:
                continue
            for sink in sinks:
                path = find_path(succ, u, sink)
                if path:
                    via = [p for p in path[1:-1] if DECLASSIFIER.search(p + uses.get(p, ""))]
                    note = (f" via declassifier {', '.join(via)} - data_exposure still fires "
                            "(transitive, no declassification); accept with a decision") if via else ""
                    warnings.append(f"{pname}: {u} ({classes[u]}) reaches external sink "
                                    f"{sink}: {' -> '.join(path)}{note}")
    if crossings and patterns:
        outs = sum(1 for c in crossings
                   if c[0] == "out" and resolved(c[3]).get("kind") != "person")
        n_sinks = sum(1 for uses, _ in patterns.values() for t in uses.values() if t in EXTERNAL_KINDS)
        if outs > n_sinks:
            info.append(f"{outs} outbound crossing(s) to non-person externals, {n_sinks} external-kind "
                        "stage(s) in the design: the rest are invisible to the Security checks")

    head = "FAIL" if errors else ("OK with warnings" if warnings else "OK")
    print(f"{head} - externals {len(externals)} crossings {len(crossings)} designs {len(patterns)}")
    for tag, rows in (("error", errors), ("warning", warnings), ("info", info)):
        for r in rows:
            print(f"  - {tag}: {r}")
    return 1 if errors else 0


def find_path(succ, start, goal):
    stack, seen = [(start, [start])], {start}
    while stack:
        node, path = stack.pop()
        if node == goal:
            return path
        for nxt in succ.get(node, []):
            if nxt not in seen:
                seen.add(nxt)
                stack.append((nxt, path + [nxt]))
    return None


if __name__ == "__main__":
    sys.exit(main())
