---
name: ase-viewpoint-context
description: >
  Build, analyse and review the Context view of an agentic system in SysML v2
  following the Rozanski & Woods Context viewpoint - the system as a black
  box, its external entities (people, systems, model providers, tool and
  search APIs, corpora it reads), the ports and items crossing the boundary
  with their data class, use cases with actors, in/out-of-scope statements,
  implicit dependencies, and the service levels of external dependencies
  (latency, rate limits, availability). Use when asked for the system
  boundary, scope, context diagram, external dependencies, "what does this
  talk to", what data leaves the system, or to draft initial scope and
  context before A1. Do not use for the internal decomposition into stages
  (use ase-viewpoint-functional) or for data ownership, lifecycle and
  retention inside the boundary (use ase-viewpoint-information).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Context viewpoint

Load `ase-arch-sysml-foundations` first. Control: `AseMethodology::ContextViewpoint`
- read with `ase_viewpoint("Context")` and `ase_obligations("Context")`.
(`ase_obligations` currently returns the concern list and, for every
viewpoint, the `PerformanceOnFunctional` attribute list; the Context-specific
obligations are the ones in this skill.)

## Definition

> "Describes the relationships, dependencies, and interactions between the
> system and its environment" - `ContextViewpoint` `@RozanskiWoods`,
> source viewpoints-and-perspectives.info/home/viewpoints.

Methodology models: "system boundary, external actors, flows crossing it".
Added in R&W's 2nd edition; every other view assumes the boundary it draws.

**When it is written.** Twice. A *draft* Context view is the output of the
supporting activity "define initial scope and context" (R&W ch7, 7-1) and
an input to A1 - it happens *before* stakeholders are engaged, because you
need a scope to know whom to engage. It is refined after A1 answers arrive
and again whenever scope changes by agreement. The ASE workflow puts
`establishContext` first for the same reason: the boundary decides
everything after it.

**Stakeholders**: all; especially acquirers (product owner), users,
developers, and - for agentic systems - the security architect and
compliance officer, because the boundary is where data leaves.
**Applicability**: all systems.

**Concerns**: ASE frames `SystemBreakdown`. R&W's concerns, carried as
design concerns specialising it or `InformationFlow`: system scope and
responsibilities; identity of external entities and the services and data
used; nature and characteristics of external entities; identity,
responsibilities, nature and characteristics of external interfaces; other
external interdependencies; impact of the system on its environment;
overall completeness, consistency and coherence.

**Models**: the context model (black box, externals, interfaces, flows) and
interaction scenarios (use cases walked against the externals).

## R&W model elements -> SysML v2

| R&W element | SysML v2 | ASE convention |
|---|---|---|
| System (black box) | `part system : <Design>` inside a context model `part def`, ports added on the usage | the design part def from `design.sysml`, never re-declared |
| External entity | `part def X :> ExternalEntity` (base declared in the view) | `kind` = person, system, service, corpus; service levels as attributes |
| External interface | `port def` with `in`/`out item`; conjugated `~Port` on the external | one port per external interaction, not per protocol call |
| Interaction | `flow of <Item> from ext.port to system.port;` | direction matters: out-flows are the Security question |
| Data crossing | `item def` with `attribute dataClass : String = "..."` | vocabulary values; restricted = restricted, pii, regulated, secret |
| External dependency quality | `slaLatencyMs`, `rateLimitRpm`, `availabilityPct` on the external | feeds Performance (ceiling calc) and Availability (fallback need) |
| Interaction scenario | `use case def` with `subject`, `actor`s, `objective`, `include use case` | actors are ExternalEntity types |
| Scope | `doc` on a `Scope` part def: in-scope, out-of-scope, implicit dependencies | out-of-scope items become A1 elicitation guards |
| Impact on environment | `doc` + `@Risk` on the out-flow | e.g. load on a vendor API, writes to another system |

Agentic externals that are routinely missed: the **model provider** (every
prompt is an out-flow, usually carrying user text), **tool and MCP servers**,
**search APIs**, **corpora owned by another team**, **identity provider**
(where tenant and role come from), **eval / telemetry sinks** (traces carry
prompts), and **the human in the loop** as an actor distinct from the user.

## Activities -> SysML

1. **Draft scope (7-1, before A1).** From the brief: one `Scope` part def
   whose `doc` states goals, in-scope, out-of-scope. Name every external you
   can see. Each open question ("is a hosted model acceptable?", "what may
   go to the web?") is an A1 question - record it, do not answer it.
2. **Identify external entities.** One `part def :> ExternalEntity` per
   external. Ask per external: who owns it, is it trusted, what does it cost
   us when it is slow or down. For agentic systems enumerate model
   provider, tools, retrieval sources, identity, telemetry explicitly.
3. **Define the interfaces.** One `port def` per interaction, items in and
   out. The system gets the port; the external gets `~Port`:
   ```
   port def WebSearchPort {
       out item query : AnonymisedQuery;
       in item pages : VendorPage[0..*];
   }
   part def SearchApi :> ExternalEntity {
       attribute redefines slaLatencyMs = 800;
       attribute redefines rateLimitRpm = 600;
       port api : ~WebSearchPort;
   }
   ```
4. **Classify what crosses.** Every boundary item gets a `dataClass`. An
   item leaving with a restricted class needs a decision. Items that enter
   as text an LLM will read (web pages, tool results, uploaded documents)
   are prompt-injection carriers - say so in their `doc`.
5. **Draw the context model.** A `part def <Design>ContextModel` with the
   system usage, one usage per external and one `flow of` per crossing:
   ```
   flow of AnonymisedQuery from system.web to search.api;
   flow of ModelPrompt from system.llm to model.api;
   ```
6. **Record dependency service levels.** `slaLatencyMs`, `rateLimitRpm`,
   `availabilityPct` on each service external; unknown -> `@Assumption`
   with owner and revisit trigger. These are what the Performance
   perspective's throughput ceiling and the Availability perspective's
   fallback decision consume.
7. **Walk interaction scenarios.** One `use case def` per A2 functional
   scenario, actors typed by externals, `include use case` for optional
   paths (the web fallback). Every actor must appear in the context model.
8. **Hand the boundary to the design.** For every out-flow to a
   non-person external, the design stage that emits it must declare the
   matching `dataClass`, and an external that should be a Security sink
   must be a stage typed `WebSearchFallback` (see Analysis). State each as
   a `@Correspondence`.

## The view

```
view def ContextView {
    satisfy requirement vp : AseMethodology::ContextViewpoint;
    filter @SysML::PartUsage or @SysML::PortUsage or @SysML::FlowUsage or @SysML::UseCaseUsage;
}
view context : ContextView {
    expose RS04ContextModel::**;
    render asInterconnectionDiagram;
}
view boundaryTable : ContextView {
    expose RS04ContextModel::*;
    render asElementTable;      // external, kind, items in/out, dataClass, SLA
}
```

Keep the filter on one line (the gate is line-based). The filter excludes
the design's internal stages by construction: `expose` names the context
model, whose system usage is a black box. Exposing `RS04Design::**` here
would turn the Context view into a Functional one.

## Analysis the context model supports

| Question | Engine |
|---|---|
| What crosses the boundary, in which direction, with which data class | `run_skill_script("ase-viewpoint-context", "boundary_report.py", stdin=<design + context>)` |
| Externals with no service levels; actors not in the model; unconnected externals | `boundary_report.py` |
| Can restricted data reach an external sink | `data_exposure` - reads *stage* `dataClass` and stage type `WebSearchFallback` only |
| Is an external stage declared untrusted and reaching out | `sandbox_consistency`, `tool_authorisation` |
| Is the system high-risk (loop + external + ungrounded) | `high_risk_classification` |
| Throughput ceiling set by an external's rate limit | Performance `calc def ThroughputCeiling` over `rateLimitRpm` |
| Is a fallback needed for a flaky dependency | Availability: `fallback_coverage` once the design reacts |
| Scope completeness | none - review against the brief and A1 answers |

**What the checks actually see.** `checks.EXTERNAL_KINDS = {"WebSearchFallback"}`
and a stage's `type` is its usage's own def name, not its ancestry. So:
the model provider, an MCP tool, an email sender, or a stage def that
*specialises* `WebSearchFallback` are all invisible to `data_exposure`.
`boundary_report.py` reports the gap as "N outbound crossings, M
external-kind stages". Close it by typing the sink stage directly, or
record the crossing as a review item with a decision (RS-04 AD-CTX-03).

**No declassification.** `data_exposure` is transitive reachability. A
`pii` stage upstream of an anonymiser still reaches the web sink through
it, so the check fires even when the design is right. Carry it as a
`@Finding` with `disposition = "accept"` and a decision naming the
anonymiser and the eval constraint (`pii_leak_rate = 0`). A declassifier
attribute is a roadmap item, not an edit to `checks.py`.

## Reasoning over the context model

- *What leaves the system?* out-flows to non-person externals, with their
  `dataClass` - the list a DPO signs.
- *What does the system depend on to answer at all?* externals on every
  path of the primary use case; each is an availability dependency.
- *What if the search API is down / rate-limited?* the use case that
  includes it degrades; the design needs `hasFallback` or a stated abstention.
- *What if the model provider changes?* one external, one port - count the
  flows touching `ModelPort`; a provider change should touch one.
- Closed-world caveat: an external not declared is not absent. The context
  model is only as complete as the brief and A1; every "no crossing found"
  names the externals it was computed over.
- Correspondences (`@Correspondence`): every boundary flow lands on one
  design stage (Functional); every boundary item is an item def with a
  `dataClass` whose ownership is stated (Information); every retrieval
  source external appears in the Knowledge view; every external with a
  rate limit appears in the Performance model; every external a stage acts
  on has an authority level (Autonomy).

## Pitfalls -> detection

| Pitfall | Detection |
|---|---|
| Missing or incorrect external entities | model provider / telemetry / identity absent from `ExternalEntity` specialisations; review against the agentic list above |
| Missing implicit dependencies | a stage with `llmCalls > 0` and no `ModelProvider` external; corpus refresh source not modelled |
| Loose or inaccurate interface descriptions | crossing item with no `dataClass` (`boundary_report` warning); port with no items |
| Inappropriate level of detail | internal stages exposed in the Context view; per-call flows instead of per-interaction |
| Scope creep | new externals appear after A1 with no decision |
| Implicit or assumed context or scope | no `Scope` doc; out-of-scope list empty |
| Overcomplicated interactions | more than one port per external for the same exchange |
| Overuse of jargon | external names that are product codenames; `doc` missing |
| (agentic) invisible sink | out-flow to non-person external with no `WebSearchFallback` stage (`boundary_report` info) |
| (agentic) injection entry unmarked | inbound item read by an LLM with no untrusted note or decision |
| (agentic) SLA-less dependency | service external with no `slaLatencyMs`/`rateLimitRpm` (`boundary_report` warning) |

## Checklist

Every external named with owner and kind; model provider, tools, corpora,
identity and telemetry considered; every interface a port with items; every
crossing item classified; restricted out-flows each carry a decision;
service levels declared or assumed with a revisit trigger; use cases cover
the A2 functional scenarios and every actor is an external; scope and
out-of-scope written; impact on the environment (load on others' APIs,
writes) stated; the draft preceded A1 and the refinement followed it.

## Output contract

`ad/context.sysml` containing: boundary `item def`s with `dataClass`; `port
def`s; `ExternalEntity` and its specialisations with service levels; the
context model part def with `flow of` per crossing; `Scope` doc; `use case
def`s; the `ContextView` def and view usages; `@Correspondence` to
Functional, Information and Security; `@Assumption` for unknown SLAs;
decisions for every restricted out-flow; `@Finding` for any accepted
`data_exposure` result. Updates to `design.sysml`: `dataClass` (and
`trustLevel`) on the stages that emit boundary items.

Validate (from `AI Skills/skills`):
```
python description-to-sysmlv2/scripts/check_model.py < ad/context.sysml
python ase-arch-sysml-foundations/scripts/check_ad.py < ad/context.sysml   # directive: fragment viewpoints=Context
cat design.sysml ad/context.sysml | python ase-viewpoint-context/scripts/boundary_report.py
python -m sysmlagents.cli explain <RS-xx>
```
Report every surviving `boundary_report` warning with its decision.
Worked example (RS-04): `references/example.sysml`.
