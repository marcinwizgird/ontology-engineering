---
name: ase-perspective-availability-resilience
description: >
  Apply the Rozanski & Woods Availability and Resilience perspective to an
  agentic system's SysML v2 architecture - capture classes of service and
  availability targets, build the availability schedule, estimate platform
  and functional availability (model provider outages, rate limits,
  timeouts, malformed or refused model output), find single points of
  failure and cascades, apply fallback models, cached answers, retries,
  timeouts and circuit breakers, and record findings and decisions. Use for
  outages, degraded modes, fallback paths, single points of failure, SLAs,
  "what happens when the model API is down" or disaster recovery questions
  about an ASE design. Do not use for speed under load (use
  ase-perspective-performance-scalability) or for attacks and trust (use
  ase-perspective-security).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Availability and Resilience perspective

Load `ase-arch-sysml-foundations` first. Control (read-only):
`AseMethodology::AvailabilityAndResiliencePerspective` - read with
`ase_perspective("Availability")`; its concern with `ase_concern("FailureBehaviour")`.

## Definition

> "The ability of the system to be fully or partly operational as and when
> required and to effectively handle failures that could affect system
> availability" - `AseMethodology::AvailabilityAndResiliencePerspective`,
> source viewpoints-and-perspectives.info/home/perspectives.

"Fully *or partly*" is the agentic key: a copilot that answers from the
knowledge base alone while the web tool is down is partly operational, and
that degraded class of service must be designed, not discovered.

**Applicability.** R&W: complex or extended availability needs, complex
recovery, high public visibility. For agentic systems apply it whenever a
stage depends on a hosted model or a third-party tool - an element outside
your control with its own outages, rate limits and deprecations.

**Concerns.** ASE frames `FailureBehaviour` (what breaks when a participant
fails and how far it spreads). R&W add: classes of service, planned
downtime, unplanned downtime, time to repair, disaster recovery.
**Stakeholders**: `SiteReliabilityEngineer`, `SoftwareEngineer`; the product
owner decides classes of service; end users feel them.

## How ASE reads availability (verified in `sysmlagents/checks.py`)

| Check | Kind | Reads | Fires when |
|---|---|---|---|
| `articulation_points` | STRUCTURE | forward flows (back edges dropped) | removing one stage strands others reachable from the entries; skipped below 3 stages |
| `minimum_cut` | STRUCTURE | forward flows | a set of 1 or 2 non-exit stages severs every entry from every exit; reports the smallest |
| `cascade_depth` | REACHABILITY | forward flows | one stage failing strands 5 or more stages downstream (info) |
| `fallback_coverage` | ABSENCE | `hasFallback` | **no** stage in the pattern declares `hasFallback = true` |

Blind spots to state in every report:

1. **The exit is invisible.** The answer synthesiser - usually the stage
   most likely to fail (provider outage, 429, timeout) - is the exit: it is
   never in a cut and strands nothing downstream. Structure checks will not
   name it; you must.
2. **Common-mode failure is not projected.** Five LLM stages on one provider
   and one API key are five independent nodes to the graph but one failure
   in reality. It lives in the Deployment view; group stages by provider
   by hand (or with a `provider` `@Extension`) and treat each group as one
   component.
3. **`fallback_coverage` is pattern-wide.** One fallback anywhere clears it;
   it does not say the stage that fails has one. The library also uses
   `hasFallback` two ways (`WebSearchFallback` *is* a fallback,
   `RelevanceEvaluator` *routes to* one). Adopt one reading per design -
   "this stage has a declared degraded path" - and name the path in `doc`.
4. **No probabilities.** The checks are structural. Availability numbers
   come from the `calc def`s below over declared SLAs - estimates, stated as
   `@Assumption`.
5. `NaiveRag` (2 stages) is below the threshold of both structure checks.

## Activities -> SysML

R&W loop: capture availability requirements -> produce the availability
schedule -> estimate platform availability -> estimate functional
availability -> assess against the requirements -> rework.

### 1. Capture the availability requirements

Per class of service: target, measurement window, what "available" means
(an answer? a grounded answer? an abstention?), time to repair, and the
degraded behaviour the owner accepts.

```
requirement def ServiceAvailability {
    doc /* A1 answer (Support director): support hours 07-19 CET, weekdays. */
    attribute targetPercent : Real = 99.0;          // full class, per month
    attribute degradedTargetPercent : Real = 99.9;  // KB-only class
    attribute maxTimeToRepairMin : Integer = 30;
}
requirement def WebDownBehaviour {
    doc /* RS-04 scripted answer: answer from the KB with a warning that
         vendor docs could not be reached. */
}
```

### 2. Produce the availability schedule

Operating hours, planned downtime (daily re-index, model version changes,
key rotation) and the modes the system can be in. A `state def` in the
Operational view carries the modes; each transition names its trigger:

```
state def OperatingMode {
    entry; then normal;
    state normal;
    state kbOnly;          // web search unavailable
    state cacheOnly;       // model API unavailable
    transition first normal accept SearchApiDown then kbOnly;
    transition first kbOnly accept SearchApiUp then normal;
    transition first normal accept ModelApiDown then cacheOnly;
    transition first cacheOnly accept ModelApiUp then normal;
}
```

### 3. Estimate platform availability

From the Deployment view: each dependency's published or measured SLA,
recorded with its source. Series dependencies multiply; redundant ones
combine as one minus the product of unavailabilities:

```
calc def SerialAvailability {
    in a1 : Real;
    in a2 : Real;
    return : Real = a1 * a2;
}
calc def RedundantAvailability {
    in a1 : Real;
    in a2 : Real;
    return : Real = 1.0 - (1.0 - a1) * (1.0 - a2);
}
```

Count a provider once per common-mode group, not once per stage.

### 4. Estimate functional availability

Platform up is not answer out. List each stage's *functional* failure
modes - rate limit (429), timeout, content-filter refusal, malformed or
schema-violating output, context overflow, empty retrieval, tool error -
with detection, response and fallback. Put the table in the stage `doc` or a
requirement per stage; a mode with no detection is pitfall "ineffective
error detection".

### 5. Assess against the requirements

Run the sweep (`python -m sysmlagents.cli explain <RS-xx>`) and the calcs;
carry each result as `@Finding`. Compare the estimate to each class target;
record `@Risk` for any shortfall.

### 6. Rework

Apply tactics, re-run, record before/after (e.g. `minimum_cut` 1 -> 2).

## Applying the perspective to each view

| View | What the perspective adds in SysML |
|---|---|
| Context | external dependencies with SLAs (model API, search API, source systems); who is told when degraded |
| Functional | fallback stages; `hasFallback`; failure-mode table per stage; guard stages that fail closed |
| Information | index rebuild from source; backup of memory and conversation state; stale-cache policy |
| Knowledge | corpus snapshot for DR; what the cache may answer and for how long |
| Concurrency | retry and timeout bounds; no retry inside a loop without a bound |
| Deployment | provider and region per stage; replicas; second provider; DR site |
| Operational | `OperatingMode` state def; health probes; circuit breakers; runbooks; time to repair |
| Development | error-handling standard for model calls (timeouts, typed errors, idempotent tools) |

## Analysis the perspective supports

| Question | Engine |
|---|---|
| Whose failure disconnects the pipeline? | `articulation_points` |
| Smallest failure set that severs input from answer | `minimum_cut` |
| How far does one failure spread? | `cascade_depth` |
| Is there any degraded path at all? | `fallback_coverage` |
| Which stages fail together? | review: group by provider / endpoint in Deployment |
| Availability per class of service | `SerialAvailability`, `RedundantAvailability` calcs over SLAs |
| Do retries break the latency or cost budget? | `latency_budget`, `cost_budget` with retries folded into the stage estimate |
| What-if: search API down, model API down | scratch variant without the stage + sweep; walk the `OperatingMode` transitions |

## Tactics -> SysML change -> expected effect

SEI groups availability tactics as detect faults, recover (preparation and
repair; reintroduction) and prevent faults; R&W add platform and
data-level tactics. Agentic forms:

| Tactic (source) | Agentic form | SysML change | Check / number that moves |
|---|---|---|---|
| Redundant spare (SEI recover) | fallback model on a *second provider* | `FallbackSynthesizer` stage, `hasFallback = true`, `provider` `@Extension` | common-mode group splits; redundant availability calc |
| Graceful degradation (SEI recover; R&W design for failure) | answer from cache or KB-only with a warning | cache stage as a second entry to synth; `OperatingMode` | `minimum_cut` 1 -> 2 |
| Retry (SEI recover) | bounded retry with backoff on 429 / 5xx | fold `timeout x attempts` into the stage `latencyMs`, `costTokens x attempts` into cost | `latency_budget`, `cost_budget` - a tradeoff point |
| Exception detection, timestamp, sanity checking (SEI detect) | timeout per model call; schema validation of model output | stage `doc` + requirement per failure mode | review; eval `schema_failure_rate` |
| Removal from service (SEI prevent) + exception detection | circuit breaker per provider | Operational `state def` closed / open / halfOpen | review |
| Heartbeat, ping/echo, condition monitoring (SEI detect) | synthetic probe question every minute | Operational telemetry element | review |
| Rollback (SEI recover) | pin model version; roll back prompt release | Development / Operational decision | review |
| HA clustering, load balancing, replication (R&W) | replicas of vector store; multiple API keys / deployments | Deployment attributes | platform calc |
| Log transactions; backup and DR (R&W) | re-index from source; conversation state journal | Information view; DR requirement with RTO / RPO | review |
| Relax transactional consistency (R&W) | serve slightly stale index during re-index | decision on staleness | removes planned downtime |

## Pitfalls -> detection in the model

| Pitfall (R&W + agentic) | Detection |
|---|---|
| Single point of failure | `articulation_points`, `minimum_cut = 1` |
| Cascading failure | `cascade_depth`; retry storms: retries without backoff or bound |
| Unavailability through overload | rate-limit ceiling below peak (Performance throughput calc); no queue or shedding |
| Overambitious availability requirements | target above the product of dependency SLAs |
| Ineffective error detection | stage with no failure-mode entry; model output used without validation |
| Overlooked global availability requirements | users in several time zones, single maintenance window (Location) |
| Incompatible technologies | fallback model with a different tool-call or output schema, never tested |
| Overestimation of component resilience | provider SLA taken as fact with no `@Assumption` |
| (agentic) invisible exit | synth never named although it is the likeliest failure - blind spot 1 |
| (agentic) fallback shares the failure | fallback model on the same provider or key |
| (agentic) loop on error | an evaluator that re-triggers retrieval on a transport error, spending `maxIterations` |

## Checklist

Classes of service defined with the owner, each with target, window and
degraded behaviour; availability schedule with planned downtime; platform
estimate over declared SLAs, provider counted once per common-mode group;
functional failure modes listed with detection for every model and tool
stage; SPOFs identified and each removed or accepted; cascades bounded;
retries bounded and budgeted; time to repair and DR (RTO / RPO) stated;
degraded modes tested, not just drawn.

## Output contract

In `ad/perspectives.sysml` (or `ad/availability.sysml`):

1. `satisfy AseMethodology::AvailabilityAndResiliencePerspective by <Design>;`
2. availability requirement defs per class of service, with the owner's words
3. platform availability `calc def`s with results as `@Finding`, SLAs as `@Assumption`
4. `@Finding` per check result, plus explicit findings for the exit stage
   and common-mode groups
5. `@Tactic` + `@ArchitectureDecision` per change with before/after numbers
6. `OperatingMode` `state def` (Operational view) and a `verification def`
   per degraded mode (fault injection)

Validate: gate; `check_ad.py` with
`// ad-check: perspectives=AvailabilityAndResilience`; `ase_gap`; the sweep.
Worked RS-04 example: `references/example.sysml`.
