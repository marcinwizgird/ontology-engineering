# Classifying tables before mapping

Keet 7.1.2. A table is a storage artefact, not an ontological commitment.
Mapping every table to a class produces flat bloat and loses the relationships
the schema encodes. Classify first.

## Decision tree

```
For each table T:

  Does a curator note say T's rows denote KINDS of the entity that
  references it?
      yes -> CLASSIFIER VOCABULARY   (rows become subclasses)
      no  -> continue

  Is T's primary key composite, with every PK column covered by a
  foreign key, and does T have exactly two foreign keys?
      no  -> ENTITY TABLE
      yes -> Does T have any columns outside the primary key?
                 no  -> RELATIONSHIP TABLE   (becomes an object property)
                 yes -> ASSOCIATION CLASS    (becomes a class, two roles)
```

## Relationship table

```sql
CREATE TABLE enrollment (
  student_id integer NOT NULL,
  course_id  integer NOT NULL,
  PRIMARY KEY (student_id, course_id),
  FOREIGN KEY (student_id) REFERENCES student (student_id),
  FOREIGN KEY (course_id)  REFERENCES course (course_id)
);
```

Three axioms, and nothing else:

```
Declaration(ObjectProperty(:enrollment))
ObjectPropertyDomain(:enrollment :Student)
ObjectPropertyRange(:enrollment :Course)
```

Domain comes from the **first** foreign key, range from the second. There is
no `:Enrollment` class, no `:studentId` data property, and no cardinality
restriction: many-to-many is the absence of one.

## Association class

Same shape, but with `grade varchar` added. Now the relationship has
properties of its own and must become a class:

```
Declaration(Class(:Enrollment))
Declaration(ObjectProperty(:hasStudent))
ObjectPropertyDomain(:hasStudent :Enrollment)
ObjectPropertyRange(:hasStudent :Student)
FunctionalObjectProperty(:hasStudent)
SubClassOf(:Enrollment ObjectExactCardinality(1 :hasStudent :Student))
... same for :hasCourse ...
Declaration(DataProperty(:grade))
DataPropertyDomain(:grade :Enrollment)
DataPropertyRange(:grade xsd:string)
FunctionalDataProperty(:grade)
```

No `HasKey`: the primary key is made of foreign keys, so there is nothing to
key on.

## Classifier vocabulary versus entity lookup

This is the class/individual impedance mismatch, and it is a judgement the
schema alone cannot settle. Both look like a small two-column lookup table.

`job_title(job_title_id, title)` holding *Manager, Engineer, Analyst*: these
name **kinds of employee**. They belong in the TBox as subclasses:

```
Declaration(Class(:Manager))
SubClassOf(:Manager :Employee)
Declaration(Class(:Engineer))
SubClassOf(:Engineer :Employee)
Declaration(Class(:Analyst))
SubClassOf(:Analyst :Employee)
DisjointClasses(:Analyst :Engineer :Manager)
```

No `:JobTitle` class, and no object property for `employee.job_title_id` -
the foreign key has been absorbed into the subclass hierarchy.

`department(department_id, department_name)` holding *humanResources, sales*:
these name **particular departments**. They belong in the ABox:

```
Declaration(Class(:Department))
Declaration(NamedIndividual(:sales))
ClassAssertion(:Department :sales)
```

and `employee.department_id` becomes an ordinary object property.

The signal is whether an instance of the referencing entity *is a* member of
the value (kind) or *is related to* it (individual). An employee **is a**
Manager. An employee **works in** Sales.

## Denormalisation

Repeating column groups (`phone1`, `phone2`, `phone3`; `address_line1`,
`address_line2`) are physical-layer artefacts. Normalise them back to a single
multi-valued data property before mapping, and do not mark it functional. A
1:1 conversion here produces three unrelated properties and loses the fact
that they are one attribute.
