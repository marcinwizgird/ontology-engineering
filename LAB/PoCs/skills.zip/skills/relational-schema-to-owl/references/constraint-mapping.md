# Relational constraints to OWL axioms

Keet 7.1.2. The constraints are where the ontological content of a schema
actually lives: NULL-ability carries existence, UNIQUE carries identity.

## Constraint table

| Relational constraint | OWL axioms |
|---|---|
| column `c` on table `T`, any | `Declaration(DataProperty(:c))`, `DataPropertyDomain(:c :T)`, `DataPropertyRange(:c xsd:...)`, `FunctionalDataProperty(:c)` |
| column `c` is `NOT NULL` | additionally `SubClassOf(:T DataSomeValuesFrom(:c xsd:...))` |
| column `c` is nullable | nothing additional - absence of an existential *is* the optionality |
| `PRIMARY KEY (c1, c2)` over non-FK columns | `HasKey(:T (:c1 :c2))` |
| `UNIQUE (c)` over non-FK columns | `HasKey(:T (:c))` |
| foreign key columns | never become data properties |
| FK `T.f -> B`, any | `Declaration(ObjectProperty(:p))`, `ObjectPropertyDomain(:p :T)`, `ObjectPropertyRange(:p :B)`, `FunctionalObjectProperty(:p)` |
| FK columns all `NOT NULL` | `SubClassOf(:T ObjectExactCardinality(1 :p :B))` |
| FK columns nullable | `SubClassOf(:T ObjectMaxCardinality(1 :p :B))` |
| FK columns also `UNIQUE` or the PK | additionally `InverseFunctionalObjectProperty(:p)` |
| repeating column group | one data property named for the base, **no** `FunctionalDataProperty` |

Every foreign key is functional: a row holds one value for its FK columns, so
it points at one target. What varies is whether it must point at one
(`NOT NULL`, exactly 1) or may point at none (nullable, at most 1). Emit
exactly one of those two cardinality axioms, never both.

## Worked example

```sql
CREATE TABLE person (
  person_id   integer NOT NULL,
  full_name   varchar NOT NULL,
  phone1      varchar,
  phone2      varchar,
  manager_id  integer,
  passport_id integer NOT NULL,
  PRIMARY KEY (person_id),
  UNIQUE (passport_id),
  FOREIGN KEY (manager_id)  REFERENCES person (person_id),
  FOREIGN KEY (passport_id) REFERENCES passport (passport_id)
);
```

```
Declaration(Class(:Person))

Declaration(DataProperty(:personId))
DataPropertyDomain(:personId :Person)
DataPropertyRange(:personId xsd:integer)
FunctionalDataProperty(:personId)
SubClassOf(:Person DataSomeValuesFrom(:personId xsd:integer))

Declaration(DataProperty(:fullName))
DataPropertyDomain(:fullName :Person)
DataPropertyRange(:fullName xsd:string)
FunctionalDataProperty(:fullName)
SubClassOf(:Person DataSomeValuesFrom(:fullName xsd:string))

Declaration(DataProperty(:phone))
DataPropertyDomain(:phone :Person)
DataPropertyRange(:phone xsd:string)

HasKey(:Person (:personId))

Declaration(ObjectProperty(:hasManager))
ObjectPropertyDomain(:hasManager :Person)
ObjectPropertyRange(:hasManager :Person)
FunctionalObjectProperty(:hasManager)
SubClassOf(:Person ObjectMaxCardinality(1 :hasManager :Person))

Declaration(ObjectProperty(:hasPassport))
ObjectPropertyDomain(:hasPassport :Person)
ObjectPropertyRange(:hasPassport :Passport)
FunctionalObjectProperty(:hasPassport)
SubClassOf(:Person ObjectExactCardinality(1 :hasPassport :Passport))
InverseFunctionalObjectProperty(:hasPassport)
```

Note in particular:

- `phone1`/`phone2` collapsed to one `:phone`, with **no**
  `FunctionalDataProperty` and no `SubClassOf ... DataSomeValuesFrom` (the
  columns are nullable);
- `manager_id` is nullable, so at most 1, and it is self-referencing - domain
  and range are both `:Person`;
- `passport_id` is `NOT NULL`, so exactly 1, and `UNIQUE`, so the property is
  inverse-functional: a 1:1 link;
- `UNIQUE (passport_id)` produces **no** `HasKey`, because the column is a
  foreign key. Keys are built from data properties.
