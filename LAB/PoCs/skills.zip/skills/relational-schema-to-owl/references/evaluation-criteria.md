# Evaluation criteria for relational-schema-to-owl

Published with the skill so a consumer can see what it is certified against.
Each criterion is executable: see ontoagents/criteria.py.

| id | criterion | weight | rule |
|---|---|---|---|
| `PDM-1` | Relationship tables are properties | 2.0 | A table whose composite primary key is entirely foreign keys and which has no attributes of its own is a relationship, not an entity: map it to an object property. |
| `PDM-2` | Foreign key cardinality | 2.0 | A NOT NULL foreign key gives exactly 1; a nullable one gives at most 1. |
| `PDM-3` | Unique foreign keys are 1:1 | 1.0 | A UNIQUE constraint over a foreign key makes the property inverse-functional. |
| `PDM-4` | Primary keys become keys | 1.0 | A primary key over non-foreign-key columns becomes HasKey. |
| `PDM-5` | Class versus individual | 2.0 | Rows of a controlled vocabulary that denote KINDS of the referencing entity become subclasses of it, not individuals, and the vocabulary table itself does not become a class. |
| `PDM-6` | Denormalisation is repaired | 1.5 | A repeating column group collapses to one multi-valued data property rather than one property per column. |
| `PDM-7` | Output hygiene | 0.5 | Every emitted line is a well-formed OWL 2 functional-syntax axiom. |

Score = 0.6 * axiom F1 against the reference mapping + 0.4 * weighted criteria pass rate.
