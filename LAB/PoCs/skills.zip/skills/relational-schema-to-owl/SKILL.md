---
name: relational-schema-to-owl
description: >
  Reverse-engineer a relational (physical) database schema into OWL 2 axioms in
  functional syntax. Use when the source is SQL DDL, CREATE TABLE statements or
  a JSON description of tables with columns, primary keys, foreign keys and
  unique constraints, or when the request mentions relational schema, database
  reverse engineering, junction table, denormalisation or physical data model.
  Do not use for UML or EER conceptual models - that is conceptual-model-to-owl.
version: "1.0.0"
domain: ontology-engineering
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Relational schema to OWL

Implements Keet, *An Introduction to Ontology Engineering*, section 7.1.2.

A 1:1 table-to-class conversion produces flat, useless bloat. The work is in
**classifying** each table first, then applying the constraint rules.

## Output contract

Emit **OWL 2 functional-syntax axioms, one per line, and nothing else**. No
prose, no code fences, no prefix or ontology declarations.

Naming, applied without exception:

- class = `:` + PascalCase of the table name (`job_title` -> `:JobTitle`)
- data property = `:` + camelCase of the column name
  (`student_number` -> `:studentNumber`)
- object property from a foreign key = `:` + camelCase of `has_` + the FK
  column name with a trailing `_id`, `_no`, `_code`, `_key` or `_fk` removed
  (`department_id` -> `:hasDepartment`, `manager_id` -> `:hasManager`)
- object property from a relationship table = `:` + camelCase of the table name
  (`enrollment` -> `:enrollment`)

Datatypes: `varchar|char|text` -> `xsd:string`; `integer|int|bigint|smallint|
serial` -> `xsd:integer`; `decimal|numeric` -> `xsd:decimal`; `float|double|
real` -> `xsd:double`; `boolean|bool` -> `xsd:boolean`; `date` -> `xsd:date`;
`timestamp|datetime` -> `xsd:dateTime`; `time` -> `xsd:time`.

## Step 1 - classify every table

Decide before emitting anything. Load `references/table-classification.md` for
the decision tree.

| Kind | Test | Becomes |
|---|---|---|
| **Relationship table** | composite PK, every PK column is part of a foreign key, exactly two foreign keys, **no** other columns | an **object property** |
| **Association class** | as above **but** it has columns of its own | a **class** with two exactly-one roles |
| **Classifier vocabulary** | curator note says its rows denote *kinds* of the referencing entity | **subclasses** of the referencing class |
| **Entity table** | anything else | a **class** |

## Step 2 - relationship tables

For a relationship table `t` whose two foreign keys point at `A` then `B`:

```
Declaration(ObjectProperty(:t))
ObjectPropertyDomain(:t :A)
ObjectPropertyRange(:t :B)
```

Emit **no** `Declaration(Class(:T))` for it and no data properties for its
key columns. A many-to-many relationship carries no cardinality restriction.

## Step 3 - classifier vocabularies

The class-versus-individual mismatch. When a lookup table's rows name *kinds*
of the entity that references it, each value becomes a **subclass of the
referencing class**:

```
Declaration(Class(:Manager))
SubClassOf(:Manager :Employee)
...
DisjointClasses(:Manager :Engineer :Analyst)     # when two or more values
```

Emit **no** class for the vocabulary table itself, **no** object property for
the foreign keys that point at it, and **no** `ClassAssertion` - these are
kinds, not individuals.

By contrast, a lookup table whose rows name *particular things* is an ordinary
entity table, and its rows become individuals:

```
Declaration(NamedIndividual(:sales))
ClassAssertion(:Department :sales)
```

## Step 4 - entity tables

```
Declaration(Class(:T))
```

**Repeating groups first.** Columns whose names differ only by a trailing
number (`phone1`, `phone2`, `phone3`) are denormalisation. Collapse them to a
single multi-valued data property named after the shared base:

```
Declaration(DataProperty(:phone))
DataPropertyDomain(:phone :T)
DataPropertyRange(:phone xsd:string)
```

Emit **no** `FunctionalDataProperty` for it - it is multi-valued - and no
property for the individual numbered columns.

**Remaining columns** that are not foreign-key columns and not part of a
repeating group:

```
Declaration(DataProperty(:c))
DataPropertyDomain(:c :T)
DataPropertyRange(:c xsd:T)
FunctionalDataProperty(:c)
SubClassOf(:T DataSomeValuesFrom(:c xsd:T))    # only when the column is NOT NULL
```

**Keys.** When the primary key contains no foreign-key column:

```
HasKey(:T (:c1 :c2 ...))
```

Do the same for each UNIQUE constraint whose columns are not foreign keys.

## Step 5 - foreign keys on entity tables

For each foreign key from `T` to `B` (skip any pointing at a classifier
vocabulary - step 3 already handled those), with property `:p` named by the
rule above:

```
Declaration(ObjectProperty(:p))
ObjectPropertyDomain(:p :T)
ObjectPropertyRange(:p :B)
FunctionalObjectProperty(:p)
SubClassOf(:T ObjectExactCardinality(1 :p :B))   # every FK column is NOT NULL
SubClassOf(:T ObjectMaxCardinality(1 :p :B))     # otherwise (nullable)
InverseFunctionalObjectProperty(:p)              # only if those columns are UNIQUE or the PK
```

Exactly one of the two cardinality axioms is emitted. A self-referencing
foreign key is no different: domain and range are the same class.

Load `references/constraint-mapping.md` for the full constraint table.

## Step 6 - association classes

For a relationship-shaped table that carries its own columns, reify it:

```
Declaration(Class(:T))
# for each of its two foreign keys, property :p to target :B
Declaration(ObjectProperty(:p))
ObjectPropertyDomain(:p :T)
ObjectPropertyRange(:p :B)
FunctionalObjectProperty(:p)
SubClassOf(:T ObjectExactCardinality(1 :p :B))
```

Then apply step 4's column rules to its own columns. Emit no `HasKey`, because
its primary key is made of foreign keys.

## Step 7 - validate

Run `scripts/check_axioms.py` with your draft axioms on stdin. Fix exactly what
it reports and re-emit the complete axiom set.
