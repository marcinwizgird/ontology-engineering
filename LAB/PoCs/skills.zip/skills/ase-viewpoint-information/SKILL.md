---
name: ase-viewpoint-information
description: >
  Build, analyse and review the Information view of an agentic system in
  SysML v2 following the Rozanski & Woods Information viewpoint - item defs
  for architecturally significant data (documents, chunks, embeddings,
  prompts, answers, citations, audit records, conversation state), data
  classes, ownership and updaters, information flow over the functional
  stages, lifecycle state machines (ingest, index, supersede, erase),
  provenance carriers, retention, information quality and volumetrics. Use
  when asked about data model, data ownership, data classification, what
  flows between agents, deletion or retention, citation fields, index size,
  or to review one. Do not use for knowledge retrieved at inference time and
  memory scope (use ase-viewpoint-knowledge) or for what crosses the system
  boundary (use ase-viewpoint-context).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Information viewpoint

Load `ase-arch-sysml-foundations` first. Control: `AseMethodology::InformationViewpoint`
- read with `ase_viewpoint("Information")` and `ase_obligations("Information")`.

## Definition

> "Describes the way that the architecture stores, manipulates, manages,
> and distributes information" - `InformationViewpoint` `@RozanskiWoods`,
> source viewpoints-and-perspectives.info/home/viewpoints.

Methodology models: "item defs, data classes, ownership, provenance
carriers". Work at architectural level only: data whose mistake would
affect the whole system (a wrong `dataClass` on chunks, a missing
`sourceId`, an unowned conversation store), not every field.

**Stakeholders**: primarily users, acquirers, developers, testers and
maintainers; for agentic systems also the compliance officer (retention,
erasure) and security architect (classification). **Applicability**: any
system with more than trivial information management - every RAG or agent
system qualifies, because the corpus and its derivatives *are* information
management.

**Concerns**: ASE frames `InformationFlow` ("What data crosses which
boundary, and who owns it?") and `AnswerGroundedness` ("Can every assertion
the system makes be traced to a source?"). R&W's concerns, as design
concerns specialising those two: information structure and content;
purpose and usage; ownership; enterprise-owned information; identifiers and
mappings; volatility of semantics; storage models; information flow;
consistency; quality; timeliness, latency and age; archiving and retention.

**Models** (R&W): static structure, information flow, lifecycle,
ownership, quality analysis, metadata, volumetric. ASE requires the first
four and asks for quality and volumetrics whenever a perspective needs them.

## R&W model elements -> SysML v2

| R&W model | SysML v2 | ASE convention |
|---|---|---|
| Static structure | `item def` with attributes; `[1..*]` multiplicity for references | only significant items; derived items (chunk, embedding, summary) are items too |
| Classification | `attribute dataClass : String = "..."` on the item | values `public`, `internal`, `restricted`, `pii`, `regulated`, `secret`; mirror onto the emitting stage's `dataClass` in `design.sysml` |
| Ownership | `attribute owner`, `attribute updaters` on the item | one updater is the goal; a comma in `updaters` is a decision |
| Information flow | `action def` with `in`/`out item` per stage role, composed with `flow a.x to b.y` | every design `flow a to b` carries a named item |
| Lifecycle | `state def` with `accept <Event> then <state>` | ingest, index, supersede, erase; erasure reaches derived items |
| Provenance / metadata | `sourceId` on chunk-like items; a `*Citation` item | `citation_carriers` reads item *names* (chunk / citation) |
| Retention | `attribute retentionDays : Integer` | 0 = until owner deletes; state who triggers deletion |
| Quality | `requirement def` with a measurable target + `verification def` | extraction fidelity, freshness, dedup |
| Volumetrics | `calc def` + `@Assumption` with the numbers | corpus size, chunks, growth, per-tenant partitions |

Agentic information that is routinely missed: **prompts** (assembled from
user text + retrieved content: highest class of their parts), **embeddings**
(derived, same class and owner as their source), **LLM-generated
intermediates** (rewritten queries, hypothetical documents, summaries -
no source of their own), **traces and eval sets** (copies of production
data), **conversation state**, **tool results**.

## Activities -> SysML

1. **Identify significant items.** From the functional ports and the
   Context view's boundary items. For each: purpose, who creates it, who
   reads it. `doc` says why it is architecturally significant.
2. **Classify.** `dataClass` on every item. Derived items inherit the
   highest class of their inputs unless a declassifying stage (anonymiser,
   aggregator) is named and decided. Then mirror onto `design.sysml`: the
   stage that emits an item declares its class - that is the only place
   `data_exposure` reads.
3. **Assign ownership.** `owner` (accountable party) and `updaters`
   (elements that write). Multiple updaters -> a decision on consistency;
   enterprise-owned data the system only reads is a Knowledge-view source,
   not something to own here.
4. **Model the flow.** One `action def` per stage role with its items;
   compose per A2 scenario:
   ```
   action def AnswerInformationFlow {
       action retrieve : RetrieveClauses;
       action synthesise : SynthesiseAnswer;
       flow retrieve.chunks to synthesise.chunks;
   }
   ```
5. **Place provenance carriers.** A chunk-like item with `sourceId`, and a
   citation item the answer carries (`citations : ClauseCitation[1..*]`).
   Declare both in `design.sysml` - `citation_carriers` runs on the design
   only. Mark stages that emit content without a source
   (`preservesProvenance = false`: HyDE, free-form rewriters).
6. **Model lifecycles.** A `state def` for each item with a non-trivial
   life: corpus documents, conversation state, audit records. Every
   `erased` state must be reachable, and erasure must cover derived items
   (chunks, embeddings, cache entries, traces).
7. **Set retention.** `retentionDays` per item, from regulation or A1; the
   trigger (owner, time, event) in `doc`.
8. **Quantify.** Volumetrics as `calc def` + assumptions (index size drives
   Deployment and Performance); quality targets as requirements with
   verification against the eval set.

## The view

```
view def InformationView {
    satisfy requirement vp : AseMethodology::InformationViewpoint;
    filter @SysML::ItemUsage or @SysML::ActionUsage or @SysML::StateUsage or @SysML::AttributeUsage;
}
view information : InformationView {
    expose RS07_Information::**;
    render asTreeDiagram;
}
view ownershipTable : InformationView {
    expose RS07_Information::*;
    render asElementTable;     // item, owner, updaters, dataClass, retention
}
```

The filter admits items, flows over actions, and lifecycle states - no
part usages (that is Functional) and no nodes (Deployment).

## Analysis the information model supports

| Question | Engine |
|---|---|
| Does a source identifier reach the output | `citation_carriers` - ABSENCE, item def *name* contains chunk or citation |
| Does provenance survive every path | `provenance_paths` - reads stage `preservesProvenance` (default `true`) |
| Which LLM stages generate with nothing upstream | `unsourced_stages` - only fires on an LLM stage with no inbound flow |
| Can restricted data reach an external sink | `data_exposure` - reads *stage* `dataClass`, not item `dataClass` |
| Is every stage classified | `trust_declared` covers trust only; `dataClass` completeness: `ase_gap` / review |
| Index size, growth, per-partition size | `calc def ChunkVolume` (evaluate by hand or in the delegate; record as `@Finding`) |
| Is erasure complete | none - review: every derived item has a path to `erased` |
| Multiple updaters | none - review `updaters` |

Closed-world traps: `provenance_paths` passes on any design that never
declares `preservesProvenance = false` - clean means "no stage declared as
breaking provenance". `citation_carriers` passes on an item called
`ChunkList` with no `sourceId`; verify the attribute by reading the item.
`data_exposure` never sees item classes: an item classified `pii` flowing
from a stage left at the default class is invisible until the stage mirrors it.

## Reasoning over the information model

- *Where does item X go?* follow `flow` over the actions, then the design
  flows between the stages that perform them.
- *What must be erased when a user or tenant leaves?* every item with that
  owner, plus every item derived from them (chunks, embeddings, traces,
  eval copies) - the lifecycle must reach `erased` for each.
- *What if a new data class enters (e.g. PII in tickets)?* re-derive the
  class of every downstream item; each stage whose class rises is a
  Security what-if (`data_exposure` re-run).
- *What if the corpus grows 10x?* re-evaluate the volumetric calc; index
  size moves Deployment and retrieval `latencyMs` (Performance).
- Correspondences (`@Correspondence`): every item on a functional port is
  defined here with class and owner (Functional); every boundary item from
  Context appears here; every item read at inference time from a source the
  system does not own is described in Knowledge; every restricted item's
  stage is covered by Security; retention states match Operational runbooks.

## Pitfalls -> detection

| Pitfall | Detection |
|---|---|
| Representation incompatibilities | two item defs for the same entity with different identifiers (e.g. `docId` vs `sourceId`) |
| Unavoidable multiple updaters | `updaters` with more than one element and no decision |
| Key-matching deficiencies | chunk `sourceId` that cannot be resolved to a document/section; no identifier mapping between sources |
| Interface complexity | an item carrying another item's full content (prompt copies of whole documents) |
| Overloaded central database | one store for corpus, memory, audit and cache with no ownership split |
| Inconsistent distributed databases | vector index and graph built by different pipelines with no shared version |
| Poor information quality | no quality requirement on extraction / chunking; no verification |
| Excessive information latency | corpus refresh slower than the business change rate (Knowledge view) |
| Inadequate volumetrics | no `calc def` or assumption for corpus size and growth |
| (agentic) derived data under-classified | embedding or summary with a lower `dataClass` than its source |
| (agentic) item class not mirrored on stage | item `pii`, emitting stage default class - `data_exposure` blind |
| (agentic) no provenance carrier | no item named *chunk* / *citation* in the design (`citation_carriers`) |
| (agentic) erasure stops at the source | lifecycle erases the document but not chunks, embeddings or traces |

## Checklist

Significant items identified, each with purpose and `doc`; every item
classified and derived items inherit; stage classes mirrored in the design;
owner and updaters stated, multiple updaters decided; information flow per
key scenario; lifecycle for corpus, memory and audit with reachable
erasure; retention with trigger; provenance carriers declared in the design;
quality targets verifiable; volumetrics computed with assumptions;
correspondences to Functional, Context, Knowledge and Security stated.

## Output contract

`ad/information.sysml` containing: item defs with `dataClass`, `owner`,
`updaters`, `retentionDays`; flow `action def`s per scenario; lifecycle
`state def`s; volumetric `calc def` + `@Assumption`s; quality requirements
with `satisfy` and `verification def`; the `InformationView` def and view
usages; `@Correspondence`s; decisions on classification, ownership and
erasure. Updates to `design.sysml`: stage `dataClass`,
`preservesProvenance = false` where it holds, and the chunk / citation
item defs.

Validate (from `AI Skills/skills`):
```
python description-to-sysmlv2/scripts/check_model.py < ad/information.sysml
python ase-arch-sysml-foundations/scripts/check_ad.py < ad/information.sysml   # directive: fragment viewpoints=Information
python -m sysmlagents.cli explain <RS-xx>     # citation_carriers, provenance_paths, data_exposure
```
Worked example (RS-07): `references/example.sysml`.
