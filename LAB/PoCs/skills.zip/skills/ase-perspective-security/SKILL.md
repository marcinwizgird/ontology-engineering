---
name: ase-perspective-security
description: >
  Apply the Rozanski & Woods Security perspective to an agentic system's SysML
  v2 architecture - identify sensitive resources and principals, write the
  security policy, build an agentic threat model (prompt injection through
  retrieved content and tool output, exfiltration through external sinks,
  cross-tenant leakage, excessive tool authority, secrets in prompts), assign
  trust levels and data classes the ASE checks can read, apply detect / resist
  / react / recover tactics, and record findings, risks and decisions. Use for
  trust boundaries, data exposure, tool authorisation, sandboxing, tenancy
  isolation, prompt injection or "can this leak" questions about an ASE
  design. Do not use for failure handling and outages (use
  ase-perspective-availability-resilience), data residency across regions
  (use ase-perspective-location) or legal evidence packs (use
  ase-perspective-regulation).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Security perspective

Load `ase-arch-sysml-foundations` first. Control (read-only):
`AseMethodology::SecurityPerspective` - read with `ase_perspective("Security")`;
concerns with `ase_concern("PrivilegeBoundaries")` and `ase_concern("DataExposure")`.

## Definition

> "The ability of the system to reliably control, monitor, and audit who can
> perform what actions on what resources and to detect and recover from
> failures in security mechanisms" - `AseMethodology::SecurityPerspective`,
> source viewpoints-and-perspectives.info/home/perspectives.

**Applicability.** R&W: systems with publicly reachable interfaces, several
users whose identity matters, or controlled operations and information. For
agentic systems treat it as always applicable: every stage that reads
retrieved text, tool output or user input is an injection surface, and every
tool call is an action on a resource.

**Concerns.** ASE frames two: `PrivilegeBoundaries` (which component may
invoke which capability, under what trust) and `DataExposure` (can a
restricted data class reach an uncontrolled sink). R&W's list - resources,
principals, policies, threats, confidentiality, integrity, availability,
accountability, detection and recovery, security mechanisms - is the
elicitation checklist behind them; specialise the two ASE concerns
(`concern def TenantIsolation :> AseMethodology::DataExposure`) so
`concern_coverage` sees yours as framed. **Stakeholders**: `SecurityArchitect`,
`ComplianceOfficer`; add data owners, tenant DPOs and the operator who holds
the keys.

## How ASE reads security (know this before modelling)

The five checks bound in `@Perspective.checks` read three things. Verified in
`sysmlagents/checks.py`:

| Input | Read by | What ASE assumes |
|---|---|---|
| `trustLevel : Integer` on a stage | `trust_escalation`, `tool_authorisation`, `sandbox_consistency`, `trust_declared` | ordinal *authority*: 0 = sandboxed (may not act outside), higher = may act on more. Flows must not go from lower to higher. Undeclared counts as 0 in `trust_escalation`, is skipped by `tool_authorisation` |
| `dataClass : String` on a stage | `data_exposure` | `restricted`, `pii`, `regulated`, `secret` (case-insensitive) are restricted; any other value is not |
| stage *type name* in `EXTERNAL_KINDS = {WebSearchFallback}` | `data_exposure`, `tool_authorisation`, `sandbox_consistency`, `high_risk_classification` | the **only** stage ASE treats as leaving the boundary. Matched on the usage's type name, so `HostedModelCall :> WebSearchFallback` is *not* external |

Three consequences to state in every report:

1. **External sinks are under-declared.** A hosted model endpoint, an MCP or
   HTTP tool, an email sender, a rendered markdown link - none is external to
   the checks. On a design without a `WebSearchFallback`, `data_exposure` and
   `tool_authorisation` pass *vacuously*. Report that as a gap, never as a
   pass; the roadmap item is an `external` stage attribute replacing the
   type list.
2. **No declassification.** `data_exposure` is plain reachability: a
   redactor or anonymiser on the path does not clear it (RS-04's
   `QueryAnonymiser` still fires). Accept the finding with a decision that
   names the sanitiser and the `verification def` that proves it
   (`pii_leak_rate = 0`).
3. **Trust must be non-increasing along flows.** That is the prompt-injection
   rule in graph form: content produced by a less-trusted stage must not
   drive a more-trusted one. A retrieval stage feeding a tool-calling agent
   at higher trust fires `trust_escalation` - which is correct.

`trustLevel` and `dataClass` are in the agreed vocabulary but not on the
library `Stage`; add them to the design's copy of `Stage` (no `@Extension`
needed). Tenancy, role and principal attributes are not in the vocabulary -
they are `@Extension`s (RS-07 oracle).

## Activities -> SysML

R&W loop: identify sensitive resources -> define the policy -> identify
threats -> design the implementation -> assess the risks -> repeat until the
residual risk is acceptable.

### 1. Identify sensitive resources

Resources are items and stores, and for agents also *capabilities*: a tool
is a resource whose misuse is an action. Put the class on the stage that
holds or emits the data and on the item in the Information view:

```
part def GraphRetriever :> Stage {
    attribute redefines trustLevel = 2;
    attribute redefines dataClass = "restricted";   // tenant contract text
}
```

List per resource: owner, class, where it is stored, which stages touch it.
Include the agent-specific ones: system prompts, few-shot examples, memory,
tool credentials, eval sets, traces (they contain everything).

### 2. Define the security policy

Principals x resources x operations, stated as requirement defs with the
spec sentence in `doc`. Every policy requirement is satisfied by the element
that enforces it:

```
requirement def TenantBoundStoreSelection {
    doc /* RS-07 QR-2, C-1: store handles resolved from the session tenantId
         before the pipeline starts; question text never selects a store. */
}
satisfy TenantBoundStoreSelection by RS07::RS07Design::session;
```

Keep it simple (a complex policy is pitfall 1). Role rules that must be
mechanical - "paralegals never see verbatim clauses" - are policy, not a
prompt instruction; say so in the requirement.

### 3. Identify threats (threat model)

One `@Risk` per credible threat, attached to the decision that mitigates or
accepts it. Agentic threats to walk every time:

| Threat | Where in the model | Check that can see it |
|---|---|---|
| Direct prompt injection (user input) | entry stage -> privileged stage | `trust_escalation` if the entry is modelled as a stage |
| Indirect injection via retrieved documents, web pages, tool output | retriever / tool stage -> LLM stage with tools | `trust_escalation` |
| Exfiltration via a tool, search query, URL or rendered link | restricted stage -> sink | `data_exposure` (only if the sink is `WebSearchFallback`) |
| Excessive agency: low-trust stage calls a tool | caller -> external stage | `tool_authorisation` |
| Sandboxed stage declared as acting outside | trust 0 external stage | `sandbox_consistency` |
| Cross-tenant leakage, shared model endpoint carrying another tenant's text | selector inputs; shared deployment | `trust_escalation` + `@Extension` tenancy attributes; review |
| Secrets in prompts or traces, memory poisoning, model / tool supply chain | Development, Operational views | none - review |

### 4. Design the security implementation

Assign `trustLevel` top-down from the policy: the stage that binds identity
and selects resources highest; stages reading untrusted content lowest;
only the top tier may call an external stage. Apply tactics (below). Record
each as `@Tactic` + `@ArchitectureDecision`.

### 5. Assess the risks

Run the sweep and carry each result into `ad/perspectives.sysml` as
`@Finding`. For every clean verdict name the attributes and flows it rests
on (closed world). Walk the threat list: mitigated / accepted (owner-signed)
/ open. Loop to 2 while a high `@Risk` has neither.

## Applying the perspective to each view

| View | What the perspective adds in SysML |
|---|---|
| Context | principals as actors; external systems and tools as externals; trust boundary drawn at the system edge |
| Functional | `trustLevel` per stage; policy requirement defs satisfied by enforcing elements; guard stages (input filter, output filter, role gate) |
| Information | `dataClass` on items and stages; ownership; retention of traces and memory |
| Knowledge | provenance of retrieved text - what may carry injected instructions; per-tenant indices |
| Concurrency | isolation of privileged work: tool execution in its own process or sandbox |
| Autonomy | which tool calls need approval; authority level per agent (`trustLevel` is the proxy) |
| Deployment | network zones, secrets store, model endpoint (shared vs dedicated), region |
| Operational | audit log, key rotation, incident runbook, injection monitoring |
| Development | secure prompt and tool-schema guidelines; no secrets in prompt files |

## Analysis the perspective supports

| Question | Engine | Kind |
|---|---|---|
| Can lower-trust content drive a higher-trust stage? | `trust_escalation` | REACHABILITY |
| Can restricted data reach an external sink? | `data_exposure` | REACHABILITY |
| Is every external capability called from the top trust tier? | `tool_authorisation` | REACHABILITY |
| Is a sandboxed stage declared as external? | `sandbox_consistency` | CLASSIFICATION |
| Does every stage declare trust? | `trust_declared` | ABSENCE |
| Is the design high-risk by definition (loop + external + ungrounded)? | `high_risk_classification` (Regulation) | CLASSIFICATION |
| What-if: question text reaches the store selector | scratch variant + sweep | - |

Run `python -m sysmlagents.cli explain <RS-xx>` or `registry.run` on the
projected design. `trust_declared` fires on every library pattern: the
library declares no trust. That is a gap to close, not noise to accept.

## Tactics -> SysML change -> expected effect

| Tactic (R&W principle / SEI category) | Agentic form | SysML change | Check that moves |
|---|---|---|---|
| Least privilege (R&W); authorise actors (SEI resist) | tool calls only from a planner that never reads raw retrieved text | lower `trustLevel` of content readers; only top tier flows to external stages | `tool_authorisation`, `trust_escalation` |
| Separate entities / compartmentalise (SEI resist) | dual-LLM / quarantined reader; per-tenant stores | split one agent into reader (low) and actor (high) stage defs; tenancy `@Extension` | `trust_escalation` |
| Validate input (SEI resist) | injection filter on retrieved text and tool output | guard stage before the LLM stage | review; eval `injection_success_rate` |
| Limit exposure (SEI resist); assume externals untrusted (R&W) | anonymise queries leaving the boundary; allow-listed domains | sanitiser stage on the edge to the sink | `data_exposure` still fires - accept with decision + verification |
| Secure defaults; fail securely (R&W) | on guard failure abstain, never answer unguarded | guard stage has no bypass flow | `articulation_points` (the guard is one - intended) |
| Identify / authenticate actors (SEI) | identity bound from the session, never from the prompt | session-binder stage at top trust, not reachable from question text | `trust_escalation` |
| Encrypt data (SEI) | TLS to model API; encrypted vector store | Deployment attributes | review |
| Detect intrusion / anomalies (SEI detect) | canary strings, tool-call rate anomaly, output PII scan | Operational telemetry stage | review |
| Revoke access, inform actors (SEI react) | kill switch per tool; key revocation | Operational `state def` with a `restricted` mode | review |
| Audit, non-repudiation (SEI recover; R&W accountability) | append-only log of every retrieval and tool call | audit stage on the retrieval edges | `articulation_points` (fail-closed audit is a tradeoff) |
| Secure the weakest link; defence in depth (R&W) | tenancy enforced at store, retriever and prompt | three enforcing elements, three `satisfy` lines | `requirement_traceability` |

## Pitfalls -> detection in the model

| Pitfall (R&W + agentic) | Detection |
|---|---|
| Complex security policies | more policy requirement defs than principals x resources warrants; rules only in prompt text |
| Security as an afterthought / no clear requirements | no `trustLevel` (`trust_declared`); no policy requirement defs |
| Not designed for failure | guard stage with a bypass flow; no fail-closed decision |
| Lack of administration facilities | no Operational key/permission procedures |
| Technology-driven approach; unproven technology | a "guardrail" product named with no threat it mitigates |
| Ignoring the insider threat | operators and tenants' own users absent from principals |
| Assuming the client is secure | role enforced in the UI only |
| Security embedded in application code / piecemeal | role gate as an LLM instruction (RS-07 fails this) |
| Failure to consider time sources | audit without a trusted timestamp |
| (agentic) retrieved text trusted as instructions | retriever feeds a higher-trust stage: `trust_escalation` |
| (agentic) invisible sink | model API / MCP tool not typed external: `data_exposure` vacuous |
| (agentic) clean verdict on undeclared inputs | "no exposure" with no `dataClass` declared - a gap (`ase_gap`) |

## Checklist

Clear policy of principals x operations x resources, as simple as possible;
every sensitive resource classed; threat model covers injection (direct and
indirect), exfiltration, excessive agency, tenancy, secrets, supply chain;
every threat mitigated to the needed extent or accepted by its owner; trust
non-increasing along flows; only the top tier calls external capabilities;
every external sink modelled - or its invisibility recorded; mechanisms for
detection and recovery named; audit covers every retrieval and tool call;
reviewed with an external security expert where the risk warrants.

## Output contract

In `ad/perspectives.sysml` (or `ad/security.sysml`):

1. `satisfy AseMethodology::SecurityPerspective by <Design>;`
2. `trustLevel`, `dataClass` on every stage def in `design.sysml`; tenancy /
   role attributes as `@Extension` with reason and roadmap item
3. policy requirement defs, each satisfied by its enforcing element
4. one `@Risk` per threat; `@Finding` per check result with disposition -
   vacuous passes recorded as `defer` with the decision naming the gap
5. `@Tactic` + `@ArchitectureDecision` per mitigation
6. `verification def` per zero-tolerance requirement (leak rate, role gate)

Validate: gate; `check_ad.py` with `// ad-check: perspectives=Security`;
`ase_gap`; the sweep. `vocabulary_conformance` warns on each tenancy
extension - intended; accept with the decision naming the roadmap item.
Worked RS-07 example: `references/example.sysml`.
