#!/usr/bin/env python3
"""Tier-3 validator: structural checks on a draft axiom set.

Reads OWL 2 functional-syntax axioms on stdin, prints a short report on
stdout. Self-contained by design - a skill package must not import the host
application. The script body never enters the agent's context; only this
report does.

Exit code 0 when clean, 1 when issues were found.
"""

import re
import sys

HEADS = {
    "Declaration", "SubClassOf", "EquivalentClasses", "DisjointClasses",
    "ObjectPropertyDomain", "ObjectPropertyRange", "DataPropertyDomain",
    "DataPropertyRange", "FunctionalObjectProperty",
    "InverseFunctionalObjectProperty", "FunctionalDataProperty",
    "TransitiveObjectProperty", "SymmetricObjectProperty",
    "AsymmetricObjectProperty", "IrreflexiveObjectProperty",
    "InverseObjectProperties", "SubObjectPropertyOf", "SubDataPropertyOf",
    "HasKey", "ClassAssertion", "ObjectPropertyAssertion",
    "DataPropertyAssertion", "DifferentIndividuals", "SameIndividual",
}

CARDINALITY = re.compile(
    r"Object(?:Exact|Min|Max)Cardinality\(\s*(\S+)\s+([^)]+?)\s*\)"
)
NAME = re.compile(r"(?<![\w:])(:[A-Za-z_][\w-]*)")
DECL = re.compile(
    r"Declaration\(\s*(Class|ObjectProperty|DataProperty|NamedIndividual|"
    r"AnnotationProperty|Datatype)\(\s*(:[\w-]+)\s*\)\s*\)"
)


def main() -> int:
    text = sys.stdin.read()
    text = re.sub(r"```[a-zA-Z]*", "", text)

    issues = []
    axioms = []
    declared = set()

    # join wrapped axioms by balancing parentheses
    buf, depth = "", 0
    for raw in text.splitlines():
        line = raw.split("#")[0].strip()
        if not line:
            continue
        buf = (buf + " " + line).strip() if buf else line
        depth += line.count("(") - line.count(")")
        if depth <= 0:
            axioms.append(buf)
            buf, depth = "", 0
    if buf:
        issues.append("unbalanced parentheses at end of input: %r" % buf[:70])

    kept = []
    for a in axioms:
        if a.lower().startswith(("prefix", "ontology", "@prefix", "import")):
            issues.append("remove wrapper line: %r" % a[:60])
            continue
        m = re.match(r"([A-Za-z]+)\s*\(", a)
        if not m:
            issues.append("not an axiom: %r" % a[:60])
            continue
        if m.group(1) not in HEADS:
            issues.append("unknown axiom type %r in %r" % (m.group(1), a[:60]))
            continue
        if a.count("(") != a.count(")"):
            issues.append("unbalanced parentheses: %r" % a[:60])
            continue
        kept.append(a)
        d = DECL.match(a)
        if d:
            declared.add(d.group(2))

    for a in kept:
        for card in CARDINALITY.finditer(a):
            if not card.group(1).isdigit():
                issues.append(
                    "cardinality needs a number first: %r" % card.group(0)[:60]
                )

    used = set()
    for a in kept:
        if DECL.match(a):
            continue
        used.update(NAME.findall(a))
    undeclared = sorted(n for n in used - declared if not n.startswith(":xsd"))
    for n in undeclared[:15]:
        issues.append("%s is used but never declared" % n)
    if len(undeclared) > 15:
        issues.append("... and %d more undeclared names" % (len(undeclared) - 15))

    if not kept:
        issues.append("no axioms found in input")

    if issues:
        print("ISSUES (%d) in %d axioms, %d declarations:"
              % (len(issues), len(kept), len(declared)))
        for i in issues:
            print("  - " + i)
        return 1

    print("OK %d axioms, %d declarations, no structural issues."
          % (len(kept), len(declared)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
