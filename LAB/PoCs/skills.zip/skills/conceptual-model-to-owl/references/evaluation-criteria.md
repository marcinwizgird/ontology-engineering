# Evaluation criteria for conceptual-model-to-owl

Published with the skill so a consumer can see what it is certified against.
Each criterion is executable: see ontoagents/criteria.py.

| id | criterion | weight | rule |
|---|---|---|---|
| `CDM-1` | Class coverage | 1.0 | Every entity type becomes an OWL class. |
| `CDM-2` | Multiplicity to restriction | 2.0 | min>=1 becomes an existential restriction; 1..1 becomes exactly 1; both directions of a binary association are constrained. |
| `CDM-3` | n-ary reification | 2.0 | OWL has only binary properties: associations of arity>2 and association classes must be reified into a class with exactly-one roles. |
| `CDM-4` | Generalisation semantics | 1.5 | subClassOf per child, plus disjointness and a covering axiom where the generalisation set declares them. |
| `CDM-5` | Attribute typing | 1.0 | Every attribute becomes a data property with a domain. |
| `CDM-6` | Output hygiene | 0.5 | Every emitted line is a well-formed OWL 2 functional-syntax axiom. |

Score = 0.6 * axiom F1 against the reference mapping + 0.4 * weighted criteria pass rate.
