# Reification of n-ary associations and association classes

Keet 7.1.1, structural mismatch. Conceptual modelling languages permit
relationships of any arity and permit a relationship to carry attributes.
**OWL 2 object properties are strictly binary and carry no attributes.** The
standard repair is to reify: promote the relationship to a class whose
instances are occurrences of the relationship.

## When to reify

Reify if either test passes:

1. the association has three or more ends;
2. the association is an association class, i.e. it has attributes.

Otherwise map it as a plain object property.

## Ternary example

`Supply(Supplier, Part, Project)` with roles `supplier`, `suppliedPart`,
`project`, each end `1..*`, and an attribute `quantity : integer` (mandatory).

```
Declaration(Class(:Supply))

Declaration(ObjectProperty(:supplier))
ObjectPropertyDomain(:supplier :Supply)
ObjectPropertyRange(:supplier :Supplier)
SubClassOf(:Supply ObjectExactCardinality(1 :supplier :Supplier))
FunctionalObjectProperty(:supplier)
SubClassOf(:Supplier ObjectSomeValuesFrom(ObjectInverseOf(:supplier) :Supply))

Declaration(ObjectProperty(:suppliedPart))
ObjectPropertyDomain(:suppliedPart :Supply)
ObjectPropertyRange(:suppliedPart :Part)
SubClassOf(:Supply ObjectExactCardinality(1 :suppliedPart :Part))
FunctionalObjectProperty(:suppliedPart)
SubClassOf(:Part ObjectSomeValuesFrom(ObjectInverseOf(:suppliedPart) :Supply))

Declaration(ObjectProperty(:project))
ObjectPropertyDomain(:project :Supply)
ObjectPropertyRange(:project :Project)
SubClassOf(:Supply ObjectExactCardinality(1 :project :Project))
FunctionalObjectProperty(:project)
SubClassOf(:Project ObjectSomeValuesFrom(ObjectInverseOf(:project) :Supply))

Declaration(DataProperty(:quantity))
DataPropertyDomain(:quantity :Supply)
DataPropertyRange(:quantity xsd:integer)
FunctionalDataProperty(:quantity)
SubClassOf(:Supply DataSomeValuesFrom(:quantity xsd:integer))
```

The shape to memorise, per participant:

- the role property runs **from the reified class to the participant**;
- the reified class relates to **exactly one** participant per role - that is
  what makes an instance of `:Supply` a single supply event;
- the participant gets an existential through `ObjectInverseOf(role)` **only
  when that end's minimum is 1 or more**. An end of `0..*` contributes no
  participation axiom.

## Association class example

`Loan` between `Member` (`0..*`) and `Copy` (`0..*`), with attributes
`loanDate` and `dueDate`, both mandatory dates.

Identical shape. Because both ends are `0..*`, no participation axioms are
emitted:

```
Declaration(Class(:Loan))
Declaration(ObjectProperty(:borrower))
ObjectPropertyDomain(:borrower :Loan)
ObjectPropertyRange(:borrower :Member)
SubClassOf(:Loan ObjectExactCardinality(1 :borrower :Member))
FunctionalObjectProperty(:borrower)
...same for the other role...
Declaration(DataProperty(:loanDate))
DataPropertyDomain(:loanDate :Loan)
DataPropertyRange(:loanDate xsd:date)
FunctionalDataProperty(:loanDate)
SubClassOf(:Loan DataSomeValuesFrom(:loanDate xsd:date))
```

## Traps

- Do **not** emit `Declaration(ObjectProperty(:Supply))`. The association name
  became a class; only the role names become properties.
- The roles, not the association name, are the properties. If the model gives
  no role names, derive them from the participating entity names, but prefer
  the roles when present.
- The reified class takes the association's attributes. Do not attach them to
  the participating entity types.
- Multiplicities at the ends of an n-ary association do **not** become
  cardinality restrictions on the reified class beyond the exactly-one role
  axioms; they only decide whether a participation existential is emitted.
