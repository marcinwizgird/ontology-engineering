# Multiplicity patterns, worked

Keet 7.1.1. The rule that is most often got wrong: **a multiplicity written at
one end of an association constrains instances of the class at the *other*
end.** Read `Professor 1 --- teaches ---> 1..* Course` as "each Professor
teaches at least one Course", and "each Course is taught by exactly one
Professor".

## Worked example

Association `teaches`, left end `Professor` with `1..1`, right end `Course`
with `1..*`.

```
Declaration(ObjectProperty(:teaches))
ObjectPropertyDomain(:teaches :Professor)
ObjectPropertyRange(:teaches :Course)
SubClassOf(:Professor ObjectSomeValuesFrom(:teaches :Course))
SubClassOf(:Course ObjectExactCardinality(1 ObjectInverseOf(:teaches) :Professor))
InverseFunctionalObjectProperty(:teaches)
```

Line by line:

- the right end says `1..*`, so a Professor has at least one Course: an
  existential restriction on `:Professor`;
- there is no upper bound at the right end, so no max cardinality;
- the left end says `1..1`, so a Course relates to exactly one Professor. That
  is a restriction on `:Course`, and it must be written with
  `ObjectInverseOf(:teaches)` because `:teaches` runs Professor to Course;
- `1..1` at the *left* end also makes the property inverse-functional. Only a
  `1..1` or `0..1` at the *right* end would make it functional.

## Every case

Given `:r` with domain `:A` and range `:B`.

Right end `mB..MB`, constraining `:A`, expression `:r`:

| multiplicity | axioms |
|---|---|
| `0..*` | none |
| `1..*` | `SubClassOf(:A ObjectSomeValuesFrom(:r :B))` |
| `0..1` | `SubClassOf(:A ObjectMaxCardinality(1 :r :B))`, `FunctionalObjectProperty(:r)` |
| `1..1` | `SubClassOf(:A ObjectExactCardinality(1 :r :B))`, `FunctionalObjectProperty(:r)` |
| `2..*` | `SubClassOf(:A ObjectMinCardinality(2 :r :B))` |
| `0..5` | `SubClassOf(:A ObjectMaxCardinality(5 :r :B))` |
| `2..5` | both of the two preceding axioms |

Left end `mA..MA`, constraining `:B`, expression `ObjectInverseOf(:r)`, and
`InverseFunctionalObjectProperty(:r)` wherever the table above says
`FunctionalObjectProperty(:r)`.

## Traps

- `1..1` collapses to a single `ObjectExactCardinality(1 ...)`. Do not also
  emit the separate min and max axioms.
- `0..*` is the absence of a constraint. Emitting
  `ObjectMinCardinality(0 ...)` is noise and counts against precision.
- Emit domain and range **once per property**, from the association's own
  direction. Do not swap them when writing the inverse restriction.
- A mandatory attribute is `DataSomeValuesFrom`, not `ObjectSomeValuesFrom`.
