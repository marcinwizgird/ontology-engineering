---
name: conceptual-model-to-owl
description: >
  Convert a UML class diagram, EER diagram or ORM conceptual data model into
  OWL 2 axioms in functional syntax. Use when the source is a conceptual data
  model with entity types, attributes, generalisation sets and associations
  carrying multiplicities, or when the request mentions UML, EER, ORM,
  class diagram, conceptual model, multiplicity or n-ary relationship. Do not
  use for relational schemas, DDL or SQL - that is relational-schema-to-owl.
version: "1.0.0"
domain: ontology-engineering
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Conceptual data model to OWL

Implements Keet, *An Introduction to Ontology Engineering*, section 7.1.1.

## Output contract

Emit **OWL 2 functional-syntax axioms, one per line, and nothing else**. No
prose, no code fences, no `Prefix(...)` or `Ontology(...)` wrapper.

Naming, applied without exception:

- class name = `:` + PascalCase of the entity name (`Course` -> `:Course`)
- property name = `:` + camelCase of the association or attribute name
  (`teaches` -> `:teaches`, `student_number` -> `:studentNumber`)
- reified association class = `:` + PascalCase of the association name

Datatypes: `string|varchar|char|text` -> `xsd:string`; `integer|int` ->
`xsd:integer`; `decimal|numeric` -> `xsd:decimal`; `float|double|real` ->
`xsd:double`; `boolean` -> `xsd:boolean`; `date` -> `xsd:date`;
`datetime|timestamp` -> `xsd:dateTime`; `time` -> `xsd:time`.

## Step 1 - entity types

For every entity type `E`: `Declaration(Class(:E))`

## Step 2 - attributes

For attribute `a` of type `T` on owner `O` (an entity type, or a reified
association class from step 5):

```
Declaration(DataProperty(:a))
DataPropertyDomain(:a :O)
DataPropertyRange(:a xsd:T)
FunctionalDataProperty(:a)                    # unless the attribute is multivalued
SubClassOf(:O DataSomeValuesFrom(:a xsd:T))   # only if the attribute is mandatory
HasKey(:O (:a))                               # only if the attribute is an identifier
```

## Step 3 - generalisation sets

For a generalisation with parent `P` and children `C1..Cn`:

```
SubClassOf(:Ci :P)                                    # one per child
DisjointClasses(:C1 ... :Cn)                          # only if declared disjoint
EquivalentClasses(:P ObjectUnionOf(:C1 ... :Cn))      # only if declared complete
```

A generalisation that is both disjoint and complete is a partition and gets
both axioms. Never emit a covering axiom for an incomplete generalisation.

## Step 4 - binary associations

An association `r` with exactly two ends and no attributes of its own.
Call the ends `L` (entity `A`, multiplicity `mA..MA`) and `R` (entity `B`,
multiplicity `mB..MB`). Always emit:

```
Declaration(ObjectProperty(:r))
ObjectPropertyDomain(:r :A)
ObjectPropertyRange(:r :B)
```

**The multiplicity at one end constrains the class at the other end.**

From the `R` end, constrain `:A` using `:r` directly:

| `mB..MB` | axioms |
|---|---|
| `1..1` | `SubClassOf(:A ObjectExactCardinality(1 :r :B))` and `FunctionalObjectProperty(:r)` |
| `1..*` | `SubClassOf(:A ObjectSomeValuesFrom(:r :B))` |
| `0..1` | `SubClassOf(:A ObjectMaxCardinality(1 :r :B))` and `FunctionalObjectProperty(:r)` |
| `n..*` (n>1) | `SubClassOf(:A ObjectMinCardinality(n :r :B))` |
| `0..m` (m>1) | `SubClassOf(:A ObjectMaxCardinality(m :r :B))` |
| `n..m` | both the min and the max axiom above |
| `0..*` | nothing |

From the `L` end, constrain `:B` the same way but with `ObjectInverseOf(:r)`
in place of `:r`, and with `InverseFunctionalObjectProperty(:r)` in place of
`FunctionalObjectProperty(:r)`. For example `mA..MA = 1..1` gives:

```
SubClassOf(:B ObjectExactCardinality(1 ObjectInverseOf(:r) :A))
InverseFunctionalObjectProperty(:r)
```

Both directions must be emitted. Load `references/multiplicity-patterns.md`
for worked examples.

## Step 5 - reification

OWL 2 has only **binary** properties. Reify when either holds:

- the association has **three or more ends** (n-ary), or
- the association is an **association class** (it carries attributes).

For association `R` with ends `(role ri, entity Ei)`:

```
Declaration(Class(:R))
# for each end i:
Declaration(ObjectProperty(:ri))
ObjectPropertyDomain(:ri :R)
ObjectPropertyRange(:ri :Ei)
SubClassOf(:R ObjectExactCardinality(1 :ri :Ei))
FunctionalObjectProperty(:ri)
# participation, only when that end's minimum is 1 or more:
SubClassOf(:Ei ObjectSomeValuesFrom(ObjectInverseOf(:ri) :R))
```

Then apply step 2 to the association's own attributes with owner `:R`.

Never emit `Declaration(ObjectProperty(:R))` for a reified association - the
association became a class, not a property. Load
`references/reification.md` when the model contains an n-ary association or an
association class.

## Step 6 - validate

Run `scripts/check_axioms.py` with your draft axioms on stdin. It reports
unparsable lines and undeclared names. Fix exactly what it reports and re-emit
the complete axiom set.
