# Templates for ase-build-from-design

## Project layout

```
<project>/
  architecture/            spec, design, ad/, review/, build-plan.md, eval/, deploy/
  src/<agent>/
    config.py              model/provider strings, limits, thresholds - from env or file
    <part>.py              one module per design part; docstring names part + requirement ids
    prompts/ or signatures.py
    tools/                 one module per tool; permission scope declared next to it
  tests/
    l1_structure/          design conformance + pattern properties, no model
    l2_scenarios/          one test per A2 scenario, stubbed model
    l3_eval/               metrics on the eval set, marked slow
  scripts/
    eval.py                runs a dataset version, writes architecture/eval/reports/<run>.json
    gate.py                exit 1 if the latest report breaks a threshold
```

## Build plan (`architecture/build-plan.md`)

```
# Build plan - <system>
Target stage: P<n>        Source: design <commit> | review <date>
Coverage before: <stage reached>     Coverage target: P<n>

| Seq | Pattern | Status now | Card |
|---|---|---|---|
| 05 | watchdog-timeout | missing | [card](#05-watchdog-timeout) |
```

## Pattern card

```
### 05 watchdog-timeout
Realises:      design part <Name> / flow <a -> b>
Requirements:  QR-2 (answer within 8 s)
Prerequisites: 01 single-agent-baseline (present)
Code:          src/<agent>/llm.py, src/<agent>/graph.py
L1 test:       tests/l1_structure/test_timeouts.py - every model and HTTP client
               is constructed with timeout <= config.TIMEOUT_S; every loop has max_iter
L2 test:       tests/l2_scenarios/test_tool_hangs.py - a hanging tool yields the
               fallback answer within the budget
Metric:        P99 latency <= 8 s on held-out; timeout violations / 100 requests
Done when:     L1 + L2 green; metric in eval report; matrix line present with evidence
Decisions:     AD-7 timeout values
```

## Decision record

```
AD-<n>  <title>
Status:   proposed | accepted | superseded by AD-<m>
Owner:    <stakeholder role>          Date: <yyyy-mm-dd>
Context:  <requirement / finding / scenario>
Decision: <what>
Rejected: <alternative> - <why>
Consequences: <what gets better, what gets worse>
Revisit when: <trigger>
```

## Eval dataset manifest (`architecture/eval/datasets/<version>/manifest.json`)

```json
{
  "version": "v3",
  "created": "2026-10-15",
  "generator_model": "<provider/model@version>",
  "seed": 1234,
  "source_hash": "<sha256 of corpus or inputs>",
  "recipe": ["answerable", "out_of_scope", "adversarial"],
  "splits": {"train": 120, "dev": 40, "heldout": 40},
  "reviewed_sample": 20,
  "approver": "<role>",
  "requirements_covered": ["FR-1", "FR-2", "QR-1"],
  "quality_checks": {"duplicates": 0, "unsupported": 1, "uncovered_requirements": []}
}
```

## Deploy record (`architecture/deploy/<yyyy-mm-dd>-<version>.json`)

```json
{
  "program_version": "<git sha>",
  "prompt_version": "<hash or optimiser run id>",
  "dataset_version": "v3",
  "eval_report": "architecture/eval/reports/<run>.json",
  "gate": "pass",
  "target": "local | container | <env>",
  "live_heldout": {"metric": "groundedness", "offline": 0.94, "live": 0.93, "tolerance": 0.02},
  "approved_by": "<role>"
}
```
