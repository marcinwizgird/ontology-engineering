---
name: ase-build-from-design
description: >
  Implement or rebuild an agentic system by hand (with a coding agent)
  following the ASE methodology - from an accepted SysML v2 design or an
  architecture review's remediation plan, build pattern by pattern in the
  ASE pattern-sequence order, each pattern with its structural test, scenario
  test and metric; keep code traceable to the design and requirements; build
  a versioned evaluation set, optimise against held-out data, and make the
  agent deployable behind an eval gate. Use when asked to build, implement,
  refactor or harden an agent "according to the methodology", to implement
  a design produced with ase-arch-definition-process, or to fix the findings
  of ase-arch-review. Do not use to decide the architecture (use
  ase-arch-definition-process) or to review existing code (use
  ase-arch-review).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Build from design, pattern by pattern

This is the manual counterpart of ASE's generator: a coding agent builds,
the method constrains. It is methodology-guided, not deterministic -
the code will differ from what ASE would generate - so keep the artifacts
in ASE's shape (spec, design, decisions, eval, deploy record) and the
system can be taken over by ASE later. Load `ase-arch-patterns` first.

## Rules you are held to

- **Design first.** Never code a component the design does not have. If
  the code needs to differ, change `design.sysml` (gate it) and record the
  decision, then change the code.
- **Sequence order.** Build a pattern only when every pattern it requires is
  present. Within a stage, follow catalogue order unless a decision says
  otherwise.
- **Deterministic where the answer is determined.** Parsing, validation,
  calculation, reasoning over formal models, routing on known keys: code or a
  formal tool, not an LLM. The LLM does judgement, language and what cannot
  be computed.
- **Provider-agnostic.** Model choice is configuration (`provider/model`
  strings via DSPy `dspy.LM` or a LangChain chat-model factory); no provider
  SDK in agent logic.
- **A pattern is done when its metric is measured.** Code without a test
  that measures the card's metric is `partial`.
- **Every deviation has a decision** (owner, date, reason, requirement).

## Inputs

Either a new design (`architecture/spec.md`, `design.sysml`, `ad/` with
accepted decisions - produced by `ase-arch-definition-process`) or a review
(`architecture/review/report.md` with the coverage matrix and findings).

## Steps

### B1 Build plan
From the design's chosen patterns or the review's remediation list, write
`architecture/build-plan.md`: target stage, then one **pattern card** per
pattern in sequence order (template in `references/templates.md`): the
design element it realises, requirement ids, code location, structural
test, scenario test, metric and threshold, done-when. Close over
prerequisites with `catalogue.py coverage` on the planned matrix; the plan
must show no prerequisite violations.

### B2 Project skeleton
Lay out the code so the design is visible in it (layout in
`references/templates.md`): one module per design part, configuration
separate from logic, prompts or DSPy signatures in their own files, tests
split by layer:

| Layer | Asserts | Runs |
|---|---|---|
| L1 structure | the code matches the design and the pattern properties hold (every client has a timeout, every loop a bound, every tool a permission scope) | always, no model |
| L2 scenarios | each A2 scenario's expected behaviour with a scripted or stubbed model | always, no model |
| L3 evaluation | metrics on the eval set clear the thresholds | with model and data, marked slow |

### B3 Implement in sequence
For each card, in order:

1. implement the smallest code that realises the pattern for this design;
2. write the L1 test for its defining property, then the L2 scenario test;
3. hook the metric into the eval (B5) if the card has a runtime metric;
4. update the coverage matrix line to `present` with `file:line` and test
   evidence; re-run `coverage` - no new violations;
5. record any decision (choice of library, threshold, deviation).

Do not start the next card while the current one's tests fail.

### B4 Traceability
Each module's docstring names the design part and the requirement ids it
serves. A change that alters behaviour visible in the design updates
`design.sysml` and re-runs the analysis (`ase-arch-review` R5 snippet).

### B5 Evaluation set (production contract rule 2)
- Choose item types from the requirement types: answerable cases per
  function, out-of-scope and unanswerable cases (refusal requirements),
  multi-step cases, decoys, adversarial inputs (from red teaming, pattern 20).
- Generate with a pinned model and a recorded seed, review a sample by hand,
  split train / dev / held-out, and store under
  `architecture/eval/datasets/<version>/` with a manifest (template).
- Check the set before use: duplicates, items whose answer the source does
  not support, a requirement with no items.
- One metric per requirement, deterministic where possible; an LLM judge
  only where it must, with its own agreement check against human labels.

### B6 Optimisation
Measure the baseline on dev and held-out. Optimise prompts (DSPy / GEPA,
or recorded manual iterations) on train, select on dev, **accept only on
held-out**: better on the objective, no hard requirement or budget
broken. Record before / after and every rejected candidate. Optimisation
has its own token budget.

### B7 Deployment readiness (production contract rules 1 and 3)
Configuration with model and provider as settings; health check; one
structured log record per request with program, prompt and dataset
versions; a gate script that reads the latest eval report and refuses to
deploy when a threshold fails; after deploying, the held-out set run against
the live endpoint and the result written to a deploy record (template).

### B8 Close
Re-run `coverage` (stage reached), the analysis on the updated design, and
all test layers. Write a summary: stage reached, patterns added, metrics
before / after, open findings, decisions taken.

## Pitfalls -> detection

| Pitfall | Detection |
|---|---|
| Pattern built on a missing prerequisite | `coverage` reports a violation |
| Code ahead of the design | a module whose docstring names no design part; design unchanged in the diff |
| LLM used for a computable answer | a model call whose output a parser, validator or reasoner could produce |
| Pattern "done" without a metric | matrix says present, no test measures the card's metric |
| Optimised on the test set | accepted candidate chosen by held-out score more than once, or no held-out split |
| Eval set reused after regeneration without a new version | dataset files changed, manifest version unchanged |
| Deploy without gate | deploy record missing the eval report and verdict |

## Output contract

`architecture/build-plan.md` with every card closed or explicitly open;
code and tests per the layout; updated matrix and `coverage` output;
`architecture/eval/` datasets with manifests and reports; decisions in
`ad/decisions.sysml`; deploy record when deployed; the B8 summary. Report
test and eval failures as failures.
