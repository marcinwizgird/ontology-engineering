---
name: ase-perspective-location
description: >
  Apply the Rozanski & Woods Location perspective to an agentic system's
  SysML v2 architecture - map where each stage, store, model endpoint and
  user sits, estimate link quality and latency across distance, handle data
  residency and sovereignty, time zones and wide-area link failure, and make
  residency computable by adding a `region` extension attribute and a
  residency requirement checked with residency_check.py. Use for model API
  region, data residency, "may this data leave the EU / our premises",
  cross-region latency, multi-office time zones, offline operation or
  distributed deployment questions about an ASE design. Do not use for
  placement of stages on nodes in general (use ase-viewpoint-deployment),
  attacks and trust boundaries (use ase-perspective-security) or legal
  evidence packs (use ase-perspective-regulation).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Location perspective

Load `ase-arch-sysml-foundations` first. Control (read-only):
`AseMethodology::LocationPerspective` - read with `ase_perspective("Location")`;
it frames `DeploymentTopology` (`ase_concern("DeploymentTopology")`).

## Definition

> "The ability of the system to overcome problems brought about by the
> absolute location of its elements and the distances between them" -
> `AseMethodology::LocationPerspective`, source
> viewpoints-and-perspectives.info/home/perspectives.

## Status in ASE: review-only - and why

`LocationPerspective` declares `checks = ""` and carries `@ReviewOnly`:

> "Computable the moment the vocabulary carries a residency attribute:
> data-residency violations are a reachability question over region
> boundaries, exactly like data_exposure. It is review-only because the
> attribute does not exist yet, not because the question resists
> formalising. This is the clearest example of the coverage matrix naming
> its own next move."

So: **no ASE check** reads location today; `check_coverage` accepts the
perspective because the reason is stated. This skill supplies the next move
without touching the vocabulary: `region` as an `@Extension` attribute on
the *design's* stage defs, a residency requirement with a machine-readable
rule, and `scripts/residency_check.py`, which does the `data_exposure`-style
traversal with regions in place of sink types. `vocabulary_conformance`
warns on `region` - intended; the decision names the roadmap item to promote
it. `check_ad.py` already expects `region` when Location is applied.

**Applicability.** R&W: systems whose elements or external partners are
physically separated, including DR sites and distant links. Agentic systems
almost always qualify: the model endpoint is a remote service in a
provider-chosen region, often a different jurisdiction from the data.

**Concerns.** R&W: time zones of operation; network link characteristics;
resilience to link failure; wide-area interoperability; high-volume
operations over distance; political, commercial and legal differences
between countries; use of the public internet; physical variation between
sites. Agentic additions: model API region and the provider's own logging
and retention location; residency of embeddings, caches, traces and memory
(they are copies of the data); per-call round trips multiplied by
`llmCalls`; human approvers in other time zones. **Stakeholders**:
`SiteReliabilityEngineer`, `FinanceOwner` (holders of `DeploymentTopology`),
`ComplianceOfficer` / DPO for residency, users in each region.

## Activities -> SysML

R&W activities: geographical mapping; link quality estimation; latency
estimation; benchmarking; modelling geographical characteristics.

### 1. Geographical mapping

Give every stage, store and external endpoint a region, as an extension on
the design's stage defs (never on the library):

```
part def LocatedStage :> RS06::Stage {
    @AseProfile::Extension {
        reason = "LocationPerspective @ReviewOnly: residency needs a region.";
        extends = "Stage vocabulary (RagPatterns::Stage) - roadmap: promote `region`";
    }
    attribute region : String = "onprem-fra";
}
part def HostedSynthesizer :> LocatedStage {
    attribute redefines region = "eu-west";
}
```

Use one naming scheme (provider region codes, or `<site>-<city>`) and list
users' regions in the Context view. Include the stores behind the stages:
the vector index, the cache, the trace store, conversation memory.

### 2. State the residency rule as a requirement

A residency sentence becomes a requirement with the allowed regions and the
data classes it applies to - the two attributes the script reads:

```
requirement def ConfidentialStaysOnPrem {
    doc /* RS-06 C-2: confidential proposals use the on-prem model only. */
    attribute allowedRegions : String = "onprem-fra";
    attribute appliesTo : String = "restricted";
}
satisfy ConfidentialStaysOnPrem by RS06::RS06Design;
```

`dataClass` on the stages (vocabulary attribute) supplies the class.

### 3. Link quality and latency estimation

Flows carry no latency. For each cross-region edge (the script lists them),
fold the round trip into the called stage's `latencyMs` and record the RTT
as an `@Assumption`. LLM calls pay the RTT per call, so a loop multiplies
it by `maxIterations`. A calc states the allowance:

```
calc def WanAllowance {
    in crossingsOnPath : Integer;
    in rttMs : Integer;
    in iterations : Integer;
    return : Integer = crossingsOnPath * rttMs * iterations;
}
```

Link failure: name each cross-region edge's behaviour when the link is down
(retry, degrade, queue, offline) - that is Availability work on the edge.

### 4. Benchmarking

Measure RTT and time-to-first-token from each user region to each model
region; replace the assumption, keep the old value in `doc`. Express it as
a `verification def` against the latency requirement.

### 5. Model geographical characteristics

Time zones and working hours per user group; maintenance windows that
overlap nobody; public-internet segments; jurisdictions per region (which
law, which provider contract clause). Record as `@Assumption`s with
`revisitWhen`, and as `doc` on the Deployment view nodes.

## Applying the perspective to each view

| View | What the perspective adds in SysML |
|---|---|
| Context | users and external systems by region; jurisdictions; public-internet links |
| Functional | routing stages that keep a data class in its region (per-region synthesiser) |
| Information | `dataClass` per stage and item; residency of copies - embeddings, cache, traces, memory |
| Knowledge | where each corpus lives; whether retrieval runs next to its store |
| Concurrency | cross-region calls on the critical path vs batched in the background |
| Autonomy | approvers' time zones: an approval gate nobody staffs at night is an outage |
| Deployment | `region` per node and endpoint; provider region pinned by contract; DR site distance |
| Operational | follow-the-sun support; maintenance windows per region; link-down runbooks |
| Development | environment per region; test data that respects residency |

## Analysis the perspective supports

| Question | Engine |
|---|---|
| Does restricted data reach a stage outside its allowed regions? | `run_skill_script("ase-perspective-location", "residency_check.py", stdin=<design + location file>)` |
| Which flows cross a region boundary? | same script (info lines) |
| Which stages have no region (no conclusion possible)? | same script (warnings) |
| WAN latency on the critical path | `WanAllowance` calc + `latency_budget` after folding RTT into `latencyMs` |
| Does `data_exposure` see residency? | no - the model endpoint is not an `EXTERNAL_KINDS` stage; say so |
| Time zones, jurisdictions, political and commercial issues | none - review |

The script is closed-world and has no declassification: a redactor on the
path does not clear a finding. It follows every declared flow in a pattern
transitively. A clean result names the regions, classes and flows it rests on.

## Reasoning over the model regardless

Without the extension an agent can still: list every stage that calls a
model (`llmCalls > 0`) and ask where its endpoint runs; follow flows from
each restricted stage and list what it reaches - that set is the residency
question even before regions exist; count `llmCalls x maxIterations` on the
critical path to size the RTT multiplier; check that every Autonomy gate has
an approver in the users' time zones. Report each as a question for A1, not
a verdict.

## Tactics -> SysML change -> expected effect

| Tactic (R&W) | Agentic form | SysML change | Expected effect |
|---|---|---|---|
| Avoid widely distributed transactions | keep retrieval, rerank and synthesis in one region per request | co-locate stages; one region per branch | fewer cross-region edges in the script output |
| Plan for wide-area link failure | local fallback model or cached answers when the hosted region is unreachable | fallback stage in the local region, `hasFallback = true` | `fallback_coverage`; residency unchanged |
| Allow offline operation | on-device or on-prem small model for field users | on-prem synthesiser stage | cross-region edges removed from that path |
| (agentic) Route by data class | confidential branch to an in-region model | separate reranker and synthesiser for the class | residency violation cleared (RS-06 example) |
| (agentic) Pin provider region | contract clause; regional endpoint | `region` on the endpoint stage; `@Assumption` citing the contract | the script can conclude instead of warn |
| (agentic) Move work off the interactive path | cross-region enrichment in a nightly batch | stage moved to a batch pattern | `latency_budget` improves |

## Pitfalls -> detection in the model

| Pitfall (R&W + agentic) | Detection |
|---|---|
| Invalid WAN assumptions | cross-region edges with no RTT `@Assumption`; `latencyMs` unchanged after adding a region |
| Assuming centralised administration | one operator role, users in several regions |
| Assuming a single time zone | one maintenance window; approval gate staffed in one zone |
| Assuming end-to-end security | a public-internet edge with no Security finding |
| Assuming overnight batch windows | re-index scheduled "overnight" with users on two continents |
| Overlooking political, commercial and legal differences | residency sentence in the spec with no `allowedRegions` requirement |
| Overestimating public network capability | streaming to distant users assumed to match local |
| Assuming standard physical environments | edge sites with no offline decision |
| (agentic) model endpoint region unknown | stage with `llmCalls > 0` and no `region` (script warning) |
| (agentic) copies forgotten | cache, embeddings, traces with no region |
| (agentic) RTT counted once | loop with `maxIterations > 1` crossing regions each pass |

## Checklist

Every stage, store and endpoint mapped to a region; residency rules written
as requirements with allowed regions and classes; `residency_check.py`
clean or each violation fixed or accepted by its owner; every cross-region
edge has an RTT assumption folded into latency and a link-down behaviour;
time zones of users, operators and approvers covered; jurisdictional issues
reviewed with compliance; benchmarks planned from each user region.

## Output contract

In `ad/perspectives.sysml` (or `ad/location.sysml`):

1. `satisfy AseMethodology::LocationPerspective by <Design>;` - or a
   decision setting it aside with its reason
2. `region` on the design's stage defs with `@Extension` (reason, roadmap
   item); residency requirement defs with `allowedRegions` / `appliesTo`
3. the script output as `@Finding`s (check = `residency_check.py`), with
   the what-if variant that shows the rule can fail
4. `@Assumption`s for RTTs, provider region, time zones
5. `@ArchitectureDecision` per routing or placement choice

Validate: gate; `check_ad.py` with `// ad-check: perspectives=Location`;
`residency_check.py` on `design.sysml` + the location file concatenated.
Worked RS-06 example: `references/example.sysml` (runs through the script
on its own).
