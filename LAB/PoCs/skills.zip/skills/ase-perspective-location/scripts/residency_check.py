#!/usr/bin/env python3
"""Tier-3 analysis: data residency as reachability over region boundaries.

The Location perspective is @ReviewOnly in ASE because the stage vocabulary
has no residency attribute. This script shows the check the methodology says
becomes possible once it does: read a design (SysML v2 text on stdin) whose
stage defs carry an @Extension attribute `region`, and report restricted data
flowing across region boundaries - the same traversal `data_exposure` makes
towards external sinks, with regions in place of sink types.

Reads
    part def X :> Y { attribute [redefines] region = "..."; dataClass = "..."; }
                          resolved through :> within the input; a part usage
                          may override with `part u : X { attribute redefines region = "..."; }`
    part def P { part u : X; flow a to b; }          a pattern: parts + flows
    requirement def R { attribute allowedRegions : String = "a,b";
                        attribute appliesTo : String = "restricted,pii"; }   optional

Rules
    restricted classes    restricted, pii, regulated, secret (as data_exposure),
                          or the requirement's appliesTo list
    with a requirement    error: restricted data is held in, or reaches a stage
                          in, a region outside allowedRegions
    without one           warning: restricted data reaches a stage in a
                          different region from where it is held
    undeclared region     warning on any stage restricted data reaches
                          (closed world: no region means no conclusion)
    cross-region edges    info: every flow whose ends sit in different regions
                          - a WAN hop whose latency no flow carries

Limits, stated: flows are followed transitively and nothing declassifies (a
redactor on the path does not clear a finding, as in data_exposure);
`dataClass` is read per stage, not per item; only flows declared inside a
pattern are seen. Exit 1 on any error, 0 otherwise.
"""

import re
import sys

RESTRICTED = {"restricted", "pii", "regulated", "secret"}
ATTR = re.compile(r"\battribute\s+(?:redefines\s+)?(\w+)\s*(?::\s*[\w:]+)?\s*=\s*"
                  r"(\"[^\"]*\"|[\w.]+)\s*;")


def strip(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"//[^\n]*", " ", text)


def body_at(text, i):
    depth, j = 0, i
    while j < len(text):
        depth += {"{": 1, "}": -1}.get(text[j], 0)
        if depth == 0:
            return text[i + 1:j]
        j += 1
    return text[i + 1:]


def own_attrs(body):
    # only the def's own level: drop nested blocks first
    flat, depth = [], 0
    for ch in body:
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
        elif depth == 0:
            flat.append(ch)
    return {k: v.strip('"') for k, v in ATTR.findall("".join(flat))}


def parse(text):
    defs, reqs = {}, {}
    for m in re.finditer(r"\bpart\s+def\s+(\w+)\s*(?::>\s*((?:\w+::)*\w+))?\s*;", text):
        defs[m.group(1)] = {"parent": m.group(2).split("::")[-1] if m.group(2) else None,
                            "attrs": {}, "usages": {}, "flows": []}
    for m in re.finditer(r"\b(part|requirement)\s+def\s+(\w+)\s*(?::>\s*((?:\w+::)*\w+))?"
                         r"[^;{]*\{", text):
        kind, name, parent = m.group(1), m.group(2), m.group(3)
        body = body_at(text, m.end() - 1)
        if kind == "requirement":
            reqs[name] = own_attrs(body)
            continue
        usages = {}
        for u in re.finditer(r"\bpart\s+(\w+)\s*:\s*((?:\w+::)*\w+)\s*(;|\{)", body):
            over = own_attrs(body_at(body, u.end() - 1)) if u.group(3) == "{" else {}
            usages[u.group(1)] = (u.group(2).split("::")[-1], over)
        flows = re.findall(r"\bflow\s+(\w+)\s+to\s+(\w+)\s*;", body)
        defs[name] = {"parent": parent.split("::")[-1] if parent else None,
                      "attrs": own_attrs(body), "usages": usages, "flows": flows}
    return defs, reqs


def resolved(defs, name, seen=()):
    d = defs.get(name)
    if d is None or name in seen:
        return {}
    base = resolved(defs, d["parent"], seen + (name,)) if d["parent"] else {}
    return {**base, **d["attrs"]}


def main():
    text = strip(sys.stdin.read())
    defs, reqs = parse(text)
    patterns = {n: d for n, d in defs.items() if d["usages"] and d["flows"]}
    rules = [(n, {r.strip() for r in a["allowedRegions"].split(",") if r.strip()},
              {c.strip().lower() for c in a.get("appliesTo", "").split(",") if c.strip()}
              or RESTRICTED)
             for n, a in reqs.items() if "allowedRegions" in a]
    errors, warnings, info = [], [], []

    if not patterns:
        print("FAIL - no pattern (part def with parts and flows) in the input")
        return 1
    if not any("region" in resolved(defs, n) for n in defs) and \
            not any("region" in o for p in patterns.values() for _, o in p["usages"].values()):
        print(f"OK - {len(patterns)} pattern(s), no stage declares `region`: nothing to "
              "compute, Location stays review-only for this design")
        print("note: add `region` as an @Extension on the design's stage defs to make residency checkable")
        return 0

    for pname, p in sorted(patterns.items()):
        st = {u: {**resolved(defs, t), **o} for u, (t, o) in p["usages"].items()}
        succ = {u: [] for u in st}
        for a, b in p["flows"]:
            if a in st and b in st:
                succ[a].append(b)
                ra, rb = st[a].get("region"), st[b].get("region")
                if ra and rb and ra != rb:
                    info.append(f"{pname}: {a} ({ra}) -> {b} ({rb}) crosses a region boundary "
                                "- fold the WAN hop into latencyMs")
        classes = set().union(*[c for _, _, c in rules]) if rules else RESTRICTED
        for s, a in sorted(st.items()):
            cls = str(a.get("dataClass", "")).lower()
            if cls not in classes:
                continue
            home = a.get("region")
            for rname, allowed, applies in rules:
                if cls in applies and home and home not in allowed:
                    errors.append(f"{pname}: {s} holds {cls} data in {home}, outside "
                                  f"{rname}.allowedRegions {sorted(allowed)}")
            seen, stack = set(), list(succ[s])
            while stack:
                t = stack.pop()
                if t in seen or t == s:
                    continue
                seen.add(t)
                stack.extend(succ[t])
                where = st[t].get("region")
                if not where:
                    warnings.append(f"{pname}: {s} ({cls}) reaches {t}, region undeclared "
                                    "- no conclusion")
                    continue
                hit = [r for r, allowed, applies in rules if cls in applies and where not in allowed]
                if hit:
                    errors.append(f"{pname}: {s} ({cls}, {home or '?'}) reaches {t} in {where}, "
                                  f"outside {', '.join(hit)}")
                elif not rules and home and where != home:
                    warnings.append(f"{pname}: {s} ({cls}, {home}) reaches {t} in {where} "
                                    "- crosses a region boundary; no residency requirement declared")

    head = "FAIL" if errors else ("OK with warnings" if warnings else "OK")
    print(f"{head} - {len(patterns)} pattern(s), {len(rules)} residency requirement(s), "
          f"{len(errors)} violation(s)")
    for tag, items in (("error", errors), ("warning", warnings), ("info", info)):
        for i in sorted(set(items)):
            print(f"  - {tag}: {i}")
    print("note: closed world - only declared regions, classes and flows; nothing declassifies")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
