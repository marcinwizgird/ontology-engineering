#!/usr/bin/env python3
"""Tier-3 analysis: module structure rules of an ASE Development view.

Reads SysML v2 text on stdin: the design (stage defs + the pattern part def
with parts and flows) followed by the Development view. Modules are part defs
that specialise `Module` or carry `@CodeOrigin { origin; realises; ... }`;
layers are the packages that contain them; dependencies are `import`s
between those packages.

Rules (ASE codegen split - model-determined code is generated, the rest is
hand-written):

    origin      every module carries @CodeOrigin with origin in
                generated | hand-written | optimised | data | test
    layering    hand-written never imports generated (regeneration breaks it);
                non-test code never imports test code; optimised prompt sets
                are data - loaded, not imported
    wiring      every stage usage is realised by a generated module
    contracts   every model-calling stage (llmCalls > 0) is realised by a
                hand-written contract module - else codegen emits a marked stub
                unless the library STAGE_CONTRACTS already has its kind
    impls       every non-model stage is realised by a hand-written module -
                else the generated program raises NotImplementedError
    ownership   at most one hand-written module realises a stage

Also prints the build surface (distinct stage kinds, model-calling kinds,
hand-written implementations owed), which mirrors the build_surface check.
Text-level and closed-world: undeclared modules are invisible.
Exit 1 when a layering or impls error is found, else 0.
"""

import re
import sys

ORIGINS = {"generated", "hand-written", "optimised", "data", "test"}


def strip(text):
    text = re.sub(r"/\*.*?\*/", lambda m: " " * len(m.group(0)), text, flags=re.S)
    return re.sub(r"//[^\n]*", lambda m: " " * len(m.group(0)), text)


def span(text, start):
    i = text.find("{", start)
    depth, j = 0, i
    while j < len(text):
        depth += {"{": 1, "}": -1}.get(text[j], 0)
        if depth == 0:
            break
        j += 1
    return i, j


def blocks(text, header_re):
    for m in re.finditer(header_re, text):
        i = text.find("{", m.start())
        if i < 0 or ";" in text[m.end():i]:
            continue
        a, b = span(text, m.start())
        yield m, text[a + 1:b]


def resolve(defs, parents, name, attr, seen=None):
    seen = seen or set()
    if name in seen:
        return None
    seen.add(name)
    m = re.search(r"attribute\s+(?:redefines\s+)?" + attr + r"\b[^=;]*=\s*([\w.]+)", defs.get(name, ""))
    if m:
        return m.group(1)
    return resolve(defs, parents, parents[name], attr, seen) if name in parents else None


def main():
    raw = sys.stdin.read()
    text = strip(raw)          # same length as raw: offsets stay valid
    parents = {m.group(1): m.group(2) for m in
               re.finditer(r"\bpart\s+def\s+(\w+)\s*:>\s*(?:\w+::)*(\w+)", text)}
    defs = {m.group(1): body for m, body in blocks(text, r"\bpart\s+def\s+(\w+)")}

    patterns = {}
    for name, body in defs.items():
        parts = dict(re.findall(r"\bpart\s+(\w+)\s*:\s*(?:\w+::)*(\w+)\s*;", body))
        flows = re.findall(r"\bflow\s+(\w+)(?:\.\w+)?\s+to\s+(\w+)", body)
        if len(parts) >= 2 and flows:
            patterns[name] = parts
    if not patterns:
        print("FAIL - no pattern found (a part def with parts and flows); include design.sysml in the input")
        return 1

    # innermost package for an offset
    pkgs = []
    for m in re.finditer(r"\bpackage\s+(\w+)\s*\{", text):
        a, b = span(text, m.start())
        pkgs.append((a, b, m.group(1)))

    def package_of(pos):
        inside = [p for p in pkgs if p[0] < pos < p[1]]
        return min(inside, key=lambda p: p[1] - p[0])[2] if inside else "-"

    modules = {}                    # name -> (package, origin, realises)
    for m, body in blocks(raw, r"\bpart\s+def\s+(\w+)"):
        header = raw[m.start():raw.find("{", m.start())]
        meta = re.search(r"@(?:\w+::)*CodeOrigin\s*\{(.*?)\}", body, re.S)
        if not meta and not re.search(r":>\s*(?:\w+::)*Module\b", header):
            continue
        fields = dict(re.findall(r"(\w+)\s*=\s*\"(.*?)\"\s*;", meta.group(1), re.S)) if meta else {}
        realises = {s.strip() for s in fields.get("realises", "").split(",") if s.strip()}
        modules[m.group(1)] = (package_of(m.start()), fields.get("origin"), realises)

    for m in re.finditer(r"\bpart\s+def\s+(\w+)\s*:>\s*(?:\w+::)*Module\s*;", text):
        modules.setdefault(m.group(1), (package_of(m.start()), None, set()))

    errors, warnings, info = [], [], []

    for name, (pkg, origin, _) in sorted(modules.items()):
        if origin is None:
            warnings.append(f"origin: module {name} has no @CodeOrigin - generated or hand-written is unknown")
        elif origin not in ORIGINS:
            warnings.append(f"origin: module {name} has origin '{origin}' - expected one of {', '.join(sorted(ORIGINS))}")

    pkg_origins = {}
    for pkg, origin, _ in modules.values():
        if origin:
            pkg_origins.setdefault(pkg, set()).add(origin)
    for m in re.finditer(r"\b(?:private\s+|public\s+)?import\s+((?:\w+::)*\w+)::\*\*?\s*;", text):
        src = package_of(m.start())
        dst = m.group(1).split("::")[-1]
        so, do = pkg_origins.get(src), pkg_origins.get(dst)
        if not so or not do:
            continue
        if "generated" in do and so <= {"hand-written"}:
            errors.append(f"layering: {src} (hand-written) imports {dst} (generated) - regeneration breaks hand-written code")
        if do & {"test"} and not so <= {"test", "data"}:
            errors.append(f"layering: {src} imports test package {dst} - test code in the product")
        if "optimised" in do:
            warnings.append(f"layering: {src} imports {dst} (optimised) - prompt sets are data to load, not code to import")

    if not modules:
        warnings.append("no modules declared (part def :> Module or @CodeOrigin) - only the build surface is reported")

    for pname, parts in sorted(patterns.items()):
        kinds = set(parts.values())
        llm_kinds = {t for t in kinds if (resolve(defs, parents, t, "llmCalls") or "0") != "0"}
        print(f"== {pname}: {len(parts)} stages, {len(kinds)} distinct kinds, {len(llm_kinds)} model-calling kinds; "
              f"hand-written implementations owed: {len(kinds - llm_kinds)} ({', '.join(sorted(kinds - llm_kinds)) or 'none'})")
        if not modules:
            continue
        for stage, kind in sorted(parts.items()):
            gen = [n for n, (_, o, r) in modules.items() if o == "generated" and stage in r]
            hand = [n for n, (_, o, r) in modules.items() if o == "hand-written" and stage in r]
            if not gen:
                warnings.append(f"wiring: {pname}.{stage} is realised by no generated module - hand-wired, or missing")
            if kind in llm_kinds and not hand:
                warnings.append(f"contracts: {pname}.{stage} ({kind}) calls a model but no hand-written contract module realises it - a marked stub unless STAGE_CONTRACTS has {kind}")
            if kind not in llm_kinds and not hand:
                errors.append(f"impls: {pname}.{stage} ({kind}) is a non-model stage with no hand-written implementation - NotImplementedError at run time")
            if len(hand) > 1:
                warnings.append(f"ownership: {pname}.{stage} realised by {len(hand)} hand-written modules: {', '.join(sorted(hand))}")

    by_origin = {}
    for n, (_, o, _) in modules.items():
        by_origin.setdefault(o or "?", []).append(n)
    info.append("modules by origin: " + "; ".join(f"{o} {len(v)}" for o, v in sorted(by_origin.items())) if modules else "modules by origin: none")

    head = "FAIL" if errors else ("OK with warnings" if warnings else "OK")
    print(f"{head} - {len(modules)} module(s), {len(errors)} error(s), {len(warnings)} warning(s)")
    for tag, items in (("error", errors), ("warning", warnings), ("info", info)):
        for i in items:
            print(f"  - {tag}: {i}")
    print("note: text-level, closed-world rules over declared modules, imports and realises lists")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
