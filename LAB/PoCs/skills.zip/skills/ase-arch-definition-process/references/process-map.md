# Process map: R&W ch7 -> ASE IDEF0 -> SysML artefacts -> agents

Authoritative content is `methodology/ase-process-idef0.sysml`; query it with
`ase_step` / `ase_controls`. This table is the working summary.

## ICOM per step

| Node | R&W step | Inputs (may transform) | Controls (obey) | Outputs (SysML) | Mechanism / ASE agent |
|---|---|---|---|---|---|
| A-0 | Define the architecture | scope & context, concerns, requirements | viewpoint catalogue, perspective catalogue, styles | the AD, revised requirements | architect, stakeholders, ASE workbench |
| A1 | 1 Consolidate inputs | raw inputs, draft Context view, concerns | stakeholder agreement | requirement defs, concerns, `@Assumption`, exploration list | ConsolidationAgent (assists) |
| A2 | 2 Identify scenarios | consolidated inputs | quality property requirements | `@QualityScenario`, `@FunctionalScenario`, utility tree | ScenarioAgent (assists) |
| A3 | 3 Identify styles | consolidated inputs, scenarios | pattern catalogue | pattern choice + rejections as `@ArchitectureDecision` | PatternAgent (performs) |
| A4 | 4 Candidate architecture | consolidated inputs | styles, viewpoints, perspectives | `design.sysml`, draft `ad/<view>.sysml` | ViewAuthoringAgent (performs) |
| A5 | 5 Explore options | draft views, inputs, scenarios | viewpoints, perspectives | refined views, `@Finding`, decisions, trade studies | AnalysisAgent (performs) |
| A6 | 6 Evaluate with stakeholders | inputs, views, perspective outputs | stakeholder concerns | review comments, acceptance decision, evidence pack | EvidenceAgent (assists) |
| A7 | 7A Rework | views, review comments | styles, viewpoints, perspectives | reworked views; areas for investigation (tunnelled) | ViewAuthoringAgent (performs) |
| A8 | 7B Revisit requirements | views, review comments | stakeholder agreement | revised requirements (`status = proposed` until agreed) | EvidenceAgent (assists) |

Rework loop: A6 -> {A7 || A8} -> A5. Never back to A1.

Note on numbering: R&W print the two concurrent rework steps as 7A / 7B;
ASE numbers them A7 / A8 so each is a distinct IDEF0 box.

## Supporting activities (R&W Fig. 7-2) -> ASE

| R&W | ASE | Output |
|---|---|---|
| Define initial scope and context | before A1; `ase-viewpoint-context` | draft Context view |
| Engage stakeholders | before A1 | stakeholder part defs |
| Capture first-cut concerns | before A1 | concern defs with priorities |
| Define architecture | A0 (A1-A8) | the AD, guidelines and constraints |
| Create skeleton system (optional) | codegen + eval (ROADMAP pipeline) | generated program addressing >= 1 scenario |

The skeleton's acceptance test in R&W is that it addresses at least one
scenario. In ASE that is the generated program passing the A2 scenario's
response measure in eval.

## Where viewpoints and perspectives enter

R&W name viewpoints and perspectives as guidance in steps 4, 5 and 7A only;
perspective *outputs* are an input to step 6. They do not appear in 1-3 or 7B.
ASE departs in one place, deliberately: A1 uses viewpoint and perspective
*obligations* (`ase_obligations`) to decide what to ask, because asking
without them is what makes elicitation arbitrary.

## Lifecycle fit

| Lifecycle | Where A1-A8 sits | ASE practice |
|---|---|---|
| Waterfall | distinct early task, before/alongside requirements | one full pass, deep views |
| Iterative (RUP elaboration) | each iteration targets a high-risk area | one A5-A7 loop per iteration, per risk |
| Agile | incremental, on-demand architecture; perspectives for cross-cutting concerns | run the perspective sweep in CI on every model change; keep views thin; decisions as the durable record |

## Exit (R&W: risk-based)

Complete for an iteration once material risks are mitigated - no
significant open comments after evaluation, architect included. Rule of
thumb in R&W: one to three months for all but the largest systems. Avoid
endless refinement; the AD is baselined and lives under configuration
control afterwards.
