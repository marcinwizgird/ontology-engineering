---
name: ase-arch-definition-process
description: >
  Walk the Rozanski & Woods Architecture Definition Process (IDEF0 A1-A8 in
  ASE) for an agentic system and produce a SysML v2 architecture description:
  consolidate inputs, identify scenarios, select styles/patterns, draft views,
  explore options, evaluate with stakeholders, rework, revisit requirements.
  Use when asked to define, design or review the architecture of a system
  from an RS-xx spec or requirements, to run the ASE process end to end, or
  to decide which viewpoint and perspective skills to apply next. Do not use
  for a single view or a single quality concern in isolation - load the
  matching ase-viewpoint-* or ase-perspective-* skill directly.
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Architecture Definition Process (R&W ch7, ASE IDEF0)

The orchestrating skill of the ASE architecture series. It says *which step
you are in, what governs it, what it must produce in SysML, and which skill to
load next*. First load `ase-arch-sysml-foundations`.

Source: Rozanski & Woods, *Software Systems Architecture* 2nd ed., ch7, as
modelled in `methodology/ase-process-idef0.sysml`. Cite with
`ase_provenance`; read any step with `ase_step("<node>")`.

## Principles you are held to

R&W require the process to be **concern-driven** (balance conflicting
concerns, not just list them), **structured** (each step has aims, inputs,
outputs), **pragmatic** and **flexible** (a toolkit - use what the risk
warrants), **technology-agnostic**, and **enforced** (decisions hold through to
deployment). ASE adds: controls are read-only, every decision has a record,
and a draft is never ratified by the agent that drafted it.

## Before A1 - supporting activities

R&W assume three accepted preconditions: a baseline scope and context, the key
stakeholder concerns, and the right stakeholders engaged. They are rarely
true. Establish them in `ad/00-stakeholders.sysml` and a draft Context view:

| Supporting activity | SysML output | Skill |
|---|---|---|
| Define initial scope and context | draft `ContextView`: system `part def`, externals, boundary flows, in/out-of-scope in `doc` | `ase-viewpoint-context` |
| Engage stakeholders | `part def <Role> :> AseMethodology::<Stakeholder>` per group, `doc` naming the representative *role* | this skill |
| Capture first-cut concerns | `concern def X :> AseMethodology::<Concern>` with `stakeholder` usages, priority in `doc` | this skill |

A spec that names two stakeholders but has a latency target and a budget is
missing the SRE and the finance owner - those concerns are held by somebody.
Use `ase_concern` to find who, and ask.

## The steps

For each step: call `ase_step(node)` first; obey its controls; produce the
listed SysML; do not advance while the exit test fails.

### A1 Consolidate the inputs
- **Aim**: understand, validate and refine the raw inputs to a baseline.
- **Do**: resolve inconsistencies between spec sections; for every viewpoint
  and perspective you will apply, run `ase_obligations(vp)` and list what the
  spec does not state. Those gaps are the elicitation questions - ask only
  about them. Unanswered items become `@Assumption` records.
- **SysML**: requirement defs with the spec sentence in `doc`; concerns;
  `@Assumption` metadata; an "areas requiring exploration" list in `doc`.
- **Exit**: every required attribute of every applicable perspective has a
  value, an assumption, or a stated reason it does not apply.
- **Never** ask about concerns the spec gives no reason for (RS oracles fail a
  design that asks about tenancy or web access when nothing implies them).

### A2 Identify scenarios -> load `ase-arch-scenarios`
- **Aim**: scenarios illustrating the most important requirements.
- **SysML**: `use case def` + `@FunctionalScenario` for behaviour;
  `@QualityScenario` (six parts, numeric response measure) per quality
  requirement; a utility tree ranking them.
- **Control**: quality property requirements.

### A3 Identify styles / patterns
- **Aim**: reuse proven organisation instead of designing from scratch.
- **Do**: retrieve candidate patterns from the catalogue (`models/rag-patterns.sysml`,
  the graph's `Pattern` nodes); match their Context to the scenarios; record
  each rejection with its reason.
- **SysML**: `@ArchitectureDecision` with `alternatives` listing every
  rejected pattern and why. The pattern library is a control - copy, never edit.

### A4 Produce a candidate architecture
- **Aim**: first-cut views reflecting the primary concerns.
- **Controls**: viewpoints, perspectives, the chosen style.
- **Do**: instantiate the pattern into `design.sysml` (budgets redefined from
  the spec, each with its source sentence); then draft views in this order,
  loading each viewpoint skill (context decides the boundary; autonomy before
  operational because escalation routes feed operations):

  `context -> functional -> information -> knowledge -> concurrency -> autonomy -> deployment -> operational -> development`

  Not every system needs all nine at the same depth - decide depth by risk,
  and record a view you omit as a decision.
- **Exit**: gate passes on every file; each view exposes something.

### A5 Explore the options -> load `ase-arch-evaluation` + perspective skills
- **Aim**: make the key decisions among real alternatives.
- **Do**: apply each relevant perspective skill across the views (the
  perspective sweep: `python -m sysmlagents.cli explain <RS>`); walk each A2
  scenario against the models; for each failing or marginal verdict,
  generate options with the perspective's tactics and compare them
  numerically.
- **SysML**: `variation`/`variant` or scratch variants per option; trade
  study; `@Finding` per check result; `@ArchitectureDecision`,
  `@SensitivityPoint`, `@TradeoffPoint`, `@Risk`.

### A6 Evaluate with stakeholders
- **Aim**: confirm concerns are met, capture deficiencies, gain acceptance.
- **Inputs**: views and *perspective outputs* (findings, analyses).
- **Do**: build the evidence pack - per concern: stakeholder, framing
  viewpoint/perspective, check, verdict, decision (`ase-arch-evaluation`).
  Present conflicts as tradeoff points with numbers, not as opinions.
- **The agent drafts; the stakeholder decides.** An acceptance decision is
  recorded with the stakeholder role as owner, never the agent.

### A7 Rework the architecture / A8 Revisit the requirements (concurrent)
- Both loop back to **A5, not A1**.
- A7: apply tactics to the views; re-run the sweep; update decisions
  (supersede, never delete).
- A8: where a requirement proves infeasible or costly, draft the revision
  with the evidence; **stakeholder agreement is a control** - the revision is
  `status = "proposed"` until a stakeholder accepts it.

## Which skill when

| Symptom / need | Load |
|---|---|
| boundary, externals, scope | `ase-viewpoint-context` |
| components, responsibilities, interfaces | `ase-viewpoint-functional` |
| data ownership, lifecycle, data classes | `ase-viewpoint-information` |
| retrieval sources, memory, grounding chain | `ase-viewpoint-knowledge` |
| parallelism, fan-out, loops, termination | `ase-viewpoint-concurrency` |
| what may act without approval, escalation | `ase-viewpoint-autonomy` |
| where things run, model serving, regions | `ase-viewpoint-deployment` |
| monitoring, runbooks, failure handling in production | `ase-viewpoint-operational` |
| code structure, generated vs hand-written, CI | `ase-viewpoint-development` |
| latency, throughput, peak, capacity | `ase-perspective-performance-scalability` |
| token cost per interaction | `ase-perspective-cost` |
| trust, data exposure, tool authorisation | `ase-perspective-security` |
| failure, fallback, single points of failure | `ase-perspective-availability-resilience` |
| citations, provenance, hallucination | `ase-perspective-groundedness` |
| self-improvement, loops, envelope | `ase-perspective-drift` |
| changeability, variation, reuse | `ase-perspective-evolution` |
| laws, policies, audit evidence | `ase-perspective-regulation` |
| team, budget, time to build | `ase-perspective-development-resource` |
| residency, distance, time zones | `ase-perspective-location` |
| users working effectively | `ase-perspective-usability` |
| disabled users | `ase-perspective-accessibility` |
| languages, locales, cultures | `ase-perspective-internationalisation` |

## When to stop

R&W's criterion is **risk**, not completeness: an iteration is done when the
material risks have been mitigated - shown by no significant open comments
after stakeholder evaluation, *the architect included*. "Good enough for its
users" beats a perfect AD nobody reads. Operationally in ASE:

- `check_ad.py` has no errors for the scoped viewpoints/perspectives;
- no `error`-severity check finding without a fix or a decision;
- every `@Risk` of severity high has a mitigation decision or an owner-signed
  acceptance;
- every `@Assumption` has a `revisitWhen`.

After exit the AD stays a living document under configuration control -
decisions are superseded, not rewritten.

## Output contract

A `designs/<RS-xx>/` folder laid out as in the foundations skill, plus a
short run summary: step reached, views produced, perspectives applied or
set aside (with decision ids), open risks, open assumptions, and the
exact validation outputs. Report failures as failures.

See `references/process-map.md` for the full ICOM table per step and the
mapping to R&W's supporting activities, lifecycles and the ASE agents.
