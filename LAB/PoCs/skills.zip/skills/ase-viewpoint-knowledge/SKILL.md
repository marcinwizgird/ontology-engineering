---
name: ase-viewpoint-knowledge
description: >
  Build, analyse and review the Knowledge view of an agentic system in SysML
  v2 - the ASE extension viewpoint for what the system knows at inference
  time and where each piece came from: retrieval sources and who owns them,
  model parametric knowledge, memory scope and lifetime (turn, session,
  user, global), the grounding chain from claim to citation to source
  version, corpus refresh and staleness, and knowledge the system does not
  own. Use for RAG source inventories, memory design, citation and
  grounding chains, corpus freshness, "can every answer be traced", or to
  review one; pairs with the Groundedness perspective checks
  provenance_paths, unsourced_stages and citation_carriers. Do not use for
  data the system stores and owns - classification, ownership, retention
  (use ase-viewpoint-information) - or for applying groundedness as a
  cross-view quality (use ase-perspective-groundedness).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Knowledge viewpoint (ASE extension)

Load `ase-arch-sysml-foundations` first. Control: `AseMethodology::KnowledgeViewpoint`
- read with `ase_viewpoint("Knowledge")` and `ase_obligations("Knowledge")`.

## Definition

There is no R&W definition; this viewpoint is an ASE addition. Its
`@Extension` reason, quoted from `ase-methodology.sysml`:

> "R&W's Information viewpoint covers data the system owns. An agentic
> system is defined as much by knowledge it retrieves at inference time and
> does not own, whose grounding chain is a different structure."

Its `doc`: describes what the system knows, where each piece came from, and
how long it is retained. Methodology models: "retrieval sources, memory
scope and lifetime, grounding chain". It follows Information in the ASE
workflow (`defineInformation then defineKnowledge`).

**Why separate from Information.** Information asks *who owns this data
and how is it managed*. Knowledge asks *what may a stage say, on what
authority, and can we show it afterwards*. A corpus owned by another team
is a source here and barely an item there; a conversation memory is owned
data (Information: retention, erasure) *and* a knowledge source that
re-enters prompts (Knowledge: scope, grounding). Model them in both, linked
by `@Correspondence`.

**Stakeholders**: compliance officer and end user (they hold
`AnswerGroundedness`), systems engineer (`InformationFlow`), corpus
owners (external), the product owner deciding memory behaviour.
**Applicability**: every system with a retrieval stage, a memory, or an
LLM stage whose output a user may act on - i.e. every ASE design.

**Concerns** (framed): `AnswerGroundedness` ("Can every assertion the
system makes be traced to a source?") and `InformationFlow`. Design
concerns that specialise them: source authority and ownership; source
freshness; memory scope, lifetime and leakage between users; grounding
completeness; uncitable knowledge (model parametric knowledge, LLM
intermediates); reproducibility of an answer against a source version.

## Model elements -> SysML v2

| Element | SysML v2 | ASE convention |
|---|---|---|
| Knowledge source | `part def X :> KnowledgeSource` with `owner`, `ownedBySystem`, `citable`, `refreshCadence`, `maxStalenessDays`, `dataClass` | one per corpus, profile store, API, graph |
| Parametric knowledge | `part def ModelParametricKnowledge :> KnowledgeSource`, `citable = false` | always present; declare it so it can be reasoned about |
| Memory | `part def X :> MemoryStore` with `scope`, `lifetimeDays`, `userDeletable`, `summariseAfterTurns`, `region` | scope values: per-turn, per-session, per-user, global |
| Knowledge model | `part def KnowledgeModel` with one usage per source and memory | the view exposes it |
| Citation / provenance carrier | `item def *Citation` with `sourceKind`, `sourceId`, `sourceVersion`; `Chunk.sourceId` | names containing chunk / citation feed `citation_carriers` - declare in `design.sysml` |
| Grounding chain | `action def` whose actions pass citation items: retrieve -> generate -> judge | memory is a carrier on the chain, never its end |
| Grounding obligation | `requirement def` (min citations per claim) + `satisfy ... by <judge stage>` | verified by eval metrics (citation recall, groundedness) |
| Corpus refresh | batch `action def` with index version out | outside the interactive pattern |
| Memory lifecycle | `state def` active -> summarised -> erased | shared with Information's lifecycle model |
| Stage-level memory attributes | `@Extension` attribute on the design stage def | `vocabulary_conformance` warns - intended |

## Activities -> SysML

1. **Inventory sources.** Every thing a stage reads to decide what to say:
   corpora, profile stores, APIs, graphs, tools returning facts, the model's
   own weights. For each: owner, owned by the system or not, citable or not.
2. **Declare freshness.** `refreshCadence`, `maxStalenessDays`; model the
   refresh as a batch `action def` producing an index version. A
   refresh slower than the owner changes the source is an A1 question.
3. **Design memory.** Scope and lifetime first, mechanism second. Ask per
   memory: whose is it (leakage between users is a Security finding), how
   long, who can delete, what is summarised and by what. If the design
   stage needs these attributes, extend it on the design:
   ```
   part def ConversationMemory :> Stage {
       @AseProfile::Extension {
           reason = "Knowledge viewpoint needs memory scope and lifetime; vocabulary lacks them.";
           extends = "Stage vocabulary (RagPatterns::Stage)";
       }
       attribute memoryScope : String = "per-user";
       attribute lifetimeDays : Integer = 30;
   }
   ```
4. **Draw the grounding chain.** For each answer type: claim -> citation
   item -> chunk `sourceId` -> source at an index version. Every LLM
   stage on the chain either passes citations through or is marked
   `preservesProvenance = false` in the design.
5. **Contract the carriers.** A summariser, rewriter or planner that
   *transforms* grounded text must keep its citations - write it as a port
   contract (Functional) and a verification (eval), then declare
   `preservesProvenance = true` on the stage. Without the contract, declare
   `false` and let `provenance_paths` fire.
6. **Name what the system does not own.** Sources with `ownedBySystem =
   false`: the system can only cite them and record their version. Their
   owners are stakeholders; their outages and errors are risks.
7. **Close the uncitable sources.** Parametric knowledge and LLM
   intermediates (HyDE documents, free summaries) cannot be cited. The
   control is structural (a judge that rejects uncited claims, abstention)
   and measured (eval), never a prompt instruction alone.
8. **Run the Groundedness checks** and carry results as `@Finding`s.

## The view

```
view def KnowledgeView {
    satisfy requirement vp : AseMethodology::KnowledgeViewpoint;
    filter @SysML::PartUsage or @SysML::ItemUsage or @SysML::ActionUsage or @SysML::StateUsage;
}
view knowledge : KnowledgeView {
    expose KnowledgeModel::**;          // sources and memories
    render asTreeDiagram;
}
view groundingChain : KnowledgeView {
    expose GroundingChain::**;          // claim -> citation -> source
    render asInterconnectionDiagram;
}
```

Two renderings: the inventory (who owns what, how fresh, how long) for
compliance and corpus owners; the chain for engineers and auditors.

## Analysis the knowledge model supports

| Question | Engine |
|---|---|
| Does provenance survive every path to an output | `provenance_paths` (error) - stage `preservesProvenance`, default `true` |
| Which LLM stages generate with nothing upstream | `unsourced_stages` (warning) - LLM stage with no inbound flow |
| Is there a source-identifier carrier at all | `citation_carriers` (warning) - item def name contains chunk / citation |
| Is the design high-risk (loop + external + ungrounded) | `high_risk_classification` |
| Does a follow-up loop re-ground each pass | `bounded_cycles` + review of the chain on the back edge |
| Staleness vs change rate | none - review `maxStalenessDays` against owner change rate |
| Memory leakage between users | none - review `scope`; a `global` memory holding `pii` is a Security finding |
| Uncited-claim rate, citation recall | eval metrics bound to `verification def` (not the graph) |

What the three checks do *not* see, and must be said in any clean verdict:
`provenance_paths` trusts the declared boolean - a summariser left at the
default `true` passes without a contract; `unsourced_stages` sees an LLM
stage with *any* inbound flow as sourced, even if the inbound is another
LLM; `citation_carriers` checks a name, not that `sourceId` reaches the
answer; none of them sees parametric knowledge or memory scope. All are
closed-world: clean = nothing declared otherwise.

## Reasoning over the knowledge model

- *Where did this claim come from?* walk the chain backwards: claim ->
  citation -> `sourceId` -> source at `sourceVersion`. A break is where
  `preservesProvenance` must be `false`.
- *What if the corpus owner changes a page?* staleness window =
  `refreshCadence`; answers grounded in the old version stay reproducible
  only if `sourceVersion` is recorded.
- *What if memory is summarised?* the summariser joins the chain; either it
  keeps citations (contract + eval) or it breaks provenance.
- *What if a new source is added?* one `KnowledgeSource`, one retrieval
  stage, one citation `sourceKind` - more is a flexibility smell.
- *What does the system know that nobody can cite?* every source with
  `citable = false` and every stage with `preservesProvenance = false`.
- Correspondences (`@Correspondence`): each source is read by one retrieval
  stage (Functional); each source is an external in Context when not owned;
  each memory is an item with retention and erasure in Information; each
  memory's `region` maps to a node in Deployment (Location); each loop that
  re-retrieves appears in Concurrency with its bound.

## Pitfalls -> detection

| Pitfall | Detection |
|---|---|
| Unsourced generation | `unsourced_stages`; LLM stage fed only by other LLM stages (review) |
| Silent provenance break | rewriter, HyDE or summariser with default `preservesProvenance` and no contract |
| No citation carrier | `citation_carriers`; answer item with no citations attribute |
| Parametric knowledge undeclared | no `citable = false` source; no judge or abstention on the output path |
| Memory as a source of truth | follow-up answers cite the memory instead of the original source |
| Memory scope leak | `scope = "global"` with `dataClass` pii/restricted |
| Unbounded memory | `lifetimeDays` or `summariseAfterTurns` missing; context grows per turn (Cost) |
| Stale corpus | `maxStalenessDays` missing or longer than the owner's change rate |
| Unversioned grounding | citation without `sourceVersion`; answers not reproducible after refresh |
| Unowned knowledge assumed owned | `ownedBySystem = true` on another team's corpus; no owner stakeholder |
| Tool results treated as knowledge | tool output reaches the answer without a `sourceKind` |

## Checklist

Every source inventoried with owner, citability and freshness; parametric
knowledge declared; each memory has scope, lifetime, deletion and region;
grounding chain drawn per answer type with a version at its end; every
transforming LLM stage either contracted to keep citations or marked as a
break; uncitable output controlled by a judge or abstention and measured;
the three Groundedness checks run with their blind spots stated;
correspondences to Functional, Information, Context and Deployment stated.

## Output contract

`ad/knowledge.sysml` containing: `KnowledgeSource` and `MemoryStore`
specialisations; the `KnowledgeModel`; citation item defs; the grounding
chain `action def`; grounding requirements with `satisfy` and verification;
refresh `action def`; memory lifecycle `state def`; the `KnowledgeView`
def and view usages; `@Correspondence`s; `@Finding`s for
`provenance_paths`, `unsourced_stages`, `citation_carriers`; decisions on
memory, summarisation and uncitable sources. Updates to `design.sysml`:
`preservesProvenance` on every transforming stage, citation / chunk item
defs, memory `@Extension` attributes.

Validate (from `AI Skills/skills`):
```
python description-to-sysmlv2/scripts/check_model.py < ad/knowledge.sysml
python ase-arch-sysml-foundations/scripts/check_ad.py < ad/knowledge.sysml   # directive: fragment viewpoints=Knowledge
python -m sysmlagents.cli explain <RS-xx>     # provenance_paths, unsourced_stages, citation_carriers
```
Worked example (RS-08): `references/example.sysml`.
