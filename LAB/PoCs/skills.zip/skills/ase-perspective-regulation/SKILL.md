---
name: ase-perspective-regulation
description: >
  Apply the Rozanski & Woods Regulation perspective to an agentic system's
  SysML v2 architecture - build the obligation register (EU AI Act risk
  tier, GDPR, sector rules such as investment-advice suitability, company AI
  policy), trace every obligation stakeholder -> concern -> requirement ->
  element -> verification, classify the design's risk by definition, make
  outcomes reproducible, and generate the audit evidence pack from the
  model and the test runs. Use for compliance, audit, traceability, evidence
  pack, high-risk AI, human oversight, record keeping, reproducibility or
  "can we show the regulator" questions about an ASE design. Do not use for
  access control and data leakage mechanics (use ase-perspective-security)
  or for data residency across regions (use ase-perspective-location).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Regulation perspective

Load `ase-arch-sysml-foundations` first. Control (read-only, read with
`ase_perspective("Regulation")`): `AseMethodology::RegulationPerspective`.
There is no `AseCatalogue` entry for it yet - the catalogue carries only
Functional and Performance in full; cite the methodology entry.

## Definition

> "The ability of the system to conform to local and international laws,
> quasi-legal regulations, company policies, and other rules and standards"
> - `AseMethodology::RegulationPerspective`, source
> viewpoints-and-perspectives.info/home/perspectives.

**Applicability.** Any system that could fall under a law or rule. For an
agentic system that is every system: data protection applies as soon as a
prompt can carry personal data, and the EU AI Act reaches any AI system
placed on or used in the EU market. What varies is the tier, not whether.

**Concerns.** Framed by the control: `RegulatoryEvidence` (what evidence is
required, and is it generated?) and `Reproducibility` (can an outcome be
reproduced or explained afterwards?). R&W's own list, paraphrased: statutory
and industry regulation, privacy and data protection, cross-border legal
restrictions, data retention and accountability, organisational policy.
Agentic additions: risk-tier classification, human oversight, per-decision
record keeping, model and prompt versioning, and the separation of the
release test set from the optimisation set.

**Stakeholders.** `ComplianceOfficer` holds both framed concerns. Specs name
more: RS-10 adds model risk management, internal audit and the regulator
(external, represented - never interviewed). R&W's special note: compliance
is not negotiable. Other qualities are traded; this one is met or the system
does not ship. Record it as `nonNegotiable = true` on the requirement.

## Activities -> SysML

R&W give one activity (compliance auditing) and one tactic (assess the
architecture against the rules). In ASE that unfolds into six steps.

### 1. Identify the regimes and build the obligation register

Ask in A1, only where the spec gives a reason: jurisdiction(s), sector,
personal data, whether the output affects a person's access to a service,
the company's AI policy tier. For each applicable rule write one
`requirement def` with the clause in an attribute and the spec sentence in
`doc`:

```
requirement def AutonomyAndAuthorityOversight {
    doc /* RS-10 C-3: human oversight is mandatory. */
    attribute regime : String = "bank AI policy C-3; AI Act human oversight if in scope";
    attribute nonNegotiable : Boolean = true;
}
```

Regimes an agentic design usually meets (verify the current text - these
are architecture prompts, not legal advice):

| Regime | What it asks of the architecture |
|---|---|
| EU AI Act, high-risk tier | risk management, data governance, technical documentation, automatic logging, transparency to the deployer, human oversight, accuracy / robustness / cybersecurity |
| EU AI Act, transparency tier | people know they are talking to an AI; generated content marked where required |
| GDPR | lawful basis, minimisation, storage limitation and erasure (memory, embeddings, logs), DPIA for high-risk processing, limits on solely automated decisions |
| Sector (RS-10: investment advice) | suitability judgements stay with a qualified human; communications recorded and retained |
| Company AI policy | its own tiering (RS-10 C-3), release gates, model approval |

A spec that names a regulated domain but no compliance stakeholder is
missing one: ask who it is (`ase_concern("RegulatoryEvidence")`).

### 2. Name requirements after the concern they serve

`evidence_generable` decides "can this requirement be traced to someone who
asked for it" by **name correspondence**: a requirement passes if its name
contains, or is contained in, a methodology concern name (lower-cased). So
`AnswerGroundednessClauseCitations` passes, `CostBudget` does not (RS-01's
`CostBudget`, `GroundedAnswer` and `BoundedLoop` all fire). Either name
the requirement after its concern, or accept the info finding and show the
chain another way (`frame` inside the requirement, read by the script below).

### 3. Allocate and verify every obligation

Every requirement: `satisfy R by <element>` inside the design part def (the
reader only sees `satisfy` there) or `// UNALLOCATED R - reason`. Every
requirement: a `verification def` whose method is **runnable** - a test set,
a script, a static rule - never "reviewed by". Process-level requirements
(RS-10 QR-3, QR-4) are satisfied by the ASE workbench and verified by its
self-tests: say so in `doc`, do not leave them unallocated.

```
verification def ComplianceSetRelease {
    subject design : RS10::RS10Design;
    objective {
        verify requirement AnswerGroundednessClauseCitations;
        verify requirement AutonomyAndAuthoritySuitabilityRefusal;
    }
    doc /* Frozen 400-pair set; statement_support_rate and refusal_recall = 1.0 or no release. */
}
```

### 4. Classify the risk - three ways, and keep all three

- **Definitional** (`high_risk_classification`): a pattern is flagged when
  two of three traits hold - autonomous loop (a back edge), external effect
  (a stage of an external kind), ungrounded (provenance broken on a path).
- **Label** (the spec or company policy, e.g. RS-10 C-3).
- **Statutory** (the AI Act tier; decided with counsel, recorded as
  `@Assumption` until confirmed).

The strictest wins; a disagreement is a `@Risk`. RS-10 is the teaching case:
SelfRag has a loop but no external stage and keeps provenance, so the check
is silent (1 of 3) while C-3 says high-risk. The label governs.

### 5. Make outcomes reproducible and recorded

Per interaction, one record item (`item def DraftRecord`): inputs hash,
retrieved ids with document versions, index version, model version, prompt
version, effective-date rule applied, human action. For reproducibility pin
the index version, fix k and a tie-break, pin the model, temperature 0 - and
state which parts are reproducible (the retrieved set) and which are only
equivalent (generated text).

### 6. Generate the evidence pack

The pack is **generated** from the graph plus test runs, never written by an
LLM: requirement rows with concern, satisfying element, verification and
last result, plus the rejected optimisation candidates and why. Run
`scripts/evidence_chain.py` for the matrix; ship its output in the pack.

## Applying the perspective to each view

| View | What the perspective adds in SysML |
|---|---|
| Context | regulator, auditor, data subjects as stakeholders; jurisdiction in `doc`; external providers named (a hosted model is a processor) |
| Functional | oversight gate as a stage on every output path; refusal path for out-of-mandate questions (FR-2); obligation `satisfy` links |
| Information | `dataClass` on items (`pii`, `regulated`); retention and erasure lifecycle `state def`; the record `item def` |
| Knowledge | corpus versioning and effective dates; memory retention (GDPR storage limitation) |
| Autonomy | what the agent may do without approval; approval gate per effectful action |
| Deployment | pinned model versions, on-prem constraint (RS-10 C-2), log store placement |
| Operational | log retention, audit query procedure, incident reporting route |
| Development | release gate script; frozen release set separate from optimisation data |

## Analysis the model supports

Checks bound in `@Perspective.checks`, what each reads, and how to read it:

| Check | Kind | Reads | Caveat |
|---|---|---|---|
| `requirement_traceability` | ABSENCE, error | `satisfy` in the pattern, `// UNALLOCATED X` | only `satisfy` inside the design part def counts |
| `verification_coverage` | ABSENCE, warning | a `Verification` node | **always fires** - no such node is projected; accept with a decision and show coverage with the script |
| `evidence_generable` | ABSENCE, info | requirement vs methodology concern names | name heuristic, see step 2 |
| `concern_coverage` | ABSENCE, error | `FRAMES` edges | methodology concerns only; design concerns are not projected |
| `check_coverage` | ABSENCE, warning | `DECLARES` or `@ReviewOnly` | passes today: the four review-only perspectives carry reasons |
| `orphan_stakeholder` | ABSENCE, info | `HOLDS` | stakeholders are collected *from* concerns, so it cannot fire on the methodology; design stakeholders need the script (W2) |
| `high_risk_classification` | CLASSIFICATION, info | back edges, stage type in `EXTERNAL_KINDS`, pattern provenance | `EXTERNAL_KINDS = {"WebSearchFallback"}` and a stage's type is the def its usage names directly - so a subtype of it, a model provider, or a tool that sends mail or places an order is invisible |

Text-level complement, `scripts/evidence_chain.py` (stdin, stdlib):

| Rule | Severity | What it adds over the graph |
|---|---|---|
| E1 unallocated | error | same as `requirement_traceability`, across all AD files |
| E2 unverified | error | reads `verification def ... verify R` - what the projection drops |
| E3 oversight | error | with `// oversight-gate: <usage>`, every entry->exit flow path passes the gate |
| W1 untraced | warning | concern by `frame` or name, design concerns included |
| W2 orphan | warning | design stakeholders that hold no concern |
| W3 empty test | warning | a verification def that verifies nothing |

The RS-10 oracle expects the oversight gate "on every path"; no ASE check
computes that today - E3 does, over the declared flows (closed-world).

## Reasoning over the model

- **Concern -> evidence chain** (foundations, reasoning pattern 2): a break
  anywhere is a Regulation finding. Walk it for every non-negotiable.
- **What-if: add a tool.** Add a stage of an external kind to a looping
  pattern; `high_risk_classification` should flip. If the tool is not an
  external kind, it will not - which is the argument for promoting an
  `externalEffect : Boolean` stage attribute (`@Extension`, roadmap item).
- **Closed world.** "Every requirement is verified" means "every declared
  requirement has a declared verification". An obligation nobody wrote down
  is invisible; the A1 regime list is the only defence.
- **Correspondence.** Every `pii` or `regulated` item (Information) must meet
  a retention state (Information) and an erasure procedure (Operational):
  `@Correspondence { kind = "refines"; rule = "every pii item has a retention state"; }`.

## Tactics -> SysML change -> expected effect

| Tactic | Agentic form | SysML change | What should move |
|---|---|---|---|
| Assess against the rules (R&W) | obligation register | requirement def per obligation with `regime` | E1/E2 rows appear |
| Human oversight gate | adviser approves before send | terminal gate stage, `llmCalls = 0`; `// oversight-gate:` directive | E3 clean |
| Scope refusal | refuse suitability judgements | classifier stage before retrieval, refusal path to the gate | refusal requirement verified |
| Record everything | one record per interaction | `item def` record; every stage writes it | record verification passes |
| Pin and version | reproducible retrieval | index / model / prompt version attributes; temperature 0 | reproducibility test |
| Governed optimisation | GEPA candidates pass the release gate | verification def on the frozen set; rejected candidates in the pack | FR-5 evidence |
| Keep grounding | clause-level citations | `preservesProvenance` on every stage | `high_risk_classification` stays below threshold |
| Minimise data | no personal data in prompts or logs | `dataClass` on items, redaction stage | `data_exposure` (Security) |

## Pitfalls -> detection in the model

| Pitfall | Detection |
|---|---|
| Not understanding the obligations a rule creates | requirement defs with no `regime`; A1 record has no regime list |
| Unaware of a statute that applies | domain in scope (finance, health, HR decisions) and no compliance stakeholder |
| Evidence written by hand | pack has no link to test runs; verification defs say "review" |
| Label trusted over structure, or the reverse | no `@Risk` where definitional and label classifications differ |
| Oversight on some paths only | E3 |
| Release set leaks into optimisation | same dataset named in GEPA and release verification defs |
| Reproducibility claimed for generated text | reproducibility requirement with no statement of what is equivalent vs identical |
| Unbounded retention in memory or logs | `pii` item with no retention state |
| (agentic) effectful tool not recognised | new tool stage, `high_risk_classification` unchanged |

## Checklist

Regimes listed with owner; every obligation a requirement with `regime`;
every requirement satisfied and verified by something runnable; three
classifications recorded, strictest applied; oversight on every output path;
record item defined and verified; versions pinned; release and optimisation
sets separated; `verification_coverage` accepted by decision citing the
projection limit; evidence pack generated, not written.

## Output contract

In `ad/perspectives.sysml` (requirements that checks read go in `design.sysml`):

1. `satisfy AseMethodology::RegulationPerspective by <Design>;`
2. stakeholders and concerns specialising `RegulatoryEvidence` / `Reproducibility`
3. obligation register: one requirement def per obligation, each allocated
4. one runnable `verification def` per requirement
5. the record `item def`
6. `@Assumption` for the statutory classification; `@Finding` per check,
   `@Risk` for classification disagreement; `@ArchitectureDecision` per choice

Validate: gate on every file; `check_ad.py` with
`// ad-check: perspectives=Regulation`; `evidence_chain.py` over the whole
AD (exit 0); `ase_gap`; `python -m sysmlagents.cli explain <RS-xx>`. Worked
RS-10 example: `references/example.sysml`.
