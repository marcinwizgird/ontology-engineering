#!/usr/bin/env python3
"""Evidence-chain checker for the Regulation perspective.

Reads an ASE design and its AD files concatenated on stdin and prints the
traceability matrix an evidence pack is built from:

    stakeholder -> concern -> requirement -> satisfy (element) -> verify (test)

It exists because the ASE projection does not build Verification nodes, so
`verification_coverage` fires on every design, and because `orphan_stakeholder`
only sees methodology stakeholders. This script reads the text instead.

Rules
    E1 unallocated   requirement def with no `satisfy R by X` and no
                     `// UNALLOCATED R - reason`                        error
    E2 unverified    requirement def no `verification def` verifies      error
    W1 untraced      requirement def reached by no concern: it neither
                     frames a concern nor contains (or is contained in)
                     a concern name, declared or methodology              warning
    W2 orphan        design stakeholder part def named by no concern     warning
    W3 empty test    verification def with no `verify`                   warning
    E3 oversight     with `// oversight-gate: <usage>` in the input, some
                     entry->exit flow path in a part def containing that
                     usage avoids it                                       error

Self-contained, stdlib only. Exit 0 when no errors, 1 otherwise.
"""

import re
import sys

METHODOLOGY_CONCERNS = [
    "SystemBreakdown", "InformationFlow", "AnswerGroundedness",
    "ConcurrencyAndFanOut", "Termination", "CostPerInteraction",
    "LatencyBudget", "PrivilegeBoundaries", "DataExposure",
    "FailureBehaviour", "OperationalVisibility", "AutonomyAndAuthority",
    "BehaviouralDrift", "Reproducibility", "Buildability",
    "DeploymentTopology", "RegulatoryEvidence",
]
BASE_STAKEHOLDERS = {
    "Stakeholder", "SystemsEngineer", "SoftwareEngineer", "ProductOwner",
    "ComplianceOfficer", "SecurityArchitect", "SiteReliabilityEngineer",
    "FinanceOwner", "EndUser",
}


def strip(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    text = re.sub(r'"[^"\n]*"', '""', text)
    return re.sub(r"//[^\n]*", " ", text)


def blocks(text, header):
    for m in re.finditer(header, text):
        i = text.find("{", m.end())
        semi = text.find(";", m.end())
        if i < 0 or (0 <= semi < i):
            yield m.group(1), ""
            continue
        depth, j = 0, i
        while j < len(text):
            depth += {"{": 1, "}": -1}.get(text[j], 0)
            if depth == 0:
                break
            j += 1
        yield m.group(1), text[i + 1:j]


def paths_avoid(nodes, edges, gate):
    """True if some entry->exit path avoids `gate`."""
    ins = {n for _, n in edges}
    outs = {n for n, _ in edges}
    entries = [n for n in nodes if n not in ins] or list(nodes)[:1]
    exits = {n for n in nodes if n not in outs}
    succ = {}
    for a, b in edges:
        if a != gate and b != gate:
            succ.setdefault(a, []).append(b)
    seen, stack = set(), [e for e in entries if e != gate]
    while stack:
        n = stack.pop()
        if n in seen:
            continue
        seen.add(n)
        stack.extend(succ.get(n, []))
    return sorted(seen & (exits - {gate}))


def main():
    raw = sys.stdin.read()
    text = strip(raw)
    errors, warnings = [], []

    reqs = {}
    for name, body in blocks(text, r"\brequirement\s+def\s+(\w+)"):
        if "@Perspective" in body:          # methodology perspectives: controls
            continue
        reqs[name] = body
    satisfied = {}
    for r, by in re.findall(r"\bsatisfy\s+(?:requirement\s+)?(?:\w+::)*(\w+)\s+by\s+([\w:.]+)", text):
        satisfied.setdefault(r, []).append(by.split("::")[-1])
    unalloc = set(re.findall(r"//\s*UNALLOCATED\s+(\w+)", raw))

    verified, tests = {}, []
    for vname, body in blocks(text, r"\bverification\s+def\s+(\w+)"):
        tests.append(vname)
        vs = re.findall(r"\bverify\s+(?:requirement\s+)?(?:\w+::)*(\w+)", body)
        if not vs:
            warnings.append(f"W3 verification {vname}: verifies nothing")
        for r in vs:
            verified.setdefault(r, []).append(vname)

    concerns, holders = {}, {}
    for cname, body in blocks(text, r"\bconcern\s+def\s+(\w+)"):
        concerns[cname] = body
        for s in re.findall(r"\bstakeholder\s+\w+\s*:\s*(?:\w+::)*(\w+)", body):
            holders.setdefault(s, []).append(cname)
    concern_names = list(concerns) + METHODOLOGY_CONCERNS

    # -- matrix ------------------------------------------------------------
    rows = []
    for r, body in sorted(reqs.items()):
        framed = re.findall(r"\bframe\s+(?:concern\s+\w+\s*:\s*)?(?:\w+::)*(\w+)", body)
        low = r.lower()
        named = [c for c in concern_names if c.lower() in low or low in c.lower()]
        concern = (framed or named or ["-"])[0]
        by = ",".join(dict.fromkeys(satisfied.get(r, []))) or ("UNALLOCATED" if r in unalloc else "-")
        ver = ",".join(verified.get(r, [])) or "-"
        rows.append((r, concern, by, ver))
        if by == "-":
            errors.append(f"E1 requirement {r}: neither satisfied nor marked UNALLOCATED")
        if ver == "-" and by != "UNALLOCATED":
            errors.append(f"E2 requirement {r}: no verification def verifies it")
        if concern == "-":
            warnings.append(f"W1 requirement {r}: no concern reaches it - nobody can be "
                            "shown to have asked for it")

    for name, _ in blocks(text, r"\bpart\s+def\s+(\w+)\s*:>\s*(?:\w+::)*(?:" +
                          "|".join(BASE_STAKEHOLDERS) + r")\b"):
        if name not in holders and name not in BASE_STAKEHOLDERS:
            warnings.append(f"W2 stakeholder {name}: holds no concern")

    # -- oversight gate on every path ---------------------------------------
    for gate in re.findall(r"//\s*oversight-gate:\s*(\w+)", raw):
        hit = False
        for pname, body in blocks(text, r"\bpart\s+def\s+(\w+)"):
            nodes = set(re.findall(r"\bpart\s+(\w+)\s*:", body))
            if gate not in nodes:
                continue
            hit = True
            edges = re.findall(r"\bflow\s+(\w+)\s+to\s+(\w+)", body)
            leak = paths_avoid(nodes, edges, gate)
            if leak:
                errors.append(f"E3 {pname}: output reachable without {gate} at "
                              + ", ".join(leak))
        if not hit:
            errors.append(f"E3 oversight gate {gate}: no part def contains it")

    # -- report ------------------------------------------------------------
    head = "FAIL" if errors else ("OK with warnings" if warnings else "OK")
    print(f"{head} - {len(reqs)} requirements, {len(tests)} verifications, "
          f"{len(concerns)} design concerns")
    if rows:
        w = max(len(r[0]) for r in rows)
        print(f"  {'requirement':<{w}}  concern | satisfied by | verified by")
        for r, c, b, v in rows:
            print(f"  {r:<{w}}  {c} | {b} | {v}")
    for tag, items in (("error", errors), ("warning", warnings)):
        for i in items:
            print(f"  - {tag}: {i}")
    print("note: text-level, closed-world - it sees only what the files declare")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
