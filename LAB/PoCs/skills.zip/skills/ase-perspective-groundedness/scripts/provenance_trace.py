#!/usr/bin/env python3
"""Provenance trace for an ASE pattern or design (Groundedness perspective).

Reads a SysML v2 model (the ASE stage subset) on stdin and lists, per pattern,
every entry-to-output path with the stages that break provenance
(preservesProvenance = false) and the stages that call a model. Also reports
what provenance_paths / citation_carriers / unsourced_stages cannot see:

  * a break at the output stage itself (provenance_paths looks downstream only)
  * a break inside a cycle
  * stages that do not declare preservesProvenance (read as true)
  * item defs named chunk/citation that carry no source attribute

    python provenance_trace.py < design.sysml

Stdlib only. Exit 1 when any path to an output is broken, 0 otherwise.
"""

import re


VOCAB = ("llmCalls", "latencyMs", "costTokens", "fanOut",
         "preservesProvenance", "hasFallback", "trustLevel", "dataClass")
ATTR = re.compile(r"^attribute\s+(?:(?:redefines|:>>)\s+)?(\w+)\s*(?::\s*[\w:]+)?\s*(?:=\s*(.+))?$")
PART_USE = re.compile(r"^part\s+(\w+)\s*:\s*(?:\w+::)*(\w+)")
FLOW = re.compile(r"^flow\s+(\w+)\s+to\s+(\w+)$")
PART_DEF = re.compile(r"^part\s+def\s+(\w+)(?:\s*(?::>|specializes)\s*(?:\w+::)*(\w+))?$")
ITEM_DEF = re.compile(r"^item\s+def\s+(\w+)")
REQ_DEF = re.compile(r"^requirement\s+def\s+(\w+)$")


def _val(raw):
    if raw is None:
        return None
    raw = raw.strip().rstrip(";").strip()
    if raw in ("true", "false"):
        return raw == "true"
    try:
        return int(raw)
    except ValueError:
        return raw.strip('"')


def _blocks(text):
    root = {"head": "<root>", "stmts": [], "kids": []}
    stack, buf = [root], []
    for ch in text:
        if ch == "{":
            kid = {"head": " ".join("".join(buf).split()), "stmts": [], "kids": []}
            stack[-1]["kids"].append(kid)
            stack.append(kid)
            buf = []
        elif ch == "}":
            tail = " ".join("".join(buf).split())
            if tail:
                stack[-1]["stmts"].append(tail)
            buf = []
            if len(stack) > 1:
                stack.pop()
        elif ch == ";":
            s = " ".join("".join(buf).split())
            if s:
                stack[-1]["stmts"].append(s)
            buf = []
        else:
            buf.append(ch)
    return root["kids"]


def read(text):
    """-> dict(defs={name:(parent, attrs)}, patterns={name:{attrs,usages,flows}},
    items={name:[attr names]}, reqs={name:attrs})"""
    text = re.sub(r"doc\s*/\*.*?\*/", " ", text, flags=re.S)
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    text = re.sub(r"//[^\n]*", " ", text)
    m = {"defs": {}, "patterns": {}, "items": {}, "reqs": {}}

    def attrs(b):
        out = {}
        for s in b["stmts"]:
            a = ATTR.match(s)
            if a:
                out[a.group(1)] = _val(a.group(2))
        return out

    def walk(bs):
        for b in bs:
            h = b["head"]
            if h.startswith("package "):
                for st in b["stmts"]:                  # bodiless `part def X :> Y;`
                    pd = PART_DEF.match(st)
                    if pd:
                        m["defs"].setdefault(pd.group(1), (pd.group(2), {}))
                walk(b["kids"])
                continue
            pd = PART_DEF.match(h)
            if pd:
                us = [PART_USE.match(s) for s in b["stmts"]]
                fl = [FLOW.match(s) for s in b["stmts"]]
                if any(us) or any(fl):
                    m["patterns"][pd.group(1)] = {
                        "attrs": attrs(b),
                        "usages": {u.group(1): u.group(2) for u in us if u},
                        "flows": [(f.group(1), f.group(2)) for f in fl if f]}
                else:
                    m["defs"][pd.group(1)] = (pd.group(2), attrs(b))
                continue
            it = ITEM_DEF.match(h)
            if it:
                m["items"][it.group(1)] = list(attrs(b))
                continue
            rq = REQ_DEF.match(h)
            if rq:
                m["reqs"][rq.group(1)] = attrs(b)
    walk(_blocks(text))
    return m


def resolved(m, name):
    chain, seen, cur = [], set(), name
    while cur and cur in m["defs"] and cur not in seen:
        seen.add(cur)
        chain.append(m["defs"][cur][1])
        cur = m["defs"][cur][0]
    out = {}
    for a in reversed(chain):
        out.update({k: v for k, v in a.items() if v is not None})
    return out


def back_edges(nodes, edges):
    succ = {n: [] for n in nodes}
    for a, b in edges:
        succ[a].append(b)
    colour, back = {n: 0 for n in nodes}, set()

    def visit(n):
        colour[n] = 1
        for x in succ[n]:
            if colour[x] == 1:
                back.add((n, x))
            elif colour[x] == 0:
                visit(x)
        colour[n] = 2
    for n in nodes:
        if colour[n] == 0:
            visit(n)
    return back


def _reach(succ, start):
    seen, stack = set(), [start]
    while stack:
        n = stack.pop()
        if n not in seen:
            seen.add(n)
            stack.extend(succ.get(n, []))
    return seen


def cycle_members(nodes, edges, back):
    succ = {n: [] for n in nodes}
    for a, b in edges:
        succ[a].append(b)
    mem = set()
    for tail, head in back:
        seen = _reach(succ, head)
        if tail in seen:
            mem |= {n for n in seen if tail in _reach(succ, n)}
        mem |= {head, tail}
    return mem


def analyse(m, pname, override=None):
    """Worst-case numbers, same assumptions as sysmlagents.analysis.
    override: {"maxIterations": n, "fanOut": {usage: n}, "defs": {def: {attr: v}}}"""
    ov = override or {}
    p = m["patterns"][pname]
    nodes = list(p["usages"])
    edges = [(a, b) for a, b in p["flows"] if a in p["usages"] and b in p["usages"]]
    at = {}
    for n in nodes:
        d = p["usages"][n]
        at[n] = dict(resolved(m, d))
        at[n].update(ov.get("defs", {}).get(d, {}))
        if n in ov.get("fanOut", {}):
            at[n]["fanOut"] = ov["fanOut"][n]
    mi = int(ov.get("maxIterations", p["attrs"].get("maxIterations", 1)) or 1)
    back = back_edges(nodes, edges)
    dag = [e for e in edges if e not in back]
    oncyc = cycle_members(nodes, edges, back)
    it = {n: (mi if n in oncyc else 1) for n in nodes}
    indeg = {n: 0 for n in nodes}
    succ = {n: [] for n in nodes}
    preds = {n: [] for n in nodes}
    for a, b in dag:
        succ[a].append(b)
        indeg[b] += 1
        preds[b].append(a)
    order, q = [], [n for n in nodes if indeg[n] == 0]
    while q:
        n = q.pop(0)
        order.append(n)
        for x in succ[n]:
            indeg[x] -= 1
            if indeg[x] == 0:
                q.append(x)
    fan = {}
    for n in order:
        fan[n] = max((fan.get(x, 1) * int(at[x].get("fanOut", 1) or 1) for x in preds[n]),
                     default=1)
    for n in nodes:
        fan.setdefault(n, 1)
    best = {n: 0 for n in nodes}
    for n in order:
        own = int(at[n].get("latencyMs", 0) or 0) * it[n]
        best[n] = (max(best[x] for x in preds[n]) if preds[n] else 0) + own
    rows = []
    for n in nodes:
        c = int(at[n].get("costTokens", 0) or 0)
        l = int(at[n].get("llmCalls", 0) or 0)
        rows.append((n, p["usages"][n], c, fan[n], it[n], c * fan[n] * it[n], l * fan[n] * it[n]))
    return {"rows": rows, "cost": sum(r[5] for r in rows), "llm": sum(r[6] for r in rows),
            "latency": max(best.values()) if best else 0, "maxIterations": mi,
            "back": sorted(back), "on_cycle": oncyc, "attrs": at, "edges": edges,
            "dag": dag, "declared_bound": "maxIterations" in p["attrs"]}


SOURCE_ATTR = re.compile(r"^(source\w*|citations?|citationIds?|docId|chunkId|uri|url)$", re.I)


def paths(succ, start, sinks, limit=200):
    out, stack = [], [(start, [start])]
    while stack and len(out) < limit:
        n, path = stack.pop()
        if n in sinks:
            out.append(path)
            continue
        for x in succ[n]:
            if x not in path:
                stack.append((x, path + [x]))
    return out


def main(argv):
    import sys
    m = read(sys.stdin.read())
    if not m["patterns"]:
        print("no pattern found (a part def with part usages or flows)")
        return 1
    errors = 0
    carriers = {i: [a for a in attrs if SOURCE_ATTR.search(a)] for i, attrs in m["items"].items()}
    named = [i for i in m["items"] if "chunk" in i.lower() or "citation" in i.lower()]
    print("item defs carrying a source identifier:")
    for i, attrs in carriers.items():
        flag = "carries " + ", ".join(attrs) if attrs else "no source attribute"
        note = "  <- citation_carriers counts it by NAME only" if i in named and not attrs else ""
        print(f"   {i:<16}{flag}{note}")
    if not any(carriers.values()):
        print("   none - citations cannot be traced mechanically")
    for name, p in m["patterns"].items():
        a = analyse(m, name)
        succ = {n: [] for n in p["usages"]}
        for x, y in a["dag"]:
            succ[x].append(y)
        indeg = {n: 0 for n in p["usages"]}
        for x, y in a["dag"]:
            indeg[y] += 1
        entries = [n for n in p["usages"] if indeg[n] == 0]
        sinks = {n for n in p["usages"] if not succ[n]}
        breaks = {n for n in p["usages"] if a["attrs"][n].get("preservesProvenance", True) is False}
        undeclared = [n for n in p["usages"] if "preservesProvenance" not in a["attrs"][n]]
        print(f"\n== {name}  entries={entries} outputs={sorted(sinks)}")
        allp = [q for e in entries for q in paths(succ, e, sinks)]
        for q in allp:
            bad = [n for n in q if n in breaks]
            gen = [n for n in q if int(a["attrs"][n].get("llmCalls", 0) or 0)]
            tag = f"BROKEN at {', '.join(bad)}" if bad else "grounded"
            print(f"   {' -> '.join(q):<60} {tag}; generating: {', '.join(gen) or 'none'}")
        for n in sorted(breaks & sinks):
            print(f"   BLIND SPOT: {n} breaks provenance and IS the output - "
                  f"provenance_paths only looks downstream of a break and stays silent")
        for n in sorted(breaks & a["on_cycle"]):
            print(f"   LOOP: {n} breaks provenance inside a cycle - every later pass inherits it")
        for n in p["usages"]:
            if int(a["attrs"][n].get("llmCalls", 0) or 0) and indeg[n] == 0 and \
                    not [e for e in a["back"] if e[1] == n]:
                print(f"   UNSOURCED: {n} calls a model with nothing upstream (unsourced_stages)")
        if undeclared:
            print(f"   ASSUMED: {', '.join(undeclared)} declare(s) no preservesProvenance - "
                  f"read as true (closed-world default)")
        errors += bool([q for q in allp if any(n in breaks for n in q)])
    return 1 if errors else 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv[1:]))
