---
name: ase-perspective-groundedness
description: >
  Apply the ASE Groundedness perspective (an extension to Rozanski & Woods)
  to an agentic system's SysML v2 architecture - trace every generated
  assertion back to a retrieved source on every path, find stages that break
  provenance or generate from nothing, make citations a modelled item that
  reaches the output, record waivers such as HyDE's provenance break, and
  verify faithfulness through evaluation. Use for citations, provenance,
  hallucination, "can every answer be traced to a document", grounded
  answers, abstention, and faithfulness or groundedness metrics in an ASE
  design. Do not use for what knowledge the system holds and how long it
  keeps it (use ase-viewpoint-knowledge) or for leakage of restricted data
  (use ase-perspective-security).
version: "1.0.0"
domain: architecture
owner: dataenlight-ai-lab
kind: hybrid
trust_tier: 2
---

# Groundedness perspective

Load `ase-arch-sysml-foundations` first. Methodology entry (control, read
with `ase_perspective("Groundedness")`, cite with
`ase_provenance("GroundednessPerspective")`):
`AseMethodology::GroundednessPerspective`, `origin = "extension"`,
`checks = "provenance_paths,citation_carriers,unsourced_stages"`.

## Definition

> "The ability of the system to trace every assertion it makes back to a
> source, on every path." - `AseMethodology::GroundednessPerspective` doc,
> ase-methodology.sysml.

The recorded extension reason (quoted): *"No R&W analogue. An
Information-viewpoint concern raised to perspective status because for
agentic systems it cuts across retrieval, generation and operation, and
because it is the property that makes an answer auditable."*

**Applicability.** Every design in which a model-calling stage produces
content a person will read or act on. Hard requirement where a spec says
"cite", "traceable", "no unsupported statements" (RS-01, RS-05, RS-06,
RS-09, RS-10); a negotiable one where it says "ideally" (RS-03).

**Concerns.** `AnswerGroundedness` ("Can every assertion the system makes
be traced to a source?"), also framed by the Information and Knowledge
viewpoints. Related: `Reproducibility` (same inputs, same retrieved set),
`RegulatoryEvidence`. **Stakeholders:** `ComplianceOfficer`, `EndUser`
(hold the concern); `ProductOwner` (signs any waiver).

## Activities -> SysML

### 1. Make the requirement binary

"Ideally traceable" is not a requirement. Ask in A1 whether grounding is
required per sentence, per answer, or only as a source list, and whether
abstention is required when nothing relevant is retrieved. The analysis
reads one requirement by name: `GroundedAnswer`.

```
requirement def GroundedAnswer {
    doc /* RS-05 QR-2: "Every statement must be supported by the guideline." */
}
```

Specialise the concern when the spec's grounding is narrower
(`concern def AbstractListCorrect :> AseMethodology::AnswerGroundedness`).

### 2. Declare provenance on every stage

Obligation (`check_ad.py` REQUIRED for Groundedness): `preservesProvenance`.
Set it `false` on any stage whose output contains text with no source:
HyDE's hypothetical document, a summariser that drops ids, a memory
compactor, a planner writing free text that later becomes context.

**Closed world.** A stage that declares nothing is read as `true` by both the
delegate and the check. A clean result on undeclared stages is a gap.

### 3. Model the citation carrier

Provenance is carried by an item, not asserted by a stage:

```
item def Chunk  { attribute text : String; attribute sourceId : String; }
item def SourcedAnswer { attribute text : String; attribute sourceIds : String[0..*]; }
```

Put these `item def`s in `design.sysml`: `cli explain` reads that file only,
and `citation_carriers` matches item *names* there. Typed flows
(`flow of Chunk from dense to synth`) belong in the Information / Knowledge
view file - `model_reader` reads only `flow a to b`.

### 4. Analyse

| Question | Engine | Reads | Blind spot |
|---|---|---|---|
| Does provenance survive every path to an output | `provenance_paths` (error) | `preservesProvenance`, flows | fires only when a breaking stage has a **downstream** stage with no outgoing flow: silent when the breaker is itself the output, and silent on any pattern whose output sits on a cycle (SelfRag, AgenticRag - the judge has a back edge, so no sink exists) |
| Which model stage generates from nothing | `unsourced_stages` (warning) | `llmCalls`, inbound flows | only "no inbound flow at all"; a generator fed by a non-retrieval stage passes |
| Can a citation be checked mechanically | `citation_carriers` (warning) | an `item def` whose **name** contains chunk / citation | name only - an item `Chunk` without `sourceId` passes; does not test that the id reaches the output |
| Holds / claimed | `GroundedAnswer` verdict in `analyse()` | all stages preserve provenance | same closed-world default |
| Whole path listing + blind spots | `scripts/provenance_trace.py` | the design on stdin | reports terminal breaks, breaks in loops, undeclared stages, carriers without a source attribute |

On the reference model: `provenance_paths` fires once, on HydeRag ("hyde
breaks provenance and reaches 1 output stage(s)"); `unsourced_stages` fires
on HydeRag.hyde and AgenticRag.orchestrator; `citation_carriers` is clean
(`Chunk`); it fires on tripwire, which has no such item.

### 5. HyDE: a provenance break by construction

HydeRag embeds a generated hypothetical document to retrieve. The library
records the consequence in the pattern itself:

```
part def HydeRag {
    ...
    // UNALLOCATED GroundedAnswer - the hypothetical document has no source
}
```

`requirement_traceability` reads that marker (exact form
`// UNALLOCATED <Name> - reason`), so the gap is stated rather than silent.
`provenance_paths` does not read it and still reports the break as an error.
That is correct: the check reports the structure, the AD carries the
decision. Record an `@Finding { disposition = "waive"; decision = ...; }`
linked to the stakeholder's waiver (RS-03 pass criterion 3: "the sweep shows
the break as a decided warning"). Never flip `preservesProvenance` to `true`
to make the sweep green, and never edit `rag-patterns.sysml`.

The waiver does not remove grounding altogether: the sources listed still
come from dense retrieval, so a weaker requirement (`SourceListResolves`)
can be allocated and verified - see `references/example.sysml`.

### 6. Verify through evaluation

The model proves a *path* for sources; only evaluation shows the *content*
is supported. Express each as a `verification def` verifying the grounding
requirement, and name the metric:

| Metric | Measures | Where used |
|---|---|---|
| `groundedness` (ASE I0 evaluator) | every citation resolves to a chunk the program retrieved | RS-01; informational in RS-03 |
| faithfulness / `statement_support_rate` | every statement supported by its cited passage (judge or NLI) | RS-05, RS-10 (release blocks below 1.0) |
| `unattributed_claim_rate` | claims with no attribution | RS-09 (must be 0) |
| `citation_recall` | cited sources vs the sources needed | RS-06 |
| abstention recall | unanswerable questions answered with "not found" | RS-05 (eval set must contain them) |

A judge that uses the same model as the generator grades its own work;
record the judge model and its agreement with human labels.

## Applying the perspective to each view

| View | What the perspective adds or checks in SysML |
|---|---|
| Context | which sources are authoritative; external (web) sources marked as such |
| Functional | `preservesProvenance` per stage; judge / abstention stages; where citations are assembled |
| Information | carrier items (`Chunk.sourceId`, `SourcedAnswer.sourceIds`), typed flows to the output, corpus versioning |
| Knowledge | grounding chain from source to answer; memory and summaries as provenance breakers |
| Concurrency | fused / reranked results keep ids through fusion; loops re-grounding each pass |
| Autonomy | who may publish an answer that failed the judge |
| Operational | per-answer trace of retrieved ids and citations (RS-10 FR-3 record) |
| Development | prompt contracts that require ids in outputs; generated signatures with a `citations` field |

## Tactics -> SysML change -> expected effect

| Tactic | Agentic form | SysML change | Check / verdict that should move |
|---|---|---|---|
| Keep ids through every transform | fusion, rerank and compression pass `sourceId` | typed flows of `Chunk`; stage keeps `preservesProvenance = true` | `provenance_paths`, `citation_carriers` |
| Use generated text only as a key | HyDE text for retrieval, never as context | decision + `@Risk`; weaker requirement allocated | stays waived - `@Finding` with decision |
| Replace the breaker | query expansion instead of HyDE | swap `HydeGenerator` for `MultiQueryExpander` | `provenance_paths` clean, `GroundedAnswer` satisfiable |
| Judge the answer | groundedness evaluator with retry | SelfRag loop + `maxIterations` | verdict via eval; note the check's cycle blind spot |
| Abstain | "not found" when retrieval is empty or judged irrelevant | fallback stage, `hasFallback = true` | `fallback_coverage`; abstention eval |
| Resolve citations | post-check that every cited id was retrieved | citation-verifier stage before the output | eval `groundedness` |
| Provenance-preserving memory | store turns with source ids, not free summaries | memory stage `preservesProvenance` stated | `provenance_paths` |
| Version the corpus | pinned index version and effective date | Information view attribute + decision | reproducibility test |

## Pitfalls -> how to detect them in the model

| Pitfall | Detection |
|---|---|
| Hedged requirement ("ideally") | `GroundedAnswer` neither satisfied nor `// UNALLOCATED` - `requirement_traceability` |
| Undeclared provenance read as preserved | stages lacking `preservesProvenance`; `provenance_trace.py` ASSUMED lines; `ase_gap` |
| Break at the output stage | `provenance_trace.py` BLIND SPOT - `provenance_paths` is silent |
| Break inside a loop | `provenance_trace.py` LOOP - no sink, `provenance_paths` silent |
| Carrier in name only | `Chunk` without `sourceId`; `provenance_trace.py` flags it |
| Silent waiver | break present, no decision; `@Finding` without `decision` (`check_ad.py` warns) |
| Waiver by attribute edit | `preservesProvenance` flipped with no measured evidence - diff review |
| Summaries and memory drop ids | memory / summariser stage declares `true` with no carrier item flowing through it |
| Generation when retrieval is empty | no abstention path; eval set has no unanswerable questions |
| Self-graded faithfulness | judge model equals generator model; no human agreement figure |
| External source treated as authoritative | web fallback grounds the answer; no Context-view decision on trust |

## Checklist

Grounding requirement is binary and named `GroundedAnswer` (or its gap
marked); every stage declares `preservesProvenance`; a carrier item has a
source attribute and a flow to the output; `provenance_trace.py` shows no
unexplained break, including terminal and in-loop breaks; each break is
removed or waived by a named owner; abstention path exists where required;
a `verification def` names the eval metric and threshold; the waived
property is still reported by the eval.

## Output contract

In `ad/perspectives.sysml` (grounding items in `ad/information.sysml`):

1. `satisfy AseMethodology::GroundednessPerspective by <Design>;`
2. `GroundedAnswer` satisfied, or `// UNALLOCATED GroundedAnswer - reason` in `design.sysml`
3. carrier `item def`s with a source attribute, flowing to the output
4. one `@Finding` per `provenance_paths`, `unsourced_stages`, `citation_carriers` result, with disposition and decision; plus any `provenance_trace.py` blind-spot result
5. `@ArchitectureDecision` for every waiver and every provenance-affecting tactic; `@Risk` for residual exposure
6. `verification def` per grounding requirement naming the eval metric

Validate (from `AI Skills/skills`):

```
python description-to-sysmlv2/scripts/check_model.py < <file>
python ase-arch-sysml-foundations/scripts/check_ad.py < <file>   # // ad-check: perspectives=Groundedness
python ase-perspective-groundedness/scripts/provenance_trace.py < <design.sysml>
```

then `ase_gap(<design>)` and `python -m sysmlagents.cli explain <RS-xx>`.
Worked RS-03 example (HyDE waiver): `references/example.sysml`.
